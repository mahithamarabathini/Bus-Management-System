from fastapi import FastAPI
from datetime import datetime
import joblib
from dotenv import load_dotenv
load_dotenv()

from services.route_service import get_route_data
from services.traffic_service import get_traffic_factor
from services.weather_service import get_rain_mm
from utils.note_generator import generate_note

app = FastAPI()
model = joblib.load("model.pkl")

@app.post("/predict-eta")
def predict_eta(data: dict):
    start = data["start"]
    end = data["end"]

    distance_km, base_eta = get_route_data(start, end)
    traffic_factor = get_traffic_factor(start["lat"], start["lng"])
    rain_mm = get_rain_mm(start["lat"], start["lng"])
    hour = datetime.now().hour

    historical_avg_speed = 35

    features = [[
        distance_km,
        hour,
        traffic_factor,
        rain_mm,
        historical_avg_speed
    ]]

    eta = model.predict(features)[0]
    eta = max(round(eta), round(base_eta))

    note = generate_note(hour, traffic_factor, rain_mm)

    return {
        "eta_minutes": eta,
        "distance_km": round(distance_km, 2),
        "note": note
    }
