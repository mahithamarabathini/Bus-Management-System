import pandas as pd
import random

rows = []

for _ in range(1200):
    distance = random.uniform(2, 30)
    hour = random.randint(0, 23)
    traffic = random.uniform(0.8, 1.5)
    rain = random.uniform(0, 5)
    hist_speed = random.uniform(25, 45)

    eta = (distance / hist_speed) * 60
    eta *= traffic
    eta *= (1 + rain * 0.02)

    rows.append([distance, hour, traffic, rain, hist_speed, eta])

df = pd.DataFrame(
    rows,
    columns=[
        "distance_km",
        "hour_of_day",
        "traffic_factor",
        "rain_mm",
        "historical_avg_speed",
        "eta_minutes"
    ]
)

df.to_csv("train.csv", index=False)
print("Synthetic dataset generated.")
