import requests
import os

ORS_API_KEY = os.getenv("ORS_API_KEY")

def get_route_data(start, end):
    if not ORS_API_KEY:
        raise Exception("ORS_API_KEY not set")

    url = "https://api.openrouteservice.org/v2/directions/driving-car"
    headers = {
        "Authorization": ORS_API_KEY,
        "Content-Type": "application/json"
    }

    body = {
        "coordinates": [
            [start["lng"], start["lat"]],
            [end["lng"], end["lat"]]
        ]
    }

    res = requests.post(url, json=body, headers=headers).json()

    # ✅ CORRECT PARSING FOR JSON RESPONSE
    if "routes" not in res:
        raise Exception(f"OpenRouteService error: {res}")

    summary = res["routes"][0]["summary"]

    distance_km = summary["distance"] / 1000
    duration_min = summary["duration"] / 60

    return distance_km, duration_min
