import requests
import os

TOMTOM_API_KEY = os.getenv("TOMTOM_API_KEY")

def get_traffic_factor(lat, lng):
    url = (
        f"https://api.tomtom.com/traffic/services/4/flowSegmentData/absolute/10/json"
        f"?key={TOMTOM_API_KEY}&point={lat},{lng}"
    )

    try:
        res = requests.get(url).json()
        flow = res["flowSegmentData"]
        free_flow_speed = flow["freeFlowSpeed"]
        current_speed = flow["currentSpeed"]

        if current_speed == 0:
            return 1.3

        factor = free_flow_speed / current_speed
        return round(min(max(factor, 1.0), 1.5), 2)
    except:
        return 1.25
