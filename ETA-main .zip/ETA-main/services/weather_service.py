import requests
import os

WEATHER_API_KEY = os.getenv("WEATHER_API_KEY")

def get_rain_mm(lat, lng):
    url = (
        f"https://api.openweathermap.org/data/2.5/weather"
        f"?lat={lat}&lon={lng}&appid={WEATHER_API_KEY}"
    )

    try:
        res = requests.get(url).json()
        return res.get("rain", {}).get("1h", 0)
    except:
        return 0
