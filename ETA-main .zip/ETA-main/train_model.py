import pandas as pd
import joblib
from sklearn.ensemble import RandomForestRegressor

df = pd.read_csv("train.csv")

X = df.drop("eta_minutes", axis=1)
y = df["eta_minutes"]

model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X, y)

joblib.dump(model, "model.pkl")
print("ML model trained and saved as model.pkl")
