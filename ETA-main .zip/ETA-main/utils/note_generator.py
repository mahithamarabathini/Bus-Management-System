def generate_note(hour, traffic_factor, rain_mm):
    reasons = []

    if 8 <= hour <= 11 or 17 <= hour <= 20:
        reasons.append("time-of-day patterns")

    if traffic_factor > 1.2:
        reasons.append("real-time traffic conditions")

    if rain_mm > 0:
        reasons.append("weather conditions")

    if not reasons:
        return "ETA calculated using standard route conditions."

    return "ETA adjusted using " + ", ".join(reasons) + "."
