import { MaterialIcons } from "@expo/vector-icons";
import { Tabs, useRouter } from "expo-router";
import React, { useEffect } from "react";
import { Platform, View } from "react-native";

import { useAuth } from "@/contexts/AuthContext";
import { useNotifications } from "@/contexts/NotificationContext";

export default function TabLayout() {
  const { user, userData, loading } = useAuth();
  const { unreadCount } = useNotifications();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) {
      router.replace("/auth/login");
    }
  }, [user, loading, router]);

  // The loading check now includes waiting for userData to be available.
  if (loading || !user || !userData) {
    return null; // Show nothing while loading or redirecting
  }

  const renderIcon =
    (name: React.ComponentProps<typeof MaterialIcons>["name"]) =>
    ({ color, focused }: { color: string; focused: boolean }) => {
      return (
        <View
          style={{
            // Removed the blue background for the focused icon
            width: 56,
            height: 36,
            borderRadius: 18,
            backgroundColor: "transparent",
            justifyContent: "center",
            alignItems: "center",
            transform: [{ scale: focused ? 1.1 : 1 }],
          }}
        >
          <MaterialIcons
            name={name}
            size={24}
            // The icon itself will use the active color when focused
            color={color}
          />
        </View>
      );
    };

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarShowLabel: true,
        tabBarActiveTintColor: "#1e40af",
        tabBarInactiveTintColor: "#64748b",
        tabBarLabelStyle: {
          fontSize: 12,
          fontWeight: "600",
          marginTop: -4,
          marginBottom: Platform.OS === "ios" ? 0 : 6,
        },
        tabBarStyle: {
          // Removed absolute positioning to stick the bar to the bottom
          height: 80,
          backgroundColor: "#ffffff",
          borderTopWidth: 1,
          borderTopColor: "#e2e8f0", // Added a subtle top border
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: "Home",
          tabBarIcon: renderIcon("home-filled"),
        }}
      />
      <Tabs.Screen
        name="map"
        options={{
          title: "Map",
          tabBarIcon: renderIcon("map"),
        }}
      />
      <Tabs.Screen
        name="explore"
        options={{
          title: "Profile",
          tabBarIcon: renderIcon("person"),
        }}
      />
      <Tabs.Screen
        name="notifications"
        options={{
          title: "Alerts",
          tabBarIcon: renderIcon("notifications"),
          tabBarBadge: unreadCount > 0 ? unreadCount : undefined,
          tabBarBadgeStyle: {
            backgroundColor: "#ef4444",
            color: "#fff",
          },
        }}
      />
    </Tabs>
  );
}
