import { Feather, Ionicons, MaterialIcons } from "@expo/vector-icons";
import { Picker } from "@react-native-picker/picker";
import { useFocusEffect } from "@react-navigation/native";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { useCallback, useState } from "react";
import {
  Alert,
  Dimensions,
  KeyboardAvoidingView,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

import { ThemedText } from "@/components/ThemedText";
import { useAuth } from "@/contexts/AuthContext";

const { width } = Dimensions.get("window");

export default function ProfileScreen() {
  const { user, userData, logout, refreshUserData } = useAuth();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [updating, setUpdating] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [editForm, setEditForm] = useState({
    displayName: "",
    studentId: "",
    email: "",
    address: "",
    parentMobile: "",
    phoneNumber: "",
    branch: "",
    year: "",
  });

  // Refresh user data whenever screen gains focus
  useFocusEffect(
    useCallback(() => {
      refreshUserData?.();
    }, [refreshUserData])
  );

  const handleLogout = async () => {
    Alert.alert("Logout Confirmation", "Are you sure you want to logout?", [
      {
        text: "Cancel",
        style: "cancel",
      },
      {
        text: "Logout",
        style: "destructive",
        onPress: async () => {
          try {
            setLoading(true);
            await logout();
            // Navigation will be handled by the AuthContext's onAuthStateChanged listener
            // which will redirect to /auth/login when user becomes null
          } catch (error) {
            console.error("Logout error:", error);
            Alert.alert("Error", "Failed to logout. Please try again.");
            setLoading(false);
          }
        },
      },
    ]);
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case "student":
        return "graduationcap";
      case "bus_incharge":
        return "car";
      case "parent":
        return "person.2";
      case "admin":
        return "shield";
      default:
        return "person";
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case "student":
        return "#22c55e";
      case "bus_incharge":
        return "#f59e0b";
      case "parent":
        return "#8b5cf6";
      case "admin":
        return "#ef4444";
      default:
        return "#6b7280";
    }
  };

  const getRoleDisplayName = (role: string) => {
    switch (role) {
      case "student":
        return "Student";
      case "bus_incharge":
        return "Bus In-charge";
      case "parent":
        return "Parent";
      case "admin":
        return "Administrator";
      default:
        return "User";
    }
  };

  const navigateToFeature = (feature: string) => {
    switch (feature) {
      case "tracking":
        Alert.alert("Live Tracking", "Navigate to bus tracking feature");
        break;
      case "attendance":
        Alert.alert("Attendance", "Mark your attendance here");
        break;
      case "routes":
        Alert.alert("Bus Routes", "View bus routes and schedules");
        break;
      case "admin":
        if (userData?.role === "admin") {
          router.push("/admin/users" as any);
        } else {
          Alert.alert("Access Denied", "You don't have admin privileges.");
        }
        break;
      default:
        Alert.alert("Feature", `${feature} feature coming soon!`);
    }
  };

  const handleEditProfile = () => {
    setEditForm({
      displayName: userData?.displayName || "",
      studentId: userData?.studentId || "",
      email: user?.email || "",
      address: userData?.address || "",
      parentMobile: userData?.parentMobile || "",
      phoneNumber: userData?.phoneNumber || "",
      branch: userData?.branch || "",
      year: userData?.year || "",
    });
    setEditModalVisible(true);
  };

  const handleToggleEditMode = () => {
    if (!editMode) {
      // Entering edit mode
      setEditForm({
        displayName: userData?.displayName || "",
        studentId: userData?.studentId || "",
        email: user?.email || "",
        address: userData?.address || "",
        parentMobile: userData?.parentMobile || "",
        phoneNumber: userData?.phoneNumber || "",
        branch: userData?.branch || "",
        year: userData?.year || "",
      });
    } else {
      // Canceling edit mode
      Alert.alert(
        "Cancel Changes",
        "Are you sure you want to cancel? Your changes will be lost.",
        [
          {
            text: "Keep Editing",
            style: "cancel",
          },
          {
            text: "Cancel Changes",
            style: "destructive",
            onPress: () => setEditMode(false),
          },
        ]
      );
      return;
    }
    setEditMode(!editMode);
  };

  const validateRollNumber = (rollNo: string): boolean => {
    if (rollNo.length !== 10) return false;
    const pattern = /^[0-9]{2}[A-Z0-9]{4}[0-9]{2}[A-Z0-9]{2}$/;
    return pattern.test(rollNo);
  };

  const handleUpdateProfile = async () => {
    if (!editForm.displayName.trim()) {
      Alert.alert("Error", "Name is required");
      return;
    }

    if (userData?.role === "student" || userData?.role === "parent") {
      if (!editForm.studentId.trim()) {
        Alert.alert("Error", "Roll Number is required");
        return;
      }

      if (!validateRollNumber(editForm.studentId)) {
        Alert.alert(
          "Invalid Roll Number",
          "Roll number must be 10 characters long in format: 234E5A0902"
        );
        return;
      }

      if (!editForm.branch.trim()) {
        Alert.alert("Error", "Branch is required");
        return;
      }

      if (!editForm.year.trim()) {
        Alert.alert("Error", "Year is required");
        return;
      }
    }

    setUpdating(true);
    try {
      const { doc, updateDoc } = await import("firebase/firestore");
      const { db } = await import("@/config/firebase");

      const userDocRef = doc(db, "users", user?.uid || "");
      const updateData: any = {
        displayName: editForm.displayName.trim(),
        address: editForm.address.trim(),
        parentMobile: editForm.parentMobile.trim(),
        phoneNumber: editForm.phoneNumber.trim(),
      };

      // Only update student-specific fields if user is student or parent
      if (userData?.role === "student" || userData?.role === "parent") {
        updateData.studentId = editForm.studentId.toUpperCase();
        updateData.branch = editForm.branch;
        updateData.year = editForm.year;
      }

      await updateDoc(userDocRef, updateData);

      // Update user profile display name
      const { updateProfile } = await import("firebase/auth");
      if (user) {
        await updateProfile(user, {
          displayName: editForm.displayName.trim(),
        });
      }

      await refreshUserData();
      setEditModalVisible(false);
      setEditMode(false);
      Alert.alert("Success", "Profile updated successfully!");
    } catch (error) {
      console.error("Error updating profile:", error);
      Alert.alert("Error", "Failed to update profile. Please try again.");
    } finally {
      setUpdating(false);
    }
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Gradient Header mirroring Home design */}
      <LinearGradient
        colors={["#1e40af", "#3b82f6", "#60a5fa"]}
        style={styles.gradientHeader}
      >
        <View style={styles.headerTopRow}>
          <View style={styles.avatarLarge}>
            <Ionicons name="person" size={48} color="#ffffff" />
          </View>
          <TouchableOpacity
            style={[
              styles.editToggleButton,
              editMode && styles.editToggleActive,
            ]}
            onPress={handleToggleEditMode}
          >
            {editMode ? (
              <Ionicons name="close" size={18} color="#ffffff" />
            ) : (
              <Feather name="edit-3" size={18} color="#ffffff" />
            )}
            <ThemedText style={styles.editToggleText}>
              {editMode ? "Cancel" : "Edit"}
            </ThemedText>
          </TouchableOpacity>
        </View>

        <View style={styles.identityBlock}>
          <ThemedText style={styles.displayName}>
            {userData?.displayName || user?.email?.split("@")[0] || "User"}
          </ThemedText>
          {userData?.studentId && (
            <ThemedText style={styles.rollBadge}>
              {userData.studentId}
            </ThemedText>
          )}

          <View
            style={[
              styles.roleChip,
              { backgroundColor: getRoleColor(userData?.role || "student") },
            ]}
          >
            <ThemedText style={styles.roleChipText}>
              {getRoleDisplayName(userData?.role || "student").toUpperCase()}
            </ThemedText>
          </View>
          {userData?.branch && userData?.year && (
            <ThemedText style={styles.branchYearText}>
              {userData.branch} • {userData.year} Year
            </ThemedText>
          )}
          <ThemedText style={styles.emailText}>{user?.email}</ThemedText>
        </View>

        {editMode && (
          <View style={styles.editModeBanner}>
            <Ionicons
              name="information-circle-outline"
              size={16}
              color="#ffffff"
            />
            <ThemedText style={styles.editModeBannerText}>
              Edit mode active. Tap Save below to update your profile.
            </ThemedText>
          </View>
        )}
      </LinearGradient>

      <View style={styles.contentWrapper}>
        {/* Quick Actions aligned with Home */}
        <View style={styles.sectionCard}>
          <View style={styles.sectionHeaderRow}>
            <MaterialIcons name="flash-on" size={22} color="#1e40af" />
            <ThemedText style={styles.sectionTitle}>Quick Actions</ThemedText>
          </View>
          <View style={styles.quickGrid}>
            <TouchableOpacity
              style={styles.quickTile}
              onPress={() => refreshUserData?.()}
            >
              <MaterialIcons name="refresh" size={24} color="#1e40af" />
              <ThemedText style={styles.quickTileTitle}>Refresh</ThemedText>
              <ThemedText style={styles.quickTileSubtitle}>
                Sync data
              </ThemedText>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.quickTile}
              onPress={() => navigateToFeature("tracking")}
            >
              <MaterialIcons name="gps-fixed" size={24} color="#3b82f6" />
              <ThemedText style={styles.quickTileTitle}>Tracking</ThemedText>
              <ThemedText style={styles.quickTileSubtitle}>
                Live buses
              </ThemedText>
            </TouchableOpacity>
            {(userData?.role === "student" || userData?.role === "parent") && (
              <TouchableOpacity
                style={styles.quickTile}
                onPress={() => navigateToFeature("attendance")}
              >
                <MaterialIcons name="check-circle" size={24} color="#10b981" />
                <ThemedText style={styles.quickTileTitle}>
                  Attendance
                </ThemedText>
                <ThemedText style={styles.quickTileSubtitle}>
                  Daily log
                </ThemedText>
              </TouchableOpacity>
            )}
            {userData?.role === "admin" && (
              <TouchableOpacity
                style={styles.quickTile}
                onPress={() => navigateToFeature("admin")}
              >
                <MaterialIcons
                  name="admin-panel-settings"
                  size={24}
                  color="#ef4444"
                />
                <ThemedText style={styles.quickTileTitle}>Admin</ThemedText>
                <ThemedText style={styles.quickTileSubtitle}>Manage</ThemedText>
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* Profile Editable Information */}
        <View style={styles.sectionCard}>
          <View style={styles.sectionHeaderRow}>
            <MaterialIcons name="person" size={22} color="#1e40af" />
            <ThemedText style={styles.sectionTitle}>Profile Details</ThemedText>
            {editMode && (
              <TouchableOpacity
                style={[styles.savePill, updating && styles.disabledButton]}
                disabled={updating}
                onPress={handleUpdateProfile}
              >
                <Ionicons
                  name={updating ? "time-outline" : "checkmark"}
                  size={14}
                  color="#ffffff"
                />
                <ThemedText style={styles.savePillText}>
                  {updating ? "Saving" : "Save"}
                </ThemedText>
              </TouchableOpacity>
            )}
          </View>

          {/* Name */}
          <View style={styles.fieldRow}>
            <View style={styles.fieldLabelWrap}>
              <MaterialIcons name="badge" size={18} color="#6b7280" />
              <ThemedText style={styles.fieldLabel}>Full Name</ThemedText>
            </View>
            {editMode ? (
              <TextInput
                style={styles.fieldInput}
                value={editForm.displayName}
                onChangeText={(t) =>
                  setEditForm({ ...editForm, displayName: t })
                }
                placeholder="Enter full name"
              />
            ) : (
              <ThemedText style={styles.fieldValue}>
                {userData?.displayName || "Not provided"}
              </ThemedText>
            )}
          </View>

          {/* Email */}
          <View style={styles.fieldRow}>
            <View style={styles.fieldLabelWrap}>
              <MaterialIcons name="email" size={18} color="#6b7280" />
              <ThemedText style={styles.fieldLabel}>Email</ThemedText>
            </View>
            <ThemedText style={[styles.fieldValue, styles.dimValue]}>
              {user?.email}
            </ThemedText>
          </View>

          {(userData?.role === "student" || userData?.role === "parent") && (
            <>
              <View style={styles.fieldRow}>
                <View style={styles.fieldLabelWrap}>
                  <MaterialIcons name="school" size={18} color="#6b7280" />
                  <ThemedText style={styles.fieldLabel}>
                    {userData?.role === "parent" ? "Child Roll No" : "Roll No"}
                  </ThemedText>
                </View>
                <ThemedText style={styles.fieldValue}>
                  {userData?.studentId || "Not provided"}
                </ThemedText>
              </View>

              <View style={styles.fieldRow}>
                <View style={styles.fieldLabelWrap}>
                  <MaterialIcons name="business" size={18} color="#6b7280" />
                  <ThemedText style={styles.fieldLabel}>
                    {userData?.role === "parent" ? "Child Branch" : "Branch"}
                  </ThemedText>
                </View>
                {editMode ? (
                  <View style={styles.pickerFieldWrapper}>
                    <Picker
                      selectedValue={editForm.branch}
                      style={styles.inlinePicker}
                      onValueChange={(v: string) =>
                        setEditForm({ ...editForm, branch: v })
                      }
                    >
                      <Picker.Item label="Branch" value="" />
                      <Picker.Item label="CSE" value="CSE" />
                      <Picker.Item label="ECE" value="ECE" />
                      <Picker.Item label="EEE" value="EEE" />
                      <Picker.Item label="MECH" value="MECH" />
                      <Picker.Item label="CIVIL" value="CIVIL" />
                      <Picker.Item label="IT" value="IT" />
                    </Picker>
                  </View>
                ) : (
                  <ThemedText style={styles.fieldValue}>
                    {userData?.branch || "Not provided"}
                  </ThemedText>
                )}
              </View>

              <View style={styles.fieldRow}>
                <View style={styles.fieldLabelWrap}>
                  <MaterialIcons
                    name="calendar-today"
                    size={18}
                    color="#6b7280"
                  />
                  <ThemedText style={styles.fieldLabel}>
                    {userData?.role === "parent" ? "Child Year" : "Year"}
                  </ThemedText>
                </View>
                {editMode ? (
                  <View style={styles.pickerFieldWrapper}>
                    <Picker
                      selectedValue={editForm.year}
                      style={styles.inlinePicker}
                      onValueChange={(v: string) =>
                        setEditForm({ ...editForm, year: v })
                      }
                    >
                      <Picker.Item label="Year" value="" />
                      <Picker.Item label="I Year" value="I" />
                      <Picker.Item label="II Year" value="II" />
                      <Picker.Item label="III Year" value="III" />
                      <Picker.Item label="IV Year" value="IV" />
                    </Picker>
                  </View>
                ) : (
                  <ThemedText style={styles.fieldValue}>
                    {userData?.year ? `${userData.year} Year` : "Not provided"}
                  </ThemedText>
                )}
              </View>
            </>
          )}

          {/* Address */}
          <View style={[styles.fieldRow, styles.multilineRow]}>
            <View style={styles.fieldLabelWrap}>
              <MaterialIcons name="location-pin" size={20} color="#6b7280" />
              <ThemedText style={styles.fieldLabel}>Address</ThemedText>
            </View>
            {editMode ? (
              <TextInput
                style={[styles.fieldInput, styles.textArea]}
                value={editForm.address}
                onChangeText={(t) => setEditForm({ ...editForm, address: t })}
                placeholder="Enter address"
                multiline
              />
            ) : (
              <ThemedText style={styles.fieldValue}>
                {userData?.address || "Not provided"}
              </ThemedText>
            )}
          </View>

          {/* Parent Mobile */}
          <View style={styles.fieldRow}>
            <View style={styles.fieldLabelWrap}>
              <MaterialIcons name="call" size={18} color="#6b7280" />
              <ThemedText style={styles.fieldLabel}>Parent Mobile</ThemedText>
            </View>
            {editMode ? (
              <TextInput
                style={styles.fieldInput}
                value={editForm.parentMobile}
                onChangeText={(t) =>
                  setEditForm({ ...editForm, parentMobile: t })
                }
                placeholder="Parent mobile"
                keyboardType="phone-pad"
                maxLength={15}
              />
            ) : (
              <ThemedText style={styles.fieldValue}>
                {userData?.parentMobile || "Not provided"}
              </ThemedText>
            )}
          </View>

          {/* Student Mobile */}
          <View style={styles.fieldRow}>
            <View style={styles.fieldLabelWrap}>
              <MaterialIcons name="phone-android" size={18} color="#6b7280" />
              <ThemedText style={styles.fieldLabel}>Student Mobile</ThemedText>
            </View>
            {editMode ? (
              <TextInput
                style={styles.fieldInput}
                value={editForm.phoneNumber}
                onChangeText={(t) =>
                  setEditForm({ ...editForm, phoneNumber: t })
                }
                placeholder="Student mobile"
                keyboardType="phone-pad"
                maxLength={15}
              />
            ) : (
              <ThemedText style={styles.fieldValue}>
                {userData?.phoneNumber || "Not provided"}
              </ThemedText>
            )}
          </View>
        </View>

        {/* Support & Logout */}
        <View style={styles.sectionCard}>
          <View style={styles.sectionHeaderRow}>
            <MaterialIcons name="support-agent" size={22} color="#1e40af" />
            <ThemedText style={styles.sectionTitle}>Support</ThemedText>
          </View>
          <TouchableOpacity
            style={styles.supportRow}
            onPress={() =>
              Alert.alert(
                "Emergency Contact",
                "Bus Helpline: +91-9876543210\nCollege Office: +91-9876543211"
              )
            }
          >
            <MaterialIcons name="emergency" size={22} color="#ef4444" />
            <ThemedText style={styles.supportText}>
              Emergency Contacts
            </ThemedText>
            <Ionicons name="chevron-forward" size={16} color="#d1d5db" />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.supportRow}
            onPress={() =>
              Alert.alert(
                "Help & Support",
                "Contact: support@sietk.edu\nOffice Hours: 9:00 AM - 5:00 PM"
              )
            }
          >
            <MaterialIcons name="help-outline" size={22} color="#3b82f6" />
            <ThemedText style={styles.supportText}>Help & Support</ThemedText>
            <Ionicons name="chevron-forward" size={16} color="#d1d5db" />
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.logoutButton, loading && styles.disabledButton]}
            onPress={handleLogout}
            disabled={loading}
          >
            <MaterialIcons name="logout" size={22} color="#ffffff" />
            <ThemedText style={styles.logoutButtonText}>
              {loading ? "Logging out..." : "Logout"}
            </ThemedText>
          </TouchableOpacity>
        </View>

        <View style={styles.appInfo}>
          <ThemedText style={styles.appInfoText}>
            SIETK Bus Management v1.0.0
          </ThemedText>
          <ThemedText style={styles.appInfoSub}>
            © 2025 Siddharth Institution of Engineering & Technology
          </ThemedText>
        </View>
      </View>

      {/* Edit Profile Modal */}
      <Modal
        visible={editModalVisible}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setEditModalVisible(false)}
      >
        <KeyboardAvoidingView
          style={styles.modalContainer}
          behavior={Platform.OS === "ios" ? "padding" : "height"}
        >
          <View style={styles.modalHeader}>
            <TouchableOpacity
              onPress={() => setEditModalVisible(false)}
              style={styles.cancelButton}
            >
              <ThemedText style={styles.cancelText}>Cancel</ThemedText>
            </TouchableOpacity>
            <ThemedText style={styles.modalTitle}>Edit Profile</ThemedText>
            <TouchableOpacity
              onPress={handleUpdateProfile}
              disabled={updating}
              style={[styles.saveButton, updating && styles.disabledButton]}
            >
              <ThemedText style={styles.saveText}>
                {updating ? "Saving..." : "Save"}
              </ThemedText>
            </TouchableOpacity>
          </View>

          <ScrollView
            style={styles.modalContent}
            showsVerticalScrollIndicator={false}
          >
            <View style={styles.inputGroup}>
              <ThemedText style={styles.inputLabel}>Full Name *</ThemedText>
              <TextInput
                style={styles.modalInput}
                value={editForm.displayName}
                onChangeText={(text) =>
                  setEditForm({ ...editForm, displayName: text })
                }
                placeholder="Enter your full name"
                autoCapitalize="words"
              />
            </View>

            <View style={styles.inputGroup}>
              <ThemedText style={styles.inputLabel}>Roll Number *</ThemedText>
              <TextInput
                style={styles.modalInput}
                value={editForm.studentId}
                onChangeText={(text) =>
                  setEditForm({ ...editForm, studentId: text.toUpperCase() })
                }
                placeholder="234E5A0902"
                maxLength={10}
                autoCapitalize="characters"
              />
            </View>

            <View style={styles.inputGroup}>
              <ThemedText style={styles.inputLabel}>Email Address *</ThemedText>
              <TextInput
                style={[styles.modalInput, styles.disabledInput]}
                value={editForm.email}
                placeholder="Email cannot be changed"
                editable={false}
              />
              <ThemedText style={styles.helperText}>
                Email address cannot be changed for security reasons
              </ThemedText>
            </View>

            <View style={styles.inputGroup}>
              <ThemedText style={styles.inputLabel}>Address</ThemedText>
              <TextInput
                style={[styles.modalInput, styles.textArea]}
                value={editForm.address}
                onChangeText={(text) =>
                  setEditForm({ ...editForm, address: text })
                }
                placeholder="Enter your full address"
                multiline
                numberOfLines={3}
                textAlignVertical="top"
              />
            </View>

            <View style={styles.inputGroup}>
              <ThemedText style={styles.inputLabel}>
                Parent Mobile Number
              </ThemedText>
              <TextInput
                style={styles.modalInput}
                value={editForm.parentMobile}
                onChangeText={(text) =>
                  setEditForm({ ...editForm, parentMobile: text })
                }
                placeholder="+91-9876543210"
                keyboardType="phone-pad"
                maxLength={15}
              />
            </View>

            <View style={styles.noteContainer}>
              <Ionicons name="warning-outline" size={16} color="#f59e0b" />
              <ThemedText style={styles.noteText}>
                Fields marked with * are required. Make sure all information is
                accurate as it will be used for official communications.
              </ThemedText>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f8fafc",
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 40,
  },
  gradientHeader: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 32,
    borderBottomLeftRadius: 28,
    borderBottomRightRadius: 28,
  },
  headerTopRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  avatarLarge: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: "rgba(255,255,255,0.25)",
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
    borderColor: "rgba(255,255,255,0.6)",
  },
  editToggleButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.25)",
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 24,
  },
  editToggleActive: {
    backgroundColor: "rgba(239,68,68,0.9)",
  },
  editToggleText: {
    color: "#ffffff",
    fontSize: 14,
    fontWeight: "600",
    marginLeft: 8,
  },
  identityBlock: {
    marginTop: 24,
  },
  displayName: {
    fontSize: 24,
    fontWeight: "700",
    color: "#ffffff",
  },
  rollBadge: {
    fontSize: 14,
    color: "#e0f2fe",
    marginTop: 4,
    fontWeight: "600",
  },
  roleChip: {
    alignSelf: "flex-start",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    marginTop: 12,
  },
  roleChipText: {
    color: "#ffffff",
    fontSize: 12,
    fontWeight: "700",
    letterSpacing: 0.5,
  },
  branchYearText: {
    fontSize: 12,
    color: "#f0f9ff",
    marginTop: 8,
  },
  emailText: {
    fontSize: 12,
    color: "#dbeafe",
    marginTop: 4,
  },
  editModeBanner: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(0,0,0,0.25)",
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 12,
    marginTop: 20,
  },
  editModeBannerText: {
    color: "#ffffff",
    fontSize: 12,
    marginLeft: 8,
    flex: 1,
  },
  contentWrapper: {
    paddingHorizontal: 20,
    paddingTop: 24,
    paddingBottom: 40,
  },
  sectionCard: {
    backgroundColor: "#ffffff",
    borderRadius: 16,
    padding: 18,
    marginBottom: 20,
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  sectionHeaderRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 18,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#1f2937",
    marginLeft: 8,
    flex: 1,
  },
  quickGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  quickTile: {
    width: "48%",
    backgroundColor: "#f1f5f9",
    borderRadius: 14,
    padding: 14,
    marginBottom: 12,
    alignItems: "center",
  },
  quickTileTitle: {
    fontSize: 13,
    fontWeight: "600",
    color: "#1f2937",
    marginTop: 8,
  },
  quickTileSubtitle: {
    fontSize: 11,
    color: "#64748b",
    marginTop: 2,
  },
  savePill: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#10b981",
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 20,
  },
  savePillText: {
    color: "#ffffff",
    fontSize: 12,
    fontWeight: "600",
    marginLeft: 4,
  },
  fieldRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#f1f5f9",
  },
  multilineRow: {
    alignItems: "flex-start",
  },
  fieldLabelWrap: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  fieldLabel: {
    fontSize: 13,
    fontWeight: "600",
    color: "#6b7280",
    marginLeft: 8,
  },
  fieldValue: {
    fontSize: 13,
    fontWeight: "600",
    color: "#1f2937",
    flex: 1,
    textAlign: "right",
  },
  dimValue: {
    color: "#9ca3af",
  },
  fieldInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#cbd5e1",
    backgroundColor: "#ffffff",
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 8,
    fontSize: 13,
    textAlign: "right",
    fontWeight: "500",
    color: "#1f2937",
    minHeight: 40,
  },
  textArea: {
    minHeight: 80,
    textAlignVertical: "top",
  },
  pickerFieldWrapper: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#cbd5e1",
    borderRadius: 8,
    overflow: "hidden",
    backgroundColor: "#ffffff",
  },
  inlinePicker: {
    height: 40,
  },
  supportRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: "#f1f5f9",
    gap: 12,
  },
  supportText: {
    flex: 1,
    fontSize: 14,
    fontWeight: "500",
    color: "#1f2937",
  },
  logoutButton: {
    marginTop: 12,
    backgroundColor: "#ef4444",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 16,
    borderRadius: 14,
    gap: 8,
  },
  logoutButtonText: {
    fontSize: 15,
    fontWeight: "600",
    color: "#ffffff",
  },
  appInfo: {
    alignItems: "center",
    marginTop: 12,
  },
  appInfoText: {
    fontSize: 13,
    color: "#64748b",
    fontWeight: "600",
  },
  appInfoSub: {
    fontSize: 11,
    color: "#94a3b8",
    marginTop: 4,
    textAlign: "center",
  },

  // Modal Styles
  modalContainer: {
    flex: 1,
    backgroundColor: "#f8fafc",
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: "#ffffff",
    borderBottomWidth: 1,
    borderBottomColor: "#e5e7eb",
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "600",
    color: "#1f2937",
  },
  cancelButton: {
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  cancelText: {
    fontSize: 16,
    color: "#6b7280",
  },
  saveButton: {
    paddingVertical: 8,
    paddingHorizontal: 12,
    backgroundColor: "#3b82f6",
    borderRadius: 8,
  },
  saveText: {
    fontSize: 16,
    color: "#ffffff",
    fontWeight: "600",
  },
  modalContent: {
    flex: 1,
    padding: 20,
  },
  inputGroup: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: "500",
    color: "#374151",
    marginBottom: 8,
  },
  modalInput: {
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 16,
    backgroundColor: "#ffffff",
    color: "#1f2937",
  },
  disabledInput: {
    backgroundColor: "#f9fafb",
    color: "#9ca3af",
  },
  helperText: {
    fontSize: 12,
    color: "#6b7280",
    marginTop: 4,
  },
  noteContainer: {
    flexDirection: "row",
    alignItems: "flex-start",
    backgroundColor: "#fef3c7",
    padding: 12,
    borderRadius: 8,
    marginTop: 10,
  },
  noteText: {
    fontSize: 12,
    color: "#92400e",
    marginLeft: 8,
    flex: 1,
    lineHeight: 16,
  },
  disabledButton: { opacity: 0.6 },
});
