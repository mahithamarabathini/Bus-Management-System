import { MaterialIcons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  Dimensions,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  View,
} from "react-native";

import { ThemedText } from "@/components/ThemedText";
import { useAuth } from "@/contexts/AuthContext";

const { width } = Dimensions.get("window");

export default function HomeScreen() {
  const { user, userData, logout } = useAuth();
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  const handleLogout = async () => {
    Alert.alert("Logout Confirmation", "Are you sure you want to logout?", [
      {
        text: "Cancel",
        style: "cancel",
      },
      {
        text: "Logout",
        style: "destructive",
        onPress: async () => {
          try {
            setLoading(true);
            await logout();
            // Navigation will be handled by the AuthContext
          } catch (error) {
            console.error("Logout error:", error);
            Alert.alert("Error", "Failed to logout. Please try again.");
          } finally {
            setLoading(false);
          }
        },
      },
    ]);
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case "student":
        return "school";
      case "bus_incharge":
        return "directions-bus";
      case "parent":
        return "family-restroom";
      case "admin":
        return "admin-panel-settings";
      default:
        return "person";
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case "student":
        return "#22c55e";
      case "bus_incharge":
        return "#f59e0b";
      case "parent":
        return "#8b5cf6";
      case "admin":
        return "#ef4444";
      default:
        return "#6b7280";
    }
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good Morning";
    if (hour < 17) return "Good Afternoon";
    return "Good Evening";
  };

  const navigateToFeature = (route: string) => {
    try {
      console.log("Attempting to navigate to:", route);

      // Just use push with type assertion - it's the simplest approach
      router.push(route as any);
    } catch (error) {
      console.error("Navigation error:", error);
      Alert.alert("Navigation Error", "Could not navigate to that screen.");
    }
  };

  const quickActions = [
    {
      title: "Live Map",
      subtitle: "Routes & Buses",
      icon: "map" as const,
      color: "#1e40af",
      route: "map",
      roles: ["student", "parent", "bus_incharge", "admin"],
    },
    {
      title: "Attendance",
      subtitle: "Mark your attendance",
      icon: "check-circle" as const,
      color: "#8b5cf6",
      route: "attendance",
      roles: ["student"],
    },
    {
      title: "Admin Panel",
      subtitle: "User administration",
      icon: "people" as const,
      color: "#ef4444",
      route: "admin/users",
      roles: ["admin"],
    },
  ];

  const filteredActions = quickActions.filter((action) =>
    action.roles.includes(userData?.role || "student")
  );

  const identityRoleColor =
    (userData?.role && getRoleColor(userData.role)) || "#1e40af";
  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {/* Gradient Header updated to mirror Profile */}
      <LinearGradient
        colors={["#1e40af", "#3b82f6", "#60a5fa"]}
        style={styles.gradientHeader}
      >
        <View style={styles.headerTopRow}>
          <View style={styles.avatarLarge}>
            <MaterialIcons
              name={getRoleIcon(userData?.role || "student")}
              size={42}
              color="#ffffff"
            />
          </View>
          <View style={styles.headerActions}>
            <TouchableOpacity
              style={styles.headerIconButton}
              onPress={() =>
                Alert.alert("Notifications", "No new notifications")
              }
            >
              <MaterialIcons
                name="notifications-none"
                size={22}
                color="#ffffff"
              />
            </TouchableOpacity>
          </View>
        </View>
        <View style={styles.identityBlock}>
          <ThemedText style={styles.displayName}>
            {userData?.displayName || user?.email?.split("@")[0] || "User"}
          </ThemedText>
          {userData?.studentId && (
            <ThemedText style={styles.rollBadge}>
              {userData.studentId}
            </ThemedText>
          )}
          <View
            style={[styles.roleChip, { backgroundColor: identityRoleColor }]}
          >
            <ThemedText style={styles.roleChipText}>
              {(userData?.role || "student").replace("_", " ").toUpperCase()}
            </ThemedText>
          </View>
          {userData?.branch && userData?.year && (
            <ThemedText style={styles.branchYearText}>
              {userData.branch} • {userData.year} Year
            </ThemedText>
          )}
          <ThemedText style={styles.emailText}>{user?.email}</ThemedText>
        </View>
      </LinearGradient>
      <View style={styles.contentWrapper}>
        {/* Quick Actions unified styling */}
        <View style={styles.sectionCard}>
          <View style={styles.sectionHeaderRow}>
            <MaterialIcons name="flash-on" size={22} color="#1e40af" />
            <ThemedText style={styles.sectionTitle}>Quick Actions</ThemedText>
          </View>
          <View style={styles.quickGrid}>
            {filteredActions.map((action, idx) => (
              <TouchableOpacity
                key={idx}
                style={styles.quickTile}
                onPress={() => navigateToFeature(action.route)}
              >
                <MaterialIcons
                  name={action.icon}
                  size={24}
                  color={action.color}
                />
                <ThemedText style={styles.quickTileTitle}>
                  {action.title}
                </ThemedText>
                <ThemedText style={styles.quickTileSubtitle}>
                  {action.subtitle}
                </ThemedText>
              </TouchableOpacity>
            ))}
          </View>
        </View>
        {/* Information Card */}
        <View style={styles.sectionCard}>
          <View style={styles.sectionHeaderRow}>
            <MaterialIcons name="person" size={22} color="#1e40af" />
            <ThemedText style={styles.sectionTitle}>Overview</ThemedText>
          </View>
          <View style={styles.infoList}>
            <View style={styles.fieldRow}>
              <View style={styles.fieldLabelWrap}>
                <MaterialIcons name="email" size={18} color="#6b7280" />
                <ThemedText style={styles.fieldLabel}>Email</ThemedText>
              </View>
              <ThemedText style={[styles.fieldValue, styles.dimValue]}>
                {user?.email}
              </ThemedText>
            </View>
            {userData?.branch && (
              <View style={styles.fieldRow}>
                <View style={styles.fieldLabelWrap}>
                  <MaterialIcons name="business" size={18} color="#6b7280" />
                  <ThemedText style={styles.fieldLabel}>Branch</ThemedText>
                </View>
                <ThemedText style={styles.fieldValue}>
                  {userData.branch}
                </ThemedText>
              </View>
            )}
            {userData?.year && (
              <View style={styles.fieldRow}>
                <View style={styles.fieldLabelWrap}>
                  <MaterialIcons
                    name="calendar-today"
                    size={18}
                    color="#6b7280"
                  />
                  <ThemedText style={styles.fieldLabel}>Year</ThemedText>
                </View>
                <ThemedText style={styles.fieldValue}>
                  {userData.year} Year
                </ThemedText>
              </View>
            )}
            {userData?.busNumber && (
              <View style={styles.fieldRow}>
                <View style={styles.fieldLabelWrap}>
                  <MaterialIcons
                    name="directions-bus"
                    size={18}
                    color="#6b7280"
                  />
                  <ThemedText style={styles.fieldLabel}>Bus Number</ThemedText>
                </View>
                <ThemedText style={styles.fieldValue}>
                  {userData.busNumber}
                </ThemedText>
              </View>
            )}
          </View>
        </View>
        {/* Support */}
        <View style={styles.sectionCard}>
          <View style={styles.sectionHeaderRow}>
            <MaterialIcons name="support-agent" size={22} color="#1e40af" />
            <ThemedText style={styles.sectionTitle}>Support</ThemedText>
          </View>
          <TouchableOpacity
            style={styles.supportRow}
            onPress={() =>
              Alert.alert(
                "Emergency Contact",
                "Bus Helpline: +91-9876543210\nCollege Office: +91-9876543211"
              )
            }
          >
            <MaterialIcons name="emergency" size={22} color="#ef4444" />
            <ThemedText style={styles.supportText}>
              Emergency Contacts
            </ThemedText>
            <MaterialIcons name="chevron-right" size={16} color="#d1d5db" />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.supportRow}
            onPress={() =>
              Alert.alert(
                "Help & Support",
                "Contact: support@sietk.edu\nOffice Hours: 9:00 AM - 5:00 PM"
              )
            }
          >
            <MaterialIcons name="help-outline" size={22} color="#3b82f6" />
            <ThemedText style={styles.supportText}>Help & Support</ThemedText>
            <MaterialIcons name="chevron-right" size={16} color="#d1d5db" />
          </TouchableOpacity>
        </View>
        {/* Logout */}
        <View style={styles.sectionCard}>
          <TouchableOpacity
            style={[styles.logoutButton, loading && styles.disabledButton]}
            disabled={loading}
            onPress={handleLogout}
          >
            <MaterialIcons name="logout" size={22} color="#ffffff" />
            <ThemedText style={styles.logoutButtonText}>
              {loading ? "Logging out..." : "Logout"}
            </ThemedText>
          </TouchableOpacity>
        </View>
        <View style={styles.appInfo}>
          <ThemedText style={styles.appInfoText}>
            SIETK Bus Management v1.0.0
          </ThemedText>
          <ThemedText style={styles.appInfoSub}>
            © 2025 Siddharth Institution of Engineering & Technology
          </ThemedText>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f8fafc",
  },
  gradientHeader: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 32,
    borderBottomLeftRadius: 28,
    borderBottomRightRadius: 28,
  },
  headerTopRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  avatarLarge: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: "rgba(255,255,255,0.25)",
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
    borderColor: "rgba(255,255,255,0.6)",
  },
  headerActions: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  headerIconButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "rgba(255,255,255,0.25)",
    justifyContent: "center",
    alignItems: "center",
  },
  identityBlock: {
    marginTop: 20,
  },
  displayName: {
    fontSize: 24,
    fontWeight: "700",
    color: "#ffffff",
  },
  rollBadge: {
    fontSize: 14,
    color: "#e0f2fe",
    marginTop: 4,
    fontWeight: "600",
  },
  roleChip: {
    alignSelf: "flex-start",
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    marginTop: 12,
  },
  roleChipText: {
    color: "#ffffff",
    fontSize: 12,
    fontWeight: "700",
    letterSpacing: 0.5,
  },
  branchYearText: {
    fontSize: 12,
    color: "#f0f9ff",
    marginTop: 8,
  },
  emailText: {
    fontSize: 12,
    color: "#dbeafe",
    marginTop: 4,
  },
  contentWrapper: {
    paddingHorizontal: 20,
    paddingTop: 24,
    paddingBottom: 40,
  },
  sectionCard: {
    backgroundColor: "#ffffff",
    borderRadius: 16,
    padding: 18,
    marginBottom: 20,
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  sectionHeaderRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 18,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#1f2937",
    marginLeft: 8,
    flex: 1,
  },
  quickGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  quickTile: {
    width: "48%",
    backgroundColor: "#f1f5f9",
    borderRadius: 14,
    padding: 14,
    marginBottom: 12,
    alignItems: "center",
  },
  quickTileTitle: {
    fontSize: 13,
    fontWeight: "600",
    color: "#1f2937",
    marginTop: 8,
  },
  quickTileSubtitle: {
    fontSize: 11,
    color: "#64748b",
    marginTop: 2,
  },
  infoList: {},
  fieldRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: "#f1f5f9",
  },
  fieldLabelWrap: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  fieldLabel: {
    fontSize: 13,
    fontWeight: "600",
    color: "#6b7280",
    marginLeft: 8,
  },
  fieldValue: {
    fontSize: 13,
    fontWeight: "600",
    color: "#1f2937",
    flex: 1,
    textAlign: "right",
  },
  dimValue: {
    color: "#9ca3af",
  },
  supportRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: "#f1f5f9",
    gap: 12,
  },
  supportText: {
    flex: 1,
    fontSize: 14,
    fontWeight: "500",
    color: "#1f2937",
  },
  logoutButton: {
    backgroundColor: "#ef4444",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 16,
    borderRadius: 14,
    gap: 8,
  },
  logoutButtonText: {
    fontSize: 15,
    fontWeight: "600",
    color: "#ffffff",
  },
  disabledButton: {
    backgroundColor: "#9ca3af",
  },
  appInfo: {
    alignItems: "center",
    marginTop: 12,
  },
  appInfoText: {
    fontSize: 13,
    color: "#64748b",
    fontWeight: "600",
  },
  appInfoSub: {
    fontSize: 11,
    color: "#94a3b8",
    marginTop: 4,
    textAlign: "center",
  },
});
