import MapAdapter from "@/components/maps/MapAdapter";
import { ThemedText } from "@/components/ThemedText";
import { db } from "@/config/firebase";
import { useAuth } from "@/contexts/AuthContext";
import { BusLocationUpdate } from "@/services/LocationService";
import { OSRMProvider } from "@/services/routing/osrm";
import { MaterialIcons } from "@expo/vector-icons";
import { collection, onSnapshot, query } from "firebase/firestore";
import React, { useEffect, useState } from "react";
import {
  Dimensions,
  FlatList,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

interface BusStop {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  order: number;
}

interface BusRoute {
  id: string;
  name: string;
  busNumber: string;
  stops: BusStop[];
  color: string;
  isActive: boolean;
}

interface LiveBusData extends BusLocationUpdate {
  id: string;
  route?: BusRoute;
}

const { width, height } = Dimensions.get("window");
const ASPECT_RATIO = width / height;
const LATITUDE_DELTA = 0.05;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;

export default function RouteMapScreen() {
  const { userData } = useAuth();
  const [routes, setRoutes] = useState<BusRoute[]>([]);
  const [liveBuses, setLiveBuses] = useState<LiveBusData[]>([]);
  const [selectedRoute, setSelectedRoute] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [showBusList, setShowBusList] = useState(false);
  const [showRoutesList, setShowRoutesList] = useState(false);
  const [viewMode, setViewMode] = useState<"map" | "list">("map");
  const [mapRegion, setMapRegion] = useState({
    latitude: 17.145, // SIETK coordinates
    longitude: 81.804,
    latitudeDelta: LATITUDE_DELTA,
    longitudeDelta: LONGITUDE_DELTA,
  });
  const [routeGeometries, setRouteGeometries] = useState<
    Record<
      string,
      {
        coords: { latitude: number; longitude: number }[];
        distance: number;
        duration: number;
      }
    >
  >({});
  const insets = useSafeAreaInsets?.() || ({ top: 0, bottom: 0 } as any);

  useEffect(() => {
    setupRouteListener();
    setupLiveBusListener();
  }, []);

  const setupRouteListener = () => {
    const routesRef = collection(db, "routes");
    const unsubscribe = onSnapshot(routesRef, (snapshot: any) => {
      const routeData: BusRoute[] = [];
      snapshot.forEach((doc: any) => {
        routeData.push({
          id: doc.id,
          ...(doc.data() as any),
        } as BusRoute);
      });
      setRoutes(routeData);
      setLoading(false);
    });

    return unsubscribe;
  };

  const setupLiveBusListener = () => {
    const busLocationsRef = collection(db, "busLocations");
    const busQuery = query(busLocationsRef);

    const unsubscribe = onSnapshot(busQuery, async (snapshot: any) => {
      const busData: LiveBusData[] = [];

      for (const docSnapshot of snapshot.docs) {
        const data = docSnapshot.data() as BusLocationUpdate;
        if (data.isActive) {
          // Fetch route information for this bus
          const route = await getBusRoute(data.busNumber);
          busData.push({
            id: docSnapshot.id,
            ...data,
            route,
          });
        }
      }

      // Sort manually in JS instead of using Firestore query ordering
      busData.sort((a, b) => {
        const timeA = (a.lastUpdated?.toDate?.() as Date) || new Date(0);
        const timeB = (b.lastUpdated?.toDate?.() as Date) || new Date(0);
        return timeB.getTime() - timeA.getTime(); // Descending - newest first
      });

      setLiveBuses(busData);
    });

    return unsubscribe;
  };

  const getBusRoute = async (
    busNumber: string
  ): Promise<BusRoute | undefined> => {
    try {
      const routesRef = collection(db, "routes");
      const q = query(routesRef);
      const snapshot: any = await new Promise<any>((resolve) => {
        const unsubscribe = onSnapshot(q, (snap: any) => {
          unsubscribe();
          resolve(snap);
        });
      });

      for (const doc of snapshot.docs) {
        const route = doc.data() as BusRoute;
        if ((route as any).busNumber === busNumber) {
          return { ...(route as any), id: doc.id } as BusRoute;
        }
      }
    } catch (error) {
      console.error("Error fetching route for bus:", error);
    }
    return undefined;
  };

  const handleRouteSelect = (routeId: string) => {
    const route = routes.find((r) => r.id === routeId);
    if (route && route.stops.length > 0) {
      setSelectedRoute(routeId);

      // Center map on route
      const latitudes = route.stops.map((stop) => stop.latitude);
      const longitudes = route.stops.map((stop) => stop.longitude);

      const minLat = Math.min(...latitudes);
      const maxLat = Math.max(...latitudes);
      const minLng = Math.min(...longitudes);
      const maxLng = Math.max(...longitudes);

      const centerLat = (minLat + maxLat) / 2;
      const centerLng = (minLng + maxLng) / 2;
      const deltaLat = (maxLat - minLat) * 1.2; // Add padding
      const deltaLng = (maxLng - minLng) * 1.2;

      setMapRegion({
        latitude: centerLat,
        longitude: centerLng,
        latitudeDelta: Math.max(deltaLat, 0.01),
        longitudeDelta: Math.max(deltaLng, 0.01),
      });
    }
  };

  const getSelectedRoute = (): BusRoute | null => {
    return selectedRoute
      ? routes.find((r) => r.id === selectedRoute) || null
      : null;
  };

  const getRouteCoordinates = (route: BusRoute) => {
    return route.stops
      .sort((a, b) => a.order - b.order)
      .map((stop) => ({
        latitude: stop.latitude,
        longitude: stop.longitude,
      }));
  };

  const getBusIcon = (bus: LiveBusData) => {
    // You can customize this based on bus status, route, etc.
    return "🚌";
  };

  const formatLastUpdated = (timestamp: any): string => {
    if (!timestamp || !timestamp.toDate) return "Unknown";

    const date = timestamp.toDate();
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMinutes = Math.floor(diffMs / (1000 * 60));

    if (diffMinutes < 1) return "Just now";
    if (diffMinutes < 60) return `${diffMinutes}m ago`;

    const diffHours = Math.floor(diffMinutes / 60);
    return `${diffHours}h ago`;
  };

  const getBusStatus = (
    bus: LiveBusData
  ): { status: string; color: string } => {
    const speed = bus.location.speed || 0;
    if (speed > 0.5) return { status: "Moving", color: "#10b981" };
    if (speed <= 0.5 && speed >= 0)
      return { status: "Stopped", color: "#f59e0b" };
    return { status: "Unknown", color: "#6b7280" };
  };

  const renderBusListItem = ({ item }: { item: LiveBusData }) => {
    const status = getBusStatus(item);
    return (
      <TouchableOpacity
        style={styles.busListItem}
        onPress={() => {
          // Focus on bus location
          setMapRegion({
            latitude: item.location.latitude,
            longitude: item.location.longitude,
            latitudeDelta: 0.01,
            longitudeDelta: 0.01,
          });
          setShowBusList(false);
        }}
      >
        <View style={styles.busItemHeader}>
          <View style={styles.busItemLeft}>
            <MaterialIcons name="directions-bus" size={24} color="#1e40af" />
            <View style={styles.busItemInfo}>
              <Text style={styles.busItemNumber}>Bus {item.busNumber}</Text>
              <Text style={styles.busItemRoute}>
                {item.route?.name || "No Route Assigned"}
              </Text>
            </View>
          </View>
          <View style={[styles.statusBadge, { backgroundColor: status.color }]}>
            <Text style={styles.statusText}>{status.status}</Text>
          </View>
        </View>

        <View style={styles.busItemDetails}>
          <View style={styles.busDetailRow}>
            <MaterialIcons name="speed" size={16} color="#6b7280" />
            <Text style={styles.busDetailText}>
              {item.location.speed
                ? `${(item.location.speed * 3.6).toFixed(1)} km/h`
                : "0 km/h"}
            </Text>
          </View>
          <View style={styles.busDetailRow}>
            <MaterialIcons name="schedule" size={16} color="#6b7280" />
            <Text style={styles.busDetailText}>
              Updated: {formatLastUpdated(item.lastUpdated)}
            </Text>
          </View>
          <View style={styles.busDetailRow}>
            <MaterialIcons name="place" size={16} color="#6b7280" />
            <Text style={styles.busDetailText}>
              {item.location.latitude.toFixed(4)},{" "}
              {item.location.longitude.toFixed(4)}
            </Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  const renderRouteListItem = ({ item }: { item: BusRoute }) => (
    <TouchableOpacity
      style={[
        styles.routeListItem,
        selectedRoute === item.id && styles.selectedRouteListItem,
      ]}
      onPress={() => {
        handleRouteSelect(item.id);
        setShowRoutesList(false);
      }}
    >
      <View style={styles.routeItemHeader}>
        <View style={styles.routeItemLeft}>
          <View
            style={[
              styles.routeColorIndicator,
              { backgroundColor: item.color },
            ]}
          />
          <View style={styles.routeItemInfo}>
            <Text style={styles.routeItemName}>{item.name}</Text>
            <Text style={styles.routeItemNumber}>Bus: {item.busNumber}</Text>
          </View>
        </View>
        <View style={styles.routeItemRight}>
          <View
            style={[
              styles.routeStatusBadge,
              { backgroundColor: item.isActive ? "#10b981" : "#ef4444" },
            ]}
          >
            <Text style={styles.routeStatusText}>
              {item.isActive ? "Active" : "Inactive"}
            </Text>
          </View>
        </View>
      </View>

      <View style={styles.routeItemDetails}>
        <View style={styles.routeDetailRow}>
          <MaterialIcons name="alt-route" size={16} color="#6b7280" />
          <Text style={styles.routeDetailText}>{item.stops.length} stops</Text>
        </View>
        {item.stops.length > 0 && (
          <View style={styles.routeStops}>
            <Text style={styles.routeStopsTitle}>Route Stops:</Text>
            {item.stops
              .sort((a, b) => a.order - b.order)
              .slice(0, 3)
              .map((stop, index) => (
                <Text key={stop.id} style={styles.routeStopName}>
                  {index + 1}. {stop.name}
                </Text>
              ))}
            {item.stops.length > 3 && (
              <Text style={styles.routeStopsMore}>
                +{item.stops.length - 3} more stops
              </Text>
            )}
          </View>
        )}
      </View>
    </TouchableOpacity>
  );

  const buildRoadGeometryForRoute = async (route: BusRoute) => {
    try {
      const orderedStops = [...route.stops].sort((a, b) => a.order - b.order);
      if (orderedStops.length < 2) return;
      // Build successive legs to keep OSRM URL length manageable & ensure snapping through each stop
      let fullPath: { latitude: number; longitude: number }[] = [];
      for (let i = 0; i < orderedStops.length - 1; i++) {
        const from = orderedStops[i];
        const to = orderedStops[i + 1];
        const result = await OSRMProvider.getRoute([
          { latitude: from.latitude, longitude: from.longitude },
          { latitude: to.latitude, longitude: to.longitude },
        ]);
        const leg = result.geometry.map((p) => ({
          latitude: p.latitude,
          longitude: p.longitude,
        }));
        if (i === 0) fullPath.push(...leg);
        else fullPath.push(...leg.slice(1)); // avoid duplicating joint point
      }
      setRouteGeometries((prev) => ({
        ...prev,
        [route.id]: { coords: fullPath, distance: 0, duration: 0 },
      }));
    } catch (e) {
      console.warn("Road geometry build failed for route", route.id, e);
    }
  };

  useEffect(() => {
    // Auto-build geometry when routes change (once per route)
    routes.forEach((r) => {
      if (!routeGeometries[r.id] && r.stops?.length > 1) {
        buildRoadGeometryForRoute(r);
      }
    });
  }, [routes]);

  const selectedRouteObj = getSelectedRoute();

  return (
    <View style={[styles.container, { paddingTop: insets.top ? 0 : 0 }]}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <MaterialIcons name="map" size={24} color="#1e40af" />
          <ThemedText style={styles.headerTitle}>
            Bus Routes & Tracking
          </ThemedText>
        </View>
        <View style={styles.headerRight}>
          <TouchableOpacity
            style={[
              styles.viewModeButton,
              viewMode === "map" && styles.activeViewMode,
            ]}
            onPress={() => setViewMode("map")}
          >
            <MaterialIcons
              name="map"
              size={20}
              color={viewMode === "map" ? "#ffffff" : "#6b7280"}
            />
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.viewModeButton,
              viewMode === "list" && styles.activeViewMode,
            ]}
            onPress={() => setViewMode("list")}
          >
            <MaterialIcons
              name="list"
              size={20}
              color={viewMode === "list" ? "#ffffff" : "#6b7280"}
            />
          </TouchableOpacity>
        </View>
      </View>

      {viewMode === "map" ? (
        <>
          {/* Map */}
          <MapAdapter
            style={styles.map}
            mode="web"
            region={mapRegion}
            showUserLocation={true}
            stops={selectedRouteObj?.stops || []}
            buses={liveBuses}
            routeCoordinates={
              selectedRouteObj
                ? routeGeometries[selectedRouteObj.id]?.coords ||
                  getRouteCoordinates(selectedRouteObj)
                : []
            }
            routeColor={selectedRouteObj?.color || "#007AFF"}
            onError={() => console.error("Error loading map in main screen")}
          />

          {/* Control Panel */}
          <View style={styles.controlPanelRow}>
            <TouchableOpacity
              style={styles.ctrlPill}
              onPress={() => setShowBusList(true)}
            >
              <MaterialIcons name="directions-bus" size={18} color="#1e40af" />
              <Text style={styles.ctrlPillText}>Buses</Text>
              <Text style={styles.ctrlBadge}>{liveBuses.length}</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.ctrlPill}
              onPress={() => setShowRoutesList(true)}
            >
              <MaterialIcons name="alt-route" size={18} color="#1e40af" />
              <Text style={styles.ctrlPillText}>Routes</Text>
              <Text style={styles.ctrlBadge}>{routes.length}</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.ctrlPill,
                !selectedRoute && styles.ctrlPillDisabled,
              ]}
              onPress={() => setSelectedRoute(null)}
              disabled={!selectedRoute}
            >
              <MaterialIcons
                name="clear-all"
                size={18}
                color={selectedRoute ? "#ef4444" : "#94a3b8"}
              />
              <Text
                style={[
                  styles.ctrlPillText,
                  { color: selectedRoute ? "#ef4444" : "#94a3b8" },
                ]}
              >
                Clear
              </Text>
            </TouchableOpacity>
          </View>

          {/* Route Chips + Live Info */}
          <View
            style={[
              styles.bottomPanelRaised,
              {
                paddingBottom: Math.max(12, 12 + (insets.bottom || 0) * 0.3),
              },
            ]}
          >
            {/* Route summary */}
            {selectedRouteObj && (
              <View style={styles.routeSummary}>
                <View style={styles.routeSummaryLeft}>
                  <View
                    style={[
                      styles.routeSummaryColor,
                      { backgroundColor: selectedRouteObj.color },
                    ]}
                  />
                  <View style={{ flex: 1 }}>
                    <Text style={styles.routeSummaryTitle} numberOfLines={1}>
                      {selectedRouteObj.name}
                    </Text>
                    <Text style={styles.routeSummaryMeta} numberOfLines={1}>
                      {selectedRouteObj.stops.length} stops • Bus{" "}
                      {selectedRouteObj.busNumber}
                    </Text>
                  </View>
                </View>
                <TouchableOpacity
                  onPress={() => setSelectedRoute(null)}
                  style={styles.routeSummaryClear}
                >
                  <MaterialIcons name="close" size={18} color="#64748b" />
                </TouchableOpacity>
              </View>
            )}
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{ paddingRight: 4 }}
            >
              <TouchableOpacity
                style={[
                  styles.routeChip,
                  !selectedRoute && styles.routeChipActive,
                ]}
                onPress={() => setSelectedRoute(null)}
              >
                <View style={styles.routeChipRow}>
                  <MaterialIcons
                    name="all-inclusive"
                    size={14}
                    color={!selectedRoute ? "#ffffff" : "#475569"}
                  />
                  <Text
                    style={[
                      styles.routeChipText,
                      !selectedRoute && styles.routeChipTextActive,
                    ]}
                  >
                    All Buses
                  </Text>
                  <Text
                    style={[
                      styles.routeChipBadge,
                      !selectedRoute && styles.routeChipBadgeActive,
                    ]}
                  >
                    {liveBuses.length}
                  </Text>
                </View>
              </TouchableOpacity>
              {routes.map((route) => (
                <TouchableOpacity
                  key={route.id}
                  style={[
                    styles.routeChip,
                    selectedRoute === route.id && styles.routeChipActive,
                  ]}
                  onPress={() => handleRouteSelect(route.id)}
                >
                  <View style={styles.routeChipRow}>
                    <View
                      style={[
                        styles.colorDot,
                        { backgroundColor: route.color },
                      ]}
                    />
                    <Text
                      numberOfLines={1}
                      style={[
                        styles.routeChipText,
                        selectedRoute === route.id &&
                          styles.routeChipTextActive,
                      ]}
                    >
                      {route.name}
                    </Text>
                    <Text
                      style={[
                        styles.routeChipBadge,
                        selectedRoute === route.id &&
                          styles.routeChipBadgeActive,
                      ]}
                    >
                      {route.stops.length}
                    </Text>
                  </View>
                  <Text
                    style={[
                      styles.routeChipSub,
                      selectedRoute === route.id && styles.routeChipTextActive,
                    ]}
                  >
                    {route.busNumber}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            {liveBuses.length > 0 && (
              <View style={styles.busInfoRow}>
                <Text style={styles.busInfoRowTitle}>Live Buses:</Text>
                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={{ paddingLeft: 4 }}
                >
                  {liveBuses.map((bus) => (
                    <View key={bus.id} style={styles.busPill}>
                      <Text style={styles.busPillText}>{bus.busNumber}</Text>
                      <Text style={styles.busPillSub}>
                        {bus.location.speed
                          ? `${(bus.location.speed * 3.6).toFixed(0)}km/h`
                          : "0km/h"}
                      </Text>
                    </View>
                  ))}
                </ScrollView>
              </View>
            )}
          </View>
          {/* Legend */}
          <View style={styles.legend}>
            <View style={styles.legendItem}>
              <Text style={styles.legendIcon}>🚌</Text>
              <Text style={styles.legendText}>Live Bus</Text>
            </View>
            <View style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: "red" }]} />
              <Text style={styles.legendText}>Bus Stop</Text>
            </View>
            <View style={styles.legendItem}>
              <View
                style={[styles.legendLine, { backgroundColor: "#007AFF" }]}
              />
              <Text style={styles.legendText}>Route</Text>
            </View>
          </View>
        </>
      ) : (
        // List View
        <View style={styles.listContainer}>
          <View style={styles.listTabBar}>
            <TouchableOpacity
              style={[styles.listTab, styles.activeListTab]}
              onPress={() => {}}
            >
              <MaterialIcons name="directions-bus" size={20} color="#ffffff" />
              <Text style={styles.listTabText}>
                Live Buses ({liveBuses.length})
              </Text>
            </TouchableOpacity>
          </View>

          <FlatList
            data={liveBuses}
            renderItem={renderBusListItem}
            keyExtractor={(item) => item.id}
            contentContainerStyle={styles.listContent}
            showsVerticalScrollIndicator={false}
            ListEmptyComponent={
              <View style={styles.emptyState}>
                <MaterialIcons
                  name="directions-bus-filled"
                  size={48}
                  color="#d1d5db"
                />
                <Text style={styles.emptyStateText}>
                  No buses are currently active
                </Text>
                <Text style={styles.emptyStateSubtext}>
                  Buses will appear here when they start tracking
                </Text>
              </View>
            }
          />
        </View>
      )}

      {/* Buses List Modal */}
      <Modal
        visible={showBusList}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowBusList(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <View style={styles.modalHeaderLeft}>
              <MaterialIcons name="directions-bus" size={24} color="#1e40af" />
              <Text style={styles.modalTitle}>
                Live Buses ({liveBuses.length})
              </Text>
            </View>
            <TouchableOpacity
              onPress={() => setShowBusList(false)}
              style={styles.modalCloseButton}
            >
              <MaterialIcons name="close" size={24} color="#6b7280" />
            </TouchableOpacity>
          </View>

          <FlatList
            data={liveBuses}
            renderItem={renderBusListItem}
            keyExtractor={(item) => item.id}
            contentContainerStyle={styles.modalListContent}
            showsVerticalScrollIndicator={false}
            ListEmptyComponent={
              <View style={styles.emptyState}>
                <MaterialIcons
                  name="directions-bus-filled"
                  size={48}
                  color="#d1d5db"
                />
                <Text style={styles.emptyStateText}>
                  No buses are currently active
                </Text>
              </View>
            }
          />
        </View>
      </Modal>

      {/* Routes List Modal */}
      <Modal
        visible={showRoutesList}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowRoutesList(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <View style={styles.modalHeaderLeft}>
              <MaterialIcons name="alt-route" size={24} color="#1e40af" />
              <Text style={styles.modalTitle}>
                All Routes ({routes.length})
              </Text>
            </View>
            <TouchableOpacity
              onPress={() => setShowRoutesList(false)}
              style={styles.modalCloseButton}
            >
              <MaterialIcons name="close" size={24} color="#6b7280" />
            </TouchableOpacity>
          </View>

          <FlatList
            data={routes}
            renderItem={renderRouteListItem}
            keyExtractor={(item) => item.id}
            contentContainerStyle={styles.modalListContent}
            showsVerticalScrollIndicator={false}
            ListEmptyComponent={
              <View style={styles.emptyState}>
                <MaterialIcons name="alt-route" size={48} color="#d1d5db" />
                <Text style={styles.emptyStateText}>No routes configured</Text>
              </View>
            }
          />
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f8fafc",
  },

  // Header Styles
  header: {
    backgroundColor: "#ffffff",
    paddingHorizontal: 20,
    paddingTop: 50,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#e5e7eb",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  headerLeft: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#1f2937",
    marginLeft: 8,
  },
  headerRight: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  viewModeButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "#f3f4f6",
    justifyContent: "center",
    alignItems: "center",
  },
  activeViewMode: {
    backgroundColor: "#1e40af",
  },

  // Map Styles
  map: {
    flex: 1,
  },

  // Control Panel
  controlPanelRow: {
    position: "absolute",
    top: 118,
    left: 12,
    right: 12,
    flexDirection: "row",
    gap: 8,
    zIndex: 20,
  },
  ctrlPill: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#ffffff",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: "#e2e8f0",
    shadowColor: "#000",
    shadowOpacity: 0.08,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    elevation: 2,
  },
  ctrlPillDisabled: { opacity: 0.5 },
  ctrlPillText: {
    fontSize: 12,
    fontWeight: "600",
    color: "#1e293b",
    marginLeft: 6,
  },
  ctrlBadge: {
    marginLeft: 6,
    backgroundColor: "#1e40af",
    color: "#ffffff",
    fontSize: 10,
    fontWeight: "700",
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 8,
    overflow: "hidden",
  },

  // Bottom Panel
  bottomPanelRaised: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "rgba(255,255,255,0.95)",
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderTopLeftRadius: 22,
    borderTopRightRadius: 22,
    borderWidth: 1,
    borderColor: "#e2e8f0",
    shadowColor: "#000",
    shadowOpacity: 0.18,
    shadowOffset: { width: 0, height: -2 },
    shadowRadius: 10,
    elevation: 14,
  },
  routeSummary: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#ffffff",
    borderRadius: 14,
    padding: 10,
    marginBottom: 10,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    elevation: 2,
  },
  routeSummaryLeft: { flex: 1, flexDirection: "row", alignItems: "center" },
  routeSummaryColor: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginRight: 10,
  },
  routeSummaryTitle: { fontSize: 14, fontWeight: "700", color: "#0f172a" },
  routeSummaryMeta: { fontSize: 11, color: "#64748b", marginTop: 2 },
  routeSummaryClear: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: "#f1f5f9",
    justifyContent: "center",
    alignItems: "center",
  },
  routeChip: {
    backgroundColor: "#ffffff",
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 18,
    borderWidth: 1.5,
    borderColor: "#e2e8f0",
    marginRight: 8,
    minWidth: 80,
    alignItems: "center",
  },
  routeChipActive: {
    backgroundColor: "#1e40af",
    borderColor: "#1e40af",
  },
  routeChipText: {
    fontSize: 12,
    fontWeight: "600",
    color: "#1f2937",
  },
  routeChipTextActive: {
    color: "#ffffff",
  },
  routeChipSub: {
    fontSize: 10,
    color: "#64748b",
    marginTop: 2,
  },
  busInfoRow: {
    marginTop: 10,
  },
  busInfoRowTitle: {
    fontSize: 12,
    fontWeight: "700",
    color: "#1f2937",
    marginBottom: 6,
    paddingLeft: 4,
  },
  busPill: {
    backgroundColor: "rgba(30,64,175,0.12)",
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 14,
    marginRight: 6,
    alignItems: "center",
  },
  busPillText: {
    fontSize: 11,
    fontWeight: "700",
    color: "#1e40af",
  },
  busPillSub: {
    fontSize: 9,
    color: "#334155",
    marginTop: 1,
  },
  colorDot: { width: 10, height: 10, borderRadius: 5, marginRight: 6 },
  routeChipRow: { flexDirection: "row", alignItems: "center" },
  routeChipBadge: {
    marginLeft: 6,
    fontSize: 10,
    fontWeight: "700",
    color: "#475569",
    backgroundColor: "#e2e8f0",
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 10,
    overflow: "hidden",
  },
  routeChipBadgeActive: { backgroundColor: "#334155", color: "#ffffff" },

  // Legend
  legend: {
    position: "absolute",
    top: 120,
    right: 16,
    backgroundColor: "rgba(255, 255, 255, 0.9)",
    padding: 8,
    borderRadius: 8,
  },
  legendItem: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 4,
  },
  legendIcon: {
    fontSize: 12,
    marginRight: 6,
  },
  legendDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 6,
  },
  legendLine: {
    width: 12,
    height: 2,
    marginRight: 6,
  },
  legendText: {
    fontSize: 10,
    color: "#333",
  },

  // List View Styles
  listContainer: {
    flex: 1,
    backgroundColor: "#f8fafc",
  },
  listTabBar: {
    backgroundColor: "#ffffff",
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#e5e7eb",
  },
  listTab: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: "#f3f4f6",
  },
  activeListTab: {
    backgroundColor: "#1e40af",
  },
  listTabText: {
    fontSize: 14,
    fontWeight: "600",
    color: "#ffffff",
    marginLeft: 8,
  },
  listContent: {
    padding: 16,
  },

  // Bus List Item Styles
  busListItem: {
    backgroundColor: "#ffffff",
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  busItemHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  busItemLeft: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  busItemInfo: {
    marginLeft: 12,
    flex: 1,
  },
  busItemNumber: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#1f2937",
  },
  busItemRoute: {
    fontSize: 12,
    color: "#6b7280",
    marginTop: 2,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 10,
    fontWeight: "600",
    color: "#ffffff",
  },
  busItemDetails: {
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: "#f3f4f6",
  },
  busDetailRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 6,
  },
  busDetailText: {
    fontSize: 12,
    color: "#374151",
    marginLeft: 8,
  },

  // Route List Item Styles
  routeListItem: {
    backgroundColor: "#ffffff",
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  selectedRouteListItem: {
    borderWidth: 2,
    borderColor: "#1e40af",
  },
  routeItemHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  routeItemLeft: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  routeColorIndicator: {
    width: 4,
    height: 40,
    borderRadius: 2,
    marginRight: 12,
  },
  routeItemInfo: {
    flex: 1,
  },
  routeItemName: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#1f2937",
  },
  routeItemNumber: {
    fontSize: 12,
    color: "#6b7280",
    marginTop: 2,
  },
  routeItemRight: {
    alignItems: "flex-end",
  },
  routeStatusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  routeStatusText: {
    fontSize: 10,
    fontWeight: "600",
    color: "#ffffff",
  },
  routeItemDetails: {
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: "#f3f4f6",
  },
  routeDetailRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
  routeDetailText: {
    fontSize: 12,
    color: "#374151",
    marginLeft: 8,
  },
  routeStops: {
    marginTop: 8,
    padding: 12,
    backgroundColor: "#f8fafc",
    borderRadius: 8,
  },
  routeStopsTitle: {
    fontSize: 12,
    fontWeight: "600",
    color: "#374151",
    marginBottom: 6,
  },
  routeStopName: {
    fontSize: 11,
    color: "#6b7280",
    marginBottom: 2,
  },
  routeStopsMore: {
    fontSize: 11,
    color: "#9ca3af",
    fontStyle: "italic",
    marginTop: 4,
  },

  // Modal Styles
  modalContainer: {
    flex: 1,
    backgroundColor: "#f8fafc",
  },
  modalHeader: {
    backgroundColor: "#ffffff",
    paddingHorizontal: 20,
    paddingTop: 50,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#e5e7eb",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  modalHeaderLeft: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#1f2937",
    marginLeft: 8,
  },
  modalCloseButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "#f3f4f6",
    justifyContent: "center",
    alignItems: "center",
  },
  modalListContent: {
    padding: 16,
  },

  // Empty State
  emptyState: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 60,
  },
  emptyStateText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#6b7280",
    marginTop: 16,
    textAlign: "center",
  },
  emptyStateSubtext: {
    fontSize: 14,
    color: "#9ca3af",
    marginTop: 8,
    textAlign: "center",
    paddingHorizontal: 40,
  },

  // Legacy styles for compatibility
  busMarker: {
    alignItems: "center",
    backgroundColor: "white",
    borderRadius: 20,
    padding: 4,
    borderWidth: 2,
    borderColor: "#007AFF",
  },
  busMarkerText: {
    fontSize: 16,
  },
  busNumber: {
    fontSize: 8,
    fontWeight: "bold",
    color: "#007AFF",
    marginTop: 1,
  },
});
