import { useNotifications } from "@/contexts/NotificationContext";
import { Ionicons, MaterialIcons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import React, { useMemo, useState } from "react";
import {
  FlatList,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { Swipeable } from "react-native-gesture-handler";

interface RenderItemProps {
  item: any;
  onMarkRead: (id: string) => void;
  onDelete: (id: string) => void;
}

const NotificationItem: React.FC<RenderItemProps> = ({
  item,
  onMarkRead,
  onDelete,
}) => {
  const renderRightActions = () => {
    return (
      <View style={styles.swipeActions}>
        {!item.read && (
          <TouchableOpacity
            style={[styles.swipeButton, styles.readBtn]}
            onPress={() => onMarkRead(item.id)}
          >
            <Ionicons name="checkmark-done" size={22} color="#fff" />
            <Text style={styles.swipeText}>Read</Text>
          </TouchableOpacity>
        )}
        <TouchableOpacity
          style={[styles.swipeButton, styles.deleteBtn]}
          onPress={() => onDelete(item.id)}
        >
          <MaterialIcons name="delete" size={22} color="#fff" />
          <Text style={styles.swipeText}>Delete</Text>
        </TouchableOpacity>
      </View>
    );
  };

  const iconForType = (type: string) => {
    switch (type) {
      case "arrival":
        return (
          <MaterialIcons name="directions-bus" size={22} color="#2563eb" />
        );
      case "boarding":
        return (
          <MaterialIcons name="person-pin-circle" size={22} color="#10b981" />
        );
      case "delay":
        return <MaterialIcons name="schedule" size={22} color="#f59e0b" />;
      case "announcement":
        return <MaterialIcons name="campaign" size={22} color="#6366f1" />;
      case "emergency":
        return <MaterialIcons name="warning" size={22} color="#ef4444" />;
      default:
        return <MaterialIcons name="notifications" size={22} color="#64748b" />;
    }
  };

  return (
    <Swipeable renderRightActions={renderRightActions} overshootRight={false}>
      <View style={[styles.notificationCard, !item.read && styles.unreadCard]}>
        <View style={styles.iconWrap}>{iconForType(item.type)}</View>
        <View style={styles.notificationContent}>
          <Text style={styles.title}>{item.title}</Text>
          <Text style={styles.body}>{item.body}</Text>
          <Text style={styles.meta}>
            {new Date(
              item.timestamp?.seconds
                ? item.timestamp.seconds * 1000
                : item.timestamp
            ).toLocaleString()}
          </Text>
        </View>
        {!item.read && <View style={styles.unreadDot} />}
      </View>
    </Swipeable>
  );
};

export default function NotificationsScreen() {
  const {
    notificationHistory,
    markAsRead,
    deleteNotification,
    unreadCount,
    preferences,
    updatePreferences,
  } = useNotifications();
  const [filter, setFilter] = useState<
    "all" | "unread" | "alerts" | "emergencies"
  >("all");

  const filtered = useMemo(() => {
    return notificationHistory.filter((n) => {
      if (filter === "unread") return !n.read;
      if (filter === "alerts")
        return ["arrival", "boarding", "delay"].includes(n.type);
      if (filter === "emergencies") return n.type === "emergency";
      return true;
    });
  }, [notificationHistory, filter]);

  const togglePref = (key: keyof typeof preferences) => {
    updatePreferences({ [key]: !preferences[key] });
  };

  const renderHeader = () => (
    <View>
      <LinearGradient
        colors={["#1e40af", "#3b82f6", "#60a5fa"]}
        style={styles.gradientHeader}
      >
        <Text style={styles.headerTitle}>Notifications</Text>
        <Text style={styles.headerSubtitle}>{unreadCount} unread</Text>
        <View style={styles.filterRow}>
          {(["all", "unread", "alerts", "emergencies"] as const).map((f) => (
            <TouchableOpacity
              key={f}
              style={[
                styles.filterChip,
                filter === f && styles.filterChipActive,
              ]}
              onPress={() => setFilter(f)}
            >
              <Text
                style={[
                  styles.filterChipText,
                  filter === f && styles.filterChipTextActive,
                ]}
              >
                {f.charAt(0).toUpperCase() + f.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </LinearGradient>
      <View style={styles.preferenceSection}>
        <Text style={styles.prefTitle}>Notification Preferences</Text>
        <View style={styles.prefGrid}>
          {(
            [
              "arrival",
              "boarding",
              "delay",
              "announcement",
              "emergency",
            ] as const
          ).map((p) => (
            <TouchableOpacity
              key={p}
              style={[
                styles.prefTile,
                preferences[p] ? styles.prefTileOn : styles.prefTileOff,
              ]}
              onPress={() => togglePref(p)}
            >
              <Text style={styles.prefTileLabel}>{p.toUpperCase()}</Text>
              <Ionicons
                name={preferences[p] ? "notifications" : "notifications-off"}
                size={18}
                color={preferences[p] ? "#fff" : "#64748b"}
              />
            </TouchableOpacity>
          ))}
        </View>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id || Math.random().toString()}
        ListHeaderComponent={renderHeader}
        contentContainerStyle={{ paddingBottom: 80 }}
        renderItem={({ item }) => (
          <NotificationItem
            item={item}
            onMarkRead={markAsRead}
            onDelete={deleteNotification}
          />
        )}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <MaterialIcons
              name="notifications-none"
              size={40}
              color="#94a3b8"
            />
            <Text style={styles.emptyText}>No notifications</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f1f5f9" },
  gradientHeader: {
    paddingTop: 70,
    paddingHorizontal: 20,
    paddingBottom: 24,
    borderBottomLeftRadius: 28,
    borderBottomRightRadius: 28,
  },
  headerTitle: { fontSize: 24, fontWeight: "700", color: "#fff" },
  headerSubtitle: { fontSize: 12, color: "#e0f2fe", marginTop: 6 },
  filterRow: { flexDirection: "row", marginTop: 16, flexWrap: "wrap", gap: 8 },
  filterChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    backgroundColor: "rgba(255,255,255,0.25)",
    borderRadius: 22,
  },
  filterChipActive: { backgroundColor: "#ffffff" },
  filterChipText: { fontSize: 12, fontWeight: "600", color: "#ffffff" },
  filterChipTextActive: { color: "#1e40af" },
  preferenceSection: {
    backgroundColor: "#ffffff",
    marginTop: -12,
    marginHorizontal: 16,
    borderRadius: 16,
    padding: 16,
    elevation: 2,
  },
  prefTitle: {
    fontSize: 14,
    fontWeight: "700",
    color: "#1f2937",
    marginBottom: 12,
  },
  prefGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  prefTile: {
    width: "48%",
    borderRadius: 14,
    padding: 14,
    marginBottom: 12,
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    borderWidth: 1,
  },
  prefTileOn: { backgroundColor: "#1e40af", borderColor: "#1e40af" },
  prefTileOff: { backgroundColor: "#f8fafc", borderColor: "#e2e8f0" },
  prefTileLabel: {
    fontSize: 12,
    fontWeight: "700",
    color: "#ffffff",
    letterSpacing: 0.5,
  },
  notificationCard: {
    flexDirection: "row",
    padding: 16,
    backgroundColor: "#ffffff",
    marginHorizontal: 16,
    marginTop: 12,
    borderRadius: 16,
    alignItems: "flex-start",
    position: "relative",
    gap: 12,
    elevation: 1,
  },
  unreadCard: { backgroundColor: "#eef6ff" },
  iconWrap: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: "#f1f5f9",
    justifyContent: "center",
    alignItems: "center",
  },
  notificationContent: { flex: 1 },
  title: { fontSize: 14, fontWeight: "700", color: "#1f2937" },
  body: { fontSize: 12, color: "#475569", marginTop: 4 },
  meta: { fontSize: 10, color: "#94a3b8", marginTop: 6 },
  unreadDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: "#3b82f6",
    position: "absolute",
    top: 10,
    right: 10,
  },
  swipeActions: { flexDirection: "row", alignItems: "stretch", height: "100%" },
  swipeButton: {
    justifyContent: "center",
    alignItems: "center",
    width: 72,
    paddingHorizontal: 8,
  },
  readBtn: {
    backgroundColor: "#10b981",
    borderTopRightRadius: 16,
    borderBottomRightRadius: 16,
  },
  deleteBtn: {
    backgroundColor: "#ef4444",
    borderTopRightRadius: 16,
    borderBottomRightRadius: 16,
  },
  swipeText: {
    fontSize: 10,
    color: "#ffffff",
    marginTop: 4,
    fontWeight: "600",
  },
  emptyState: { alignItems: "center", marginTop: 60 },
  emptyText: {
    fontSize: 13,
    color: "#64748b",
    marginTop: 12,
    fontWeight: "500",
  },
});
