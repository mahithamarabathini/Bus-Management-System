import {
  DarkTheme,
  DefaultTheme,
  ThemeProvider,
} from "@react-navigation/native";
import Constants from "expo-constants";
import { useFonts } from "expo-font";
import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { useEffect } from "react";
import { Platform } from "react-native";
import "react-native-reanimated";

import { ErrorBoundary } from "@/components/ErrorBoundary";
import { AuthProvider } from "@/contexts/AuthContext";
import { NotificationProvider } from "@/contexts/NotificationContext";
import { useColorScheme } from "@/hooks/useColorScheme";

export default function RootLayout() {
  const colorScheme = useColorScheme();
  const [loaded] = useFonts({
    SpaceMono: require("../assets/fonts/SpaceMono-Regular.ttf"),
  });

  // EAS / Push token debug logging
  useEffect(() => {
    try {
      const easProjectId = Constants.easConfig?.projectId;
      console.log("[EAS Debug] Constants.easConfig?.projectId:", easProjectId);
      console.log("[EAS Debug] Candidates detail:", {
        easConfig: Constants.easConfig,
        expoConfigExtra: (Constants as any).expoConfig?.extra?.eas,
        manifestExtra: (Constants as any).manifest?.extra?.eas,
        manifest2Extra: (Constants as any).manifest2?.extra?.eas,
        executionEnvironment: (Constants as any).executionEnvironment,
        appOwnership: (Constants as any).appOwnership,
        deviceName: (Constants as any).deviceName,
        platform: Platform.OS,
      });
    } catch (e) {
      console.warn("[EAS Debug] Logging error", e);
    }
  }, []);

  if (!loaded) {
    // Async font loading only occurs in development.
    return null;
  }

  return (
    <ErrorBoundary>
      <AuthProvider>
        <NotificationProvider>
          <ThemeProvider
            value={colorScheme === "dark" ? DarkTheme : DefaultTheme}
          >
            <Stack screenOptions={{ headerShown: false }}>
              <Stack.Screen name="(tabs)" />
              <Stack.Screen name="auth" />
              <Stack.Screen name="tracking" />
              <Stack.Screen name="attendance" />
              <Stack.Screen name="admin" />
              <Stack.Screen name="routes" />
              <Stack.Screen name="+not-found" />
            </Stack>
            <StatusBar style="auto" />
          </ThemeProvider>
        </NotificationProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}
