import MapAdapter from "@/components/maps/MapAdapter";
import { ThemedText } from "@/components/ThemedText";
import { db } from "@/config/firebase";
import { useAuth } from "@/contexts/AuthContext";
import { MaterialIcons } from "@expo/vector-icons";
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  query,
  updateDoc,
} from "firebase/firestore";
import React, { useEffect, useState } from "react";
import {
  Alert,
  Dimensions,
  FlatList,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

const { width, height } = Dimensions.get("window");
const ASPECT_RATIO = width / height;
const LATITUDE_DELTA = 0.05;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;

interface BusStop {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  order: number;
  type: "start" | "checkpoint" | "end";
  estimatedTime?: string;
  description?: string;
}

interface BusRoute {
  id: string;
  name: string;
  busNumber: string;
  stops: BusStop[];
  color: string;
  isActive: boolean;
  createdAt?: any;
  updatedAt?: any;
}

export default function RouteManageScreen() {
  const { userData } = useAuth();
  // Guard: only admins allowed
  if (userData && userData.role !== "admin") {
    return (
      <View
        style={{
          flex: 1,
          justifyContent: "center",
          alignItems: "center",
          padding: 24,
        }}
      >
        <MaterialIcons name="lock" size={48} color="#6b7280" />
        <Text
          style={{
            marginTop: 16,
            fontSize: 18,
            fontWeight: "600",
            color: "#1f2937",
            textAlign: "center",
          }}
        >
          Access Restricted
        </Text>
        <Text
          style={{
            marginTop: 8,
            fontSize: 14,
            color: "#6b7280",
            textAlign: "center",
          }}
        >
          You do not have permission to manage routes.
        </Text>
      </View>
    );
  }

  const [routes, setRoutes] = useState<BusRoute[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [editingRoute, setEditingRoute] = useState<BusRoute | null>(null);
  const [showMapSelector, setShowMapSelector] = useState(false);
  const [mapMode, setMapMode] = useState<"start" | "checkpoint" | "end">(
    "start"
  );

  // Form states
  const [routeName, setRouteName] = useState("");
  const [busNumber, setBusNumber] = useState("");
  const [routeColor, setRouteColor] = useState("#007AFF");
  const [isActive, setIsActive] = useState(true);
  const [stops, setStops] = useState<BusStop[]>([]);
  const [searchQuery, setSearchQuery] = useState("");

  // Map state
  const [mapRegion, setMapRegion] = useState({
    latitude: 13.427395, // College coordinates (updated)
    longitude: 79.574331,
    latitudeDelta: LATITUDE_DELTA,
    longitudeDelta: LONGITUDE_DELTA,
  });

  const [currentStop, setCurrentStop] = useState({
    name: "",
    latitude: 13.427395,
    longitude: 79.574331,
    description: "",
    estimatedTime: "",
  });

  useEffect(() => {
    setupRouteListener();
  }, []);

  const setupRouteListener = () => {
    try {
      const routesRef = collection(db, "routes");
      const q = query(routesRef);

      const unsubscribe = onSnapshot(q, (snapshot) => {
        const routeData: BusRoute[] = [];
        snapshot.forEach((doc) => {
          routeData.push({
            id: doc.id,
            ...doc.data(),
          } as BusRoute);
        });

        // Sort in memory instead of Firestore query
        routeData.sort((a, b) => {
          const aTime = a.createdAt
            ? a.createdAt.toDate
              ? a.createdAt.toDate()
              : new Date(a.createdAt)
            : new Date(0);
          const bTime = b.createdAt
            ? b.createdAt.toDate
              ? b.createdAt.toDate()
              : new Date(b.createdAt)
            : new Date(0);
          return bTime.getTime() - aTime.getTime();
        });

        setRoutes(routeData);
        setLoading(false);
      });

      return unsubscribe;
    } catch (error) {
      console.error("Error setting up route listener:", error);
      setLoading(false);
    }
  };

  const resetForm = () => {
    setRouteName("");
    setBusNumber("");
    setRouteColor("#007AFF");
    setIsActive(true);
    setStops([]);
    setEditingRoute(null);
    setCurrentStop({
      name: "",
      latitude: 13.427395,
      longitude: 79.574331,
      description: "",
      estimatedTime: "",
    });
    setSearchQuery("");
  };

  const openCreateModal = () => {
    resetForm();
    setIsModalVisible(true);
  };

  const openEditModal = (route: BusRoute) => {
    setEditingRoute(route);
    setRouteName(route.name);
    setBusNumber(route.busNumber);
    setRouteColor(route.color);
    setIsActive(route.isActive);
    setStops(route.stops || []);
    setIsModalVisible(true);
  };

  const openMapSelector = (mode: "start" | "checkpoint" | "end") => {
    setMapMode(mode);
    setCurrentStop({
      ...currentStop,
      name: "",
    });
    setShowMapSelector(true);
  };

  const addStopFromMap = () => {
    if (!currentStop.name.trim()) {
      Alert.alert("Error", "Please enter a stop name");
      return;
    }

    const newStop: BusStop = {
      id: Date.now().toString(),
      name: currentStop.name.trim(),
      latitude: currentStop.latitude,
      longitude: currentStop.longitude,
      order: stops.length + 1,
      type: mapMode,
      estimatedTime: currentStop.estimatedTime,
      description: currentStop.description,
    };

    setStops([...stops, newStop]);
    setShowMapSelector(false);
    setCurrentStop({
      name: "",
      latitude: 13.427395,
      longitude: 79.574331,
      description: "",
      estimatedTime: "",
    });
  };

  const removeStop = (index: number) => {
    const updatedStops = stops.filter((_, i) => i !== index);
    // Reorder stops
    const reorderedStops = updatedStops.map((stop, i) => ({
      ...stop,
      order: i + 1,
    }));
    setStops(reorderedStops);
  };

  const moveStop = (index: number, direction: "up" | "down") => {
    const newStops = [...stops];
    const targetIndex = direction === "up" ? index - 1 : index + 1;

    if (targetIndex >= 0 && targetIndex < newStops.length) {
      [newStops[index], newStops[targetIndex]] = [
        newStops[targetIndex],
        newStops[index],
      ];

      // Update order numbers
      newStops.forEach((stop, i) => {
        stop.order = i + 1;
      });

      setStops(newStops);
    }
  };

  const saveRoute = async () => {
    if (!routeName.trim() || !busNumber.trim()) {
      Alert.alert("Error", "Please fill in all required fields");
      return;
    }

    if (stops.length === 0) {
      Alert.alert("Error", "Please add at least one stop");
      return;
    }

    try {
      // Add SIETK as the end point if not already added
      const finalStops = [...stops];
      const hasEndPoint = finalStops.some((stop) => stop.type === "end");

      if (!hasEndPoint) {
        finalStops.push({
          id: "college-end",
          name: "College Campus",
          latitude: 13.427395,
          longitude: 79.574331,
          order: finalStops.length + 1,
          type: "end",
          description: "College Campus (Auto Added)",
        });
      }

      const routeData = {
        name: routeName.trim(),
        busNumber: busNumber.trim(),
        color: routeColor,
        isActive,
        stops: finalStops,
        updatedAt: new Date(),
      };

      if (editingRoute) {
        await updateDoc(doc(db, "routes", editingRoute.id), routeData);
        Alert.alert("Success", "Route updated successfully");
      } else {
        await addDoc(collection(db, "routes"), {
          ...routeData,
          createdAt: new Date(),
        });
        Alert.alert("Success", "Route created successfully");
      }

      setIsModalVisible(false);
      resetForm();
    } catch (error) {
      console.error("Error saving route:", error);
      Alert.alert("Error", "Failed to save route. Please try again.");
    }
  };

  const deleteRoute = async (routeId: string) => {
    Alert.alert("Delete Route", "Are you sure you want to delete this route?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: async () => {
          try {
            await deleteDoc(doc(db, "routes", routeId));
            Alert.alert("Success", "Route deleted successfully");
          } catch (error) {
            console.error("Error deleting route:", error);
            Alert.alert("Error", "Failed to delete route");
          }
        },
      },
    ]);
  };

  const renderRouteItem = ({ item }: { item: BusRoute }) => (
    <View style={styles.routeCard}>
      <View style={styles.routeHeader}>
        <View style={styles.routeInfo}>
          <View style={styles.routeTitleRow}>
            <Text style={styles.routeName}>{item.name}</Text>
            <View
              style={[
                styles.statusBadge,
                { backgroundColor: item.isActive ? "#10b981" : "#ef4444" },
              ]}
            >
              <Text style={styles.statusText}>
                {item.isActive ? "Active" : "Inactive"}
              </Text>
            </View>
          </View>
          <Text style={styles.busNumber}>Bus: {item.busNumber}</Text>
          <Text style={styles.stopCount}>{item.stops?.length || 0} stops</Text>
        </View>
        <View
          style={[styles.routeColorIndicator, { backgroundColor: item.color }]}
        />
      </View>

      <View style={styles.routeActions}>
        <TouchableOpacity
          style={styles.editButton}
          onPress={() => openEditModal(item)}
        >
          <MaterialIcons name="edit" size={16} color="#ffffff" />
          <Text style={styles.editButtonText}>Edit</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.deleteButton}
          onPress={() => deleteRoute(item.id)}
        >
          <MaterialIcons name="delete" size={16} color="#ffffff" />
          <Text style={styles.deleteButtonText}>Delete</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <MaterialIcons name="alt-route" size={24} color="#1e40af" />
          <ThemedText style={styles.headerTitle}>Route Management</ThemedText>
        </View>
        <TouchableOpacity style={styles.addButton} onPress={openCreateModal}>
          <MaterialIcons name="add" size={20} color="#ffffff" />
          <Text style={styles.addButtonText}>Add Route</Text>
        </TouchableOpacity>
      </View>

      {/* Stats Cards */}
      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <MaterialIcons name="alt-route" size={24} color="#1e40af" />
          <Text style={styles.statNumber}>{routes.length}</Text>
          <Text style={styles.statLabel}>Total Routes</Text>
        </View>
        <View style={styles.statCard}>
          <MaterialIcons name="check-circle" size={24} color="#10b981" />
          <Text style={styles.statNumber}>
            {routes.filter((r) => r.isActive).length}
          </Text>
          <Text style={styles.statLabel}>Active Routes</Text>
        </View>
        <View style={styles.statCard}>
          <MaterialIcons name="directions-bus" size={24} color="#f59e0b" />
          <Text style={styles.statNumber}>
            {new Set(routes.map((r) => r.busNumber)).size}
          </Text>
          <Text style={styles.statLabel}>Buses</Text>
        </View>
      </View>

      {loading ? (
        <View style={styles.loadingContainer}>
          <MaterialIcons name="hourglass-empty" size={48} color="#6b7280" />
          <ThemedText style={styles.loadingText}>Loading routes...</ThemedText>
        </View>
      ) : routes.length === 0 ? (
        <View style={styles.emptyContainer}>
          <MaterialIcons name="alt-route" size={64} color="#d1d5db" />
          <ThemedText style={styles.emptyTitle}>No Routes Yet</ThemedText>
          <ThemedText style={styles.emptySubtitle}>
            Create your first bus route to get started
          </ThemedText>
          <TouchableOpacity
            style={styles.emptyButton}
            onPress={openCreateModal}
          >
            <MaterialIcons name="add" size={20} color="#ffffff" />
            <Text style={styles.emptyButtonText}>Create First Route</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <FlatList
          data={routes}
          renderItem={renderRouteItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
        />
      )}

      {/* Create/Edit Route Modal */}
      <Modal
        visible={isModalVisible}
        animationType="slide"
        presentationStyle="fullScreen"
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity
              onPress={() => setIsModalVisible(false)}
              style={styles.modalCloseButton}
            >
              <MaterialIcons name="close" size={24} color="#6b7280" />
            </TouchableOpacity>
            <Text style={styles.modalTitle}>
              {editingRoute ? "Edit Route" : "Create New Route"}
            </Text>
            <TouchableOpacity
              onPress={saveRoute}
              style={styles.modalSaveButton}
            >
              <MaterialIcons name="check" size={20} color="#ffffff" />
              <Text style={styles.modalSaveText}>Save</Text>
            </TouchableOpacity>
          </View>

          <ScrollView
            style={styles.modalContent}
            showsVerticalScrollIndicator={false}
          >
            {/* Basic Route Info */}
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <MaterialIcons name="info" size={20} color="#1e40af" />
                <Text style={styles.sectionTitle}>Route Information</Text>
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Route Name *</Text>
                <TextInput
                  style={styles.input}
                  placeholder="e.g., Campus to City Center"
                  value={routeName}
                  onChangeText={setRouteName}
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Bus Number *</Text>
                <TextInput
                  style={styles.input}
                  placeholder="e.g., AP 37 Z 1234"
                  value={busNumber}
                  onChangeText={setBusNumber}
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Route Color</Text>
                <View style={styles.colorPickerContainer}>
                  {[
                    "#007AFF",
                    "#34C759",
                    "#FF9500",
                    "#FF3B30",
                    "#AF52DE",
                    "#FF2D92",
                  ].map((color) => (
                    <TouchableOpacity
                      key={color}
                      style={[
                        styles.colorOption,
                        { backgroundColor: color },
                        routeColor === color && styles.selectedColor,
                      ]}
                      onPress={() => setRouteColor(color)}
                    />
                  ))}
                </View>
              </View>
            </View>

            {/* Quick Stop Addition */}
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <MaterialIcons name="place" size={20} color="#1e40af" />
                <Text style={styles.sectionTitle}>Add Stops</Text>
              </View>

              <View style={styles.quickActions}>
                <TouchableOpacity
                  style={styles.quickAddButton}
                  onPress={() => openMapSelector("start")}
                >
                  <MaterialIcons
                    name="play-circle-filled"
                    size={24}
                    color="#ffffff"
                  />
                  <Text style={styles.quickAddText}>Add Start</Text>
                  <Text style={styles.quickAddSubtext}>Starting point</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.quickAddButton}
                  onPress={() => openMapSelector("checkpoint")}
                >
                  <MaterialIcons
                    name="add-location"
                    size={24}
                    color="#ffffff"
                  />
                  <Text style={styles.quickAddText}>Add Stop</Text>
                  <Text style={styles.quickAddSubtext}>Intermediate stop</Text>
                </TouchableOpacity>
              </View>

              {/* Default End Point Info */}
              <View style={styles.endPointInfo}>
                <MaterialIcons name="school" size={20} color="#1e40af" />
                <Text style={styles.endPointText}>
                  End Point: College Campus (Auto Added)
                </Text>
                <Text style={styles.endPointSubtext}>
                  (Automatically added to all routes)
                </Text>
              </View>
            </View>

            {/* Stops List */}
            {stops.length > 0 && (
              <View style={styles.section}>
                <View style={styles.sectionHeader}>
                  <MaterialIcons name="list" size={20} color="#1e40af" />
                  <Text style={styles.sectionTitle}>
                    Route Stops ({stops.length})
                  </Text>
                </View>

                {stops.map((stop, index) => (
                  <View key={index} style={styles.stopItem}>
                    <View style={styles.stopTypeIndicator}>
                      <MaterialIcons
                        name={
                          stop.type === "start"
                            ? "play-circle-filled"
                            : stop.type === "end"
                            ? "stop-circle"
                            : "place"
                        }
                        size={20}
                        color={
                          stop.type === "start"
                            ? "#10b981"
                            : stop.type === "end"
                            ? "#ef4444"
                            : "#3b82f6"
                        }
                      />
                    </View>

                    <View style={styles.stopInfo}>
                      <View style={styles.stopHeader}>
                        <Text style={styles.stopName}>
                          {stop.order}. {stop.name}
                        </Text>
                        <View
                          style={[
                            styles.stopTypeBadge,
                            {
                              backgroundColor:
                                stop.type === "start"
                                  ? "#10b981"
                                  : stop.type === "end"
                                  ? "#ef4444"
                                  : "#3b82f6",
                            },
                          ]}
                        >
                          <Text style={styles.stopTypeBadgeText}>
                            {stop.type.toUpperCase()}
                          </Text>
                        </View>
                      </View>

                      <Text style={styles.stopCoordinates}>
                        {stop.latitude.toFixed(6)}, {stop.longitude.toFixed(6)}
                      </Text>

                      {stop.estimatedTime && (
                        <Text style={styles.stopTime}>
                          Expected: {stop.estimatedTime}
                        </Text>
                      )}

                      {stop.description && (
                        <Text style={styles.stopDescription}>
                          {stop.description}
                        </Text>
                      )}
                    </View>

                    <View style={styles.stopActions}>
                      <TouchableOpacity
                        style={styles.moveButton}
                        onPress={() => moveStop(index, "up")}
                        disabled={index === 0}
                      >
                        <MaterialIcons
                          name="keyboard-arrow-up"
                          size={20}
                          color={index === 0 ? "#9ca3af" : "#6b7280"}
                        />
                      </TouchableOpacity>
                      <TouchableOpacity
                        style={styles.moveButton}
                        onPress={() => moveStop(index, "down")}
                        disabled={index === stops.length - 1}
                      >
                        <MaterialIcons
                          name="keyboard-arrow-down"
                          size={20}
                          color={
                            index === stops.length - 1 ? "#9ca3af" : "#6b7280"
                          }
                        />
                      </TouchableOpacity>
                      <TouchableOpacity
                        style={styles.removeButton}
                        onPress={() => removeStop(index)}
                      >
                        <MaterialIcons name="close" size={16} color="#ef4444" />
                      </TouchableOpacity>
                    </View>
                  </View>
                ))}
              </View>
            )}
          </ScrollView>
        </View>
      </Modal>

      {/* Map Selector Modal */}
      <Modal
        visible={showMapSelector}
        animationType="slide"
        presentationStyle="fullScreen"
      >
        <View style={styles.mapModalContainer}>
          <View style={styles.mapModalHeader}>
            <TouchableOpacity
              onPress={() => setShowMapSelector(false)}
              style={styles.mapModalCloseButton}
            >
              <MaterialIcons name="close" size={24} color="#6b7280" />
            </TouchableOpacity>
            <Text style={styles.mapModalTitle}>
              Add {mapMode.charAt(0).toUpperCase() + mapMode.slice(1)} Point
            </Text>
            <TouchableOpacity
              onPress={addStopFromMap}
              style={styles.mapModalSaveButton}
              disabled={!currentStop.name}
            >
              <MaterialIcons name="check" size={20} color="#ffffff" />
            </TouchableOpacity>
          </View>

          <View style={styles.searchContainer}>
            <View style={styles.stopNameContainer}>
              <TextInput
                style={styles.stopNameInput}
                placeholder={`Enter ${mapMode} point name`}
                value={currentStop.name}
                onChangeText={(text) =>
                  setCurrentStop({ ...currentStop, name: text })
                }
              />
            </View>
          </View>

          <View style={styles.mapContainer}>
            <MapAdapter
              style={styles.realMap}
              region={mapRegion}
              onMapPress={(coordinate) => {
                setMapRegion({
                  ...mapRegion,
                  latitude: coordinate.latitude,
                  longitude: coordinate.longitude,
                });
                setCurrentStop({
                  ...currentStop,
                  latitude: coordinate.latitude,
                  longitude: coordinate.longitude,
                });
              }}
              stops={stops}
              showUserLocation={true}
            />

            {/* Location Info Overlay */}
            <View style={styles.mapOverlay}>
              <View style={styles.locationCard}>
                <Text style={styles.locationTitle}>Selected Location</Text>
                <Text style={styles.locationCoords}>
                  📍 {mapRegion.latitude.toFixed(6)},{" "}
                  {mapRegion.longitude.toFixed(6)}
                </Text>
                <Text style={styles.locationHelper}>
                  {mapMode === "start"
                    ? "🟢 Start Point"
                    : mapMode === "end"
                    ? "🔴 End Point"
                    : "🔵 Checkpoint"}
                </Text>
              </View>

              {/* Quick Location Presets */}
              <View style={styles.presetLocationsOverlay}>
                <TouchableOpacity
                  style={styles.presetButton}
                  onPress={() => {
                    setMapRegion({
                      ...mapRegion,
                      latitude: 13.427395,
                      longitude: 79.574331,
                    });
                    setCurrentStop({
                      ...currentStop,
                      name: currentStop.name || "College Campus",
                      latitude: 13.427395,
                      longitude: 79.574331,
                    });
                  }}
                >
                  <MaterialIcons name="school" size={16} color="#10b981" />
                  <Text style={styles.presetButtonText}>College</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.presetButton}
                  onPress={() => {
                    setMapRegion({
                      ...mapRegion,
                      latitude: 13.629615,
                      longitude: 79.428322,
                    });
                    setCurrentStop({
                      ...currentStop,
                      name: currentStop.name || "Tirupathi Busstand",
                      latitude: 13.629615,
                      longitude: 79.428322,
                    });
                  }}
                >
                  <MaterialIcons
                    name="directions-bus"
                    size={16}
                    color="#f59e0b"
                  />
                  <Text style={styles.presetButtonText}>Bus Station</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f8fafc",
  },
  header: {
    backgroundColor: "#ffffff",
    paddingHorizontal: 20,
    paddingTop: 50,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#e5e7eb",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  headerLeft: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#1f2937",
    marginLeft: 8,
  },
  addButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#1e40af",
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  addButtonText: {
    color: "#ffffff",
    fontSize: 14,
    fontWeight: "600",
    marginLeft: 4,
  },
  statsContainer: {
    flexDirection: "row",
    paddingHorizontal: 20,
    paddingVertical: 16,
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: "#ffffff",
    padding: 16,
    borderRadius: 12,
    alignItems: "center",
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  statNumber: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#1f2937",
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: "#6b7280",
    marginTop: 4,
    textAlign: "center",
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingVertical: 60,
  },
  loadingText: {
    fontSize: 16,
    color: "#6b7280",
    marginTop: 16,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 40,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#1f2937",
    marginTop: 16,
    textAlign: "center",
  },
  emptySubtitle: {
    fontSize: 14,
    color: "#6b7280",
    textAlign: "center",
    marginTop: 8,
    marginBottom: 24,
  },
  emptyButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#1e40af",
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 24,
  },
  emptyButtonText: {
    color: "#ffffff",
    fontSize: 16,
    fontWeight: "600",
    marginLeft: 8,
  },
  listContainer: {
    padding: 20,
  },
  routeCard: {
    backgroundColor: "#ffffff",
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  routeHeader: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: 12,
  },
  routeInfo: {
    flex: 1,
  },
  routeTitleRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 4,
  },
  routeName: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#1f2937",
    flex: 1,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    fontSize: 10,
    fontWeight: "600",
    color: "#ffffff",
  },
  busNumber: {
    fontSize: 14,
    color: "#6b7280",
    marginBottom: 2,
  },
  stopCount: {
    fontSize: 12,
    color: "#9ca3af",
  },
  routeColorIndicator: {
    width: 4,
    height: 60,
    borderRadius: 2,
    marginLeft: 12,
  },
  routeActions: {
    flexDirection: "row",
    gap: 8,
  },
  editButton: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#1e40af",
    paddingVertical: 10,
    borderRadius: 8,
  },
  editButtonText: {
    color: "#ffffff",
    fontSize: 14,
    fontWeight: "600",
    marginLeft: 4,
  },
  deleteButton: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#ef4444",
    paddingVertical: 10,
    borderRadius: 8,
  },
  deleteButtonText: {
    color: "#ffffff",
    fontSize: 14,
    fontWeight: "600",
    marginLeft: 4,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: "#ffffff",
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingTop: 50,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#e5e7eb",
    backgroundColor: "#ffffff",
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  modalCloseButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "#f3f4f6",
    justifyContent: "center",
    alignItems: "center",
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#1f2937",
    flex: 1,
    textAlign: "center",
    marginHorizontal: 16,
  },
  modalSaveButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#1e40af",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
  },
  modalSaveText: {
    color: "#ffffff",
    fontSize: 14,
    fontWeight: "600",
    marginLeft: 4,
  },
  modalContent: {
    flex: 1,
    backgroundColor: "#f8fafc",
  },
  section: {
    backgroundColor: "#ffffff",
    marginHorizontal: 20,
    marginVertical: 8,
    borderRadius: 12,
    padding: 16,
    elevation: 1,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
  },
  sectionHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#1f2937",
    marginLeft: 8,
  },
  inputGroup: {
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: "600",
    color: "#374151",
    marginBottom: 6,
  },
  input: {
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 16,
    backgroundColor: "#ffffff",
  },
  colorPickerContainer: {
    flexDirection: "row",
    gap: 12,
    marginTop: 8,
  },
  colorOption: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: "transparent",
  },
  selectedColor: {
    borderColor: "#1f2937",
    borderWidth: 3,
  },
  quickActions: {
    flexDirection: "row",
    gap: 12,
    marginBottom: 16,
  },
  quickAddButton: {
    flex: 1,
    backgroundColor: "#1e40af",
    padding: 16,
    borderRadius: 12,
    alignItems: "center",
  },
  quickAddText: {
    color: "#ffffff",
    fontSize: 14,
    fontWeight: "600",
    marginTop: 8,
  },
  quickAddSubtext: {
    color: "rgba(255, 255, 255, 0.8)",
    fontSize: 11,
    marginTop: 2,
  },
  endPointInfo: {
    flexDirection: "row",
    alignItems: "flex-start",
    backgroundColor: "#f0f9ff",
    padding: 12,
    borderRadius: 8,
    borderLeftWidth: 4,
    borderLeftColor: "#1e40af",
  },
  endPointText: {
    fontSize: 14,
    fontWeight: "600",
    color: "#1e40af",
    marginLeft: 8,
    flex: 1,
  },
  endPointSubtext: {
    fontSize: 12,
    color: "#6b7280",
    marginLeft: 8,
    marginTop: 2,
  },
  stopItem: {
    flexDirection: "row",
    alignItems: "flex-start",
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#f3f4f6",
  },
  stopTypeIndicator: {
    width: 40,
    alignItems: "center",
    paddingTop: 2,
  },
  stopInfo: {
    flex: 1,
    marginHorizontal: 12,
  },
  stopHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 4,
  },
  stopName: {
    fontSize: 14,
    fontWeight: "600",
    color: "#1f2937",
    flex: 1,
  },
  stopTypeBadge: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 8,
  },
  stopTypeBadgeText: {
    fontSize: 8,
    fontWeight: "bold",
    color: "#ffffff",
  },
  stopCoordinates: {
    fontSize: 12,
    color: "#6b7280",
    fontFamily: "monospace",
    marginBottom: 2,
  },
  stopTime: {
    fontSize: 11,
    color: "#10b981",
    marginBottom: 2,
  },
  stopDescription: {
    fontSize: 11,
    color: "#9ca3af",
  },
  stopActions: {
    alignItems: "center",
    gap: 4,
  },
  moveButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: "#f3f4f6",
    justifyContent: "center",
    alignItems: "center",
  },
  removeButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: "#fef2f2",
    justifyContent: "center",
    alignItems: "center",
  },
  mapModalContainer: {
    flex: 1,
    backgroundColor: "#ffffff",
  },
  mapModalHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingTop: 50,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#e5e7eb",
    backgroundColor: "#ffffff",
  },
  mapModalCloseButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "#f3f4f6",
    justifyContent: "center",
    alignItems: "center",
  },
  mapModalTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#1f2937",
    flex: 1,
    textAlign: "center",
    marginHorizontal: 16,
  },
  mapModalSaveButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "#1e40af",
    justifyContent: "center",
    alignItems: "center",
  },
  searchContainer: {
    paddingHorizontal: 20,
    paddingVertical: 12,
    backgroundColor: "#f8fafc",
    borderBottomWidth: 1,
    borderBottomColor: "#e5e7eb",
  },
  stopNameContainer: {
    marginBottom: 8,
  },
  stopNameInput: {
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 16,
    backgroundColor: "#ffffff",
  },
  mapContainer: {
    flex: 1,
    position: "relative",
  },
  realMap: {
    flex: 1,
  },
  mapOverlay: {
    position: "absolute",
    top: 16,
    left: 16,
    right: 16,
  },
  locationCard: {
    backgroundColor: "rgba(255, 255, 255, 0.95)",
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
    elevation: 4,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  locationTitle: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#1f2937",
    marginBottom: 4,
  },
  locationCoords: {
    fontSize: 12,
    color: "#6b7280",
    fontFamily: "monospace",
    marginBottom: 4,
  },
  locationHelper: {
    fontSize: 12,
    color: "#1e40af",
    fontWeight: "600",
  },
  presetLocationsOverlay: {
    flexDirection: "row",
    gap: 8,
  },
  presetButton: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(255, 255, 255, 0.9)",
    paddingVertical: 8,
    paddingHorizontal: 8,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "#e5e7eb",
  },
  presetButtonText: {
    fontSize: 10,
    fontWeight: "600",
    color: "#374151",
    marginLeft: 4,
  },
});
