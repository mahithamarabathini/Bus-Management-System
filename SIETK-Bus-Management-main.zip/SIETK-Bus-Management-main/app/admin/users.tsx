import { MaterialIcons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { collection, getDocs, orderBy, query } from "firebase/firestore";
import React, { useEffect, useState } from "react";
import {
  Alert,
  RefreshControl,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  View,
} from "react-native";
import { ThemedText } from "../../components/ThemedText";
import { ThemedView } from "../../components/ThemedView";
import { db } from "../../config/firebase";
import { useAuth, UserData } from "../../contexts/AuthContext";

export default function UsersAdminScreen() {
  const [users, setUsers] = useState<UserData[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const { userData } = useAuth();
  const router = useRouter();

  // Check if current user is admin
  useEffect(() => {
    if (userData && userData.role !== "admin") {
      Alert.alert("Access Denied", "Only administrators can access this page");
      router.back();
    }
  }, [userData]);

  const fetchUsers = async () => {
    try {
      const usersQuery = query(
        collection(db, "users"),
        orderBy("createdAt", "desc")
      );
      const querySnapshot = await getDocs(usersQuery);

      const usersData: UserData[] = [];
      querySnapshot.forEach((doc) => {
        usersData.push({ ...doc.data(), uid: doc.id } as UserData);
      });

      setUsers(usersData);
    } catch (error) {
      console.error("Error fetching users:", error);
      Alert.alert("Error", "Failed to fetch users data");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    fetchUsers();
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case "admin":
        return "#dc3545";
      case "bus_incharge":
        return "#fd7e14";
      case "student":
        return "#198754";
      default:
        return "#6c757d";
    }
  };

  const formatDate = (timestamp: any) => {
    if (!timestamp) return "N/A";

    let date;
    if (timestamp.toDate) {
      date = timestamp.toDate();
    } else if (timestamp.seconds) {
      date = new Date(timestamp.seconds * 1000);
    } else {
      return "N/A";
    }

    return date.toLocaleDateString() + " " + date.toLocaleTimeString();
  };

  if (loading) {
    return (
      <ThemedView style={styles.container}>
        <ThemedText style={styles.loadingText}>Loading users...</ThemedText>
      </ThemedView>
    );
  }

  return (
    <ThemedView style={styles.container}>
      <ThemedView style={styles.header}>
        <View style={styles.headerContent}>
          <View style={styles.headerLeft}>
            <ThemedText type="title" style={styles.title}>
              Users Management
            </ThemedText>
            <ThemedText style={styles.subtitle}>
              Total Users: {users.length}
            </ThemedText>
          </View>
          <TouchableOpacity
            style={styles.manageButton}
            onPress={() => router.push("/admin/manage" as any)}
          >
            <MaterialIcons name="alt-route" size={20} color="#ffffff" />
            <ThemedText style={styles.manageButtonText}>Routes</ThemedText>
          </TouchableOpacity>
        </View>
      </ThemedView>

      <ScrollView
        style={styles.scrollView}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {users.map((user, index) => (
          <ThemedView key={user.uid || index} style={styles.userCard}>
            <View style={styles.userHeader}>
              <ThemedText style={styles.userName}>
                {user.displayName || "No Name"}
              </ThemedText>
              <View
                style={[
                  styles.roleTag,
                  { backgroundColor: getRoleColor(user.role) },
                ]}
              >
                <ThemedText style={styles.roleText}>
                  {user.role.toUpperCase()}
                </ThemedText>
              </View>
            </View>

            <View style={styles.userDetails}>
              <ThemedText style={styles.detailText}>
                📧 Email: {user.email}
              </ThemedText>

              {user.studentId && (
                <ThemedText style={styles.detailText}>
                  🎓 Roll Number: {user.studentId}
                </ThemedText>
              )}

              {user.busNumber && (
                <ThemedText style={styles.detailText}>
                  🚌 Bus Number: {user.busNumber}
                </ThemedText>
              )}

              {user.phoneNumber && (
                <ThemedText style={styles.detailText}>
                  📱 Phone: {user.phoneNumber}
                </ThemedText>
              )}

              {user.college && (
                <ThemedText style={styles.detailText}>
                  🏫 College: {user.college}
                </ThemedText>
              )}

              <ThemedText style={styles.timestampText}>
                ⏰ Created: {formatDate(user.createdAt)}
              </ThemedText>

              <ThemedText style={styles.timestampText}>
                🔐 Last Login: {formatDate(user.lastLoginAt)}
              </ThemedText>
            </View>
          </ThemedView>
        ))}
      </ScrollView>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f8f9fa",
  },
  header: {
    padding: 20,
    backgroundColor: "#1e3a8a",
  },
  headerContent: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    width: "100%",
  },
  headerLeft: {
    flex: 1,
  },
  title: {
    color: "white",
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 5,
  },
  subtitle: {
    color: "#bfdbfe",
    fontSize: 16,
  },
  manageButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#059669",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
  },
  manageButtonText: {
    color: "#ffffff",
    fontSize: 14,
    fontWeight: "600",
    marginLeft: 4,
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 15,
  },
  loadingText: {
    textAlign: "center",
    marginTop: 50,
    fontSize: 18,
  },
  userCard: {
    backgroundColor: "white",
    marginVertical: 8,
    borderRadius: 12,
    padding: 15,
    elevation: 3,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
  },
  userHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
  },
  userName: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#1f2937",
    flex: 1,
  },
  roleTag: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  roleText: {
    color: "white",
    fontSize: 12,
    fontWeight: "600",
  },
  userDetails: {
    gap: 5,
  },
  detailText: {
    fontSize: 14,
    color: "#4b5563",
    marginBottom: 2,
  },
  timestampText: {
    fontSize: 12,
    color: "#9ca3af",
    marginTop: 5,
  },
});
