import {
  addDoc,
  collection,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  where,
} from "firebase/firestore";
import React, { useEffect, useState } from "react";
import {
  Alert,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { ThemedText } from "../../components/ThemedText";
import { ThemedView } from "../../components/ThemedView";
import { db } from "../../config/firebase";
import { useAuth } from "../../contexts/AuthContext";
import { useNotifications } from "../../contexts/NotificationContext";
import { locationService } from "../../services/LocationService";

interface AttendanceRecord {
  id: string;
  studentId: string;
  studentName: string;
  busNumber: string;
  action: "board" | "deboard";
  timestamp: any;
  location: {
    latitude: number;
    longitude: number;
  };
  date: string;
}

export default function AttendanceScreen() {
  const { userData } = useAuth();
  const { sendStudentBoardingNotification, sendStudentDeboardingNotification } =
    useNotifications();
  const [loading, setLoading] = useState(false);
  const [attendanceRecords, setAttendanceRecords] = useState<
    AttendanceRecord[]
  >([]);
  const [currentLocation, setCurrentLocation] = useState<{
    latitude: number;
    longitude: number;
  } | null>(null);

  useEffect(() => {
    if (userData?.role === "student") {
      setupAttendanceListener();
    }
    getCurrentLocation();
  }, [userData]);

  const getCurrentLocation = async () => {
    const location = await locationService.getCurrentLocation();
    if (location) {
      setCurrentLocation({
        latitude: location.latitude,
        longitude: location.longitude,
      });
    }
  };

  const setupAttendanceListener = () => {
    if (!userData?.studentId) {
      console.log("AttendanceScreen: userData or studentId not available");
      return;
    }

    try {
      const attendanceRef = collection(db, "attendance");
      const q = query(
        attendanceRef,
        where("studentId", "==", userData.studentId),
        orderBy("timestamp", "desc")
      );

      const unsubscribe = onSnapshot(q, (snapshot) => {
        const records: AttendanceRecord[] = [];
        snapshot.forEach((doc) => {
          records.push({
            id: doc.id,
            ...doc.data(),
          } as AttendanceRecord);
        });
        setAttendanceRecords(records);
      });

      return unsubscribe;
    } catch (error) {
      console.error("Error setting up attendance listener:", error);
      return;
    }
  };

  const handleAttendanceAction = async (action: "board" | "deboard") => {
    if (!userData || !currentLocation) {
      Alert.alert(
        "Error",
        "Location not available. Please enable GPS and try again."
      );
      return;
    }

    // For students, we need to determine which bus they're boarding
    // This could be enhanced with QR code scanning or bus selection
    const busNumber = userData.busNumber || "BUS001"; // Use assigned bus or default

    setLoading(true);

    try {
      const attendanceData = {
        studentId: userData.studentId || userData.uid,
        studentName:
          userData.displayName || userData.email || "Unknown Student",
        busNumber: busNumber,
        action: action,
        timestamp: serverTimestamp(),
        location: currentLocation,
        date: new Date().toISOString().split("T")[0], // YYYY-MM-DD format
      };

      await addDoc(collection(db, "attendance"), attendanceData);

      // Send notifications
      if (action === "board") {
        await sendStudentBoardingNotification(
          attendanceData.studentName,
          busNumber,
          "Current Location"
        );
      } else {
        await sendStudentDeboardingNotification(
          attendanceData.studentName,
          busNumber,
          "Current Location"
        );
      }

      Alert.alert(
        "Success",
        `Successfully marked as ${action === "board" ? "boarded" : "deboarded"}`
      );

      // Refresh location
      await getCurrentLocation();
    } catch (error) {
      console.error("Error recording attendance:", error);
      Alert.alert("Error", "Failed to record attendance. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const formatTimestamp = (timestamp: any): string => {
    if (!timestamp || !timestamp.toDate) return "Unknown";
    return timestamp.toDate().toLocaleString();
  };

  const getLastAction = (): "board" | "deboard" | null => {
    if (attendanceRecords.length === 0) return null;
    return attendanceRecords[0].action;
  };

  const lastAction = getLastAction();

  if (userData?.role !== "student") {
    return (
      <ThemedView style={styles.container}>
        <ThemedText style={styles.errorText}>
          This feature is only available for students.
        </ThemedText>
      </ThemedView>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <ThemedView style={styles.content}>
        <ThemedText style={styles.title}>Bus Attendance</ThemedText>
        <ThemedText style={styles.subtitle}>
          Mark your boarding and deboarding status
        </ThemedText>

        {currentLocation && (
          <ThemedView style={styles.locationContainer}>
            <ThemedText style={styles.locationTitle}>
              Current Location
            </ThemedText>
            <ThemedText style={styles.locationText}>
              📍 {currentLocation.latitude.toFixed(6)},{" "}
              {currentLocation.longitude.toFixed(6)}
            </ThemedText>
          </ThemedView>
        )}

        <ThemedView style={styles.statusContainer}>
          <ThemedText style={styles.statusLabel}>Current Status:</ThemedText>
          <ThemedText
            style={[
              styles.statusValue,
              lastAction === "board" ? styles.boarded : styles.deboarded,
            ]}
          >
            {lastAction === "board"
              ? "🚌 ON BUS"
              : lastAction === "deboard"
              ? "🚶 OFF BUS"
              : "❓ UNKNOWN"}
          </ThemedText>
        </ThemedView>

        <ThemedView style={styles.buttonContainer}>
          <TouchableOpacity
            style={[
              styles.button,
              styles.boardButton,
              (loading || lastAction === "board") && styles.buttonDisabled,
            ]}
            onPress={() => handleAttendanceAction("board")}
            disabled={loading || lastAction === "board"}
          >
            <Text style={styles.buttonText}>
              🚌 {loading ? "Processing..." : "Board Bus"}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.button,
              styles.deboardButton,
              (loading || lastAction !== "board") && styles.buttonDisabled,
            ]}
            onPress={() => handleAttendanceAction("deboard")}
            disabled={loading || lastAction !== "board"}
          >
            <Text style={styles.buttonText}>
              🚶 {loading ? "Processing..." : "Deboard Bus"}
            </Text>
          </TouchableOpacity>
        </ThemedView>

        {attendanceRecords.length > 0 && (
          <ThemedView style={styles.historyContainer}>
            <ThemedText style={styles.historyTitle}>Recent Activity</ThemedText>
            {attendanceRecords.slice(0, 5).map((record) => (
              <View key={record.id} style={styles.recordItem}>
                <View style={styles.recordHeader}>
                  <Text
                    style={[
                      styles.recordAction,
                      record.action === "board"
                        ? styles.boardAction
                        : styles.deboardAction,
                    ]}
                  >
                    {record.action === "board" ? "🚌 Boarded" : "🚶 Deboarded"}
                  </Text>
                  <Text style={styles.recordTime}>
                    {formatTimestamp(record.timestamp)}
                  </Text>
                </View>
                <Text style={styles.recordDetails}>
                  Bus: {record.busNumber} | Location:{" "}
                  {record.location.latitude.toFixed(4)},{" "}
                  {record.location.longitude.toFixed(4)}
                </Text>
              </View>
            ))}
          </ThemedView>
        )}

        <ThemedView style={styles.infoContainer}>
          <ThemedText style={styles.infoTitle}>How to use:</ThemedText>
          <ThemedText style={styles.infoText}>
            • Press "Board Bus" when getting on the bus
          </ThemedText>
          <ThemedText style={styles.infoText}>
            • Press "Deboard Bus" when getting off the bus
          </ThemedText>
          <ThemedText style={styles.infoText}>
            • Your location is automatically recorded
          </ThemedText>
          <ThemedText style={styles.infoText}>
            • Parents and bus in-charges get real-time updates
          </ThemedText>
        </ThemedView>
      </ThemedView>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  content: {
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 8,
    textAlign: "center",
  },
  subtitle: {
    fontSize: 16,
    textAlign: "center",
    marginBottom: 20,
    opacity: 0.7,
  },
  locationContainer: {
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    padding: 12,
    borderRadius: 8,
    marginBottom: 16,
  },
  locationTitle: {
    fontSize: 14,
    fontWeight: "600",
    marginBottom: 4,
  },
  locationText: {
    fontSize: 12,
    fontFamily: "monospace",
    opacity: 0.8,
  },
  statusContainer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 20,
    padding: 16,
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    borderRadius: 8,
  },
  statusLabel: {
    fontSize: 16,
    fontWeight: "600",
    marginRight: 10,
  },
  statusValue: {
    fontSize: 16,
    fontWeight: "bold",
  },
  boarded: {
    color: "#28a745",
  },
  deboarded: {
    color: "#dc3545",
  },
  buttonContainer: {
    marginBottom: 20,
  },
  button: {
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderRadius: 8,
    marginBottom: 10,
  },
  boardButton: {
    backgroundColor: "#28a745",
  },
  deboardButton: {
    backgroundColor: "#dc3545",
  },
  buttonDisabled: {
    backgroundColor: "#ccc",
    opacity: 0.6,
  },
  buttonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "600",
    textAlign: "center",
  },
  historyContainer: {
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    padding: 16,
    borderRadius: 8,
    marginBottom: 20,
  },
  historyTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 12,
  },
  recordItem: {
    backgroundColor: "rgba(255, 255, 255, 0.05)",
    padding: 12,
    borderRadius: 6,
    marginBottom: 8,
  },
  recordHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 4,
  },
  recordAction: {
    fontSize: 14,
    fontWeight: "600",
  },
  boardAction: {
    color: "#28a745",
  },
  deboardAction: {
    color: "#dc3545",
  },
  recordTime: {
    fontSize: 12,
    opacity: 0.7,
  },
  recordDetails: {
    fontSize: 12,
    opacity: 0.8,
    fontFamily: "monospace",
  },
  infoContainer: {
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    padding: 16,
    borderRadius: 8,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    marginBottom: 4,
    opacity: 0.8,
  },
  errorText: {
    fontSize: 16,
    textAlign: "center",
    color: "#dc3545",
    padding: 20,
  },
});
