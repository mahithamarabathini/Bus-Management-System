import { MaterialIcons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  Image,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useAuth } from "../../contexts/AuthContext";

export default function LoginScreen() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const { signIn } = useAuth();
  const router = useRouter();

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert("Error", "Please fill in all fields");
      return;
    }

    setLoading(true);
    try {
      await signIn(email, password);
      router.replace("/(tabs)");
    } catch (error: any) {
      Alert.alert("Login Error", error.message);
    } finally {
      setLoading(false);
    }
  };

  const navigateToRegister = () => {
    router.push("./register");
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <ScrollView
        contentContainerStyle={styles.scrollContainer}
        showsVerticalScrollIndicator={false}
      >
        {/* Structured Gradient Header with Logo */}
        <LinearGradient
          colors={["#1e40af", "#3b82f6", "#60a5fa"]}
          style={styles.gradientHeader}
        >
          <View style={styles.logoRow}>
            <View style={styles.logoCircle}>
              <Image
                source={require("../../assets/images/sietk-logo.png")}
                style={styles.logoImage}
                resizeMode="contain"
              />
            </View>
            <View style={styles.logoTextWrap}>
              <Text style={styles.institutionAbbr}>SIETK</Text>
              <Text style={styles.institutionSub}>Bus Management</Text>
            </View>
            <View style={styles.avatarLarge}>
              <MaterialIcons name="lock" size={40} color="#ffffff" />
            </View>
          </View>
          <View style={styles.identityBlock}>
            <Text style={styles.displayName}>Welcome Back</Text>
            <Text style={styles.subtitleHero}>Sign in to continue</Text>
          </View>
        </LinearGradient>
        <View style={styles.contentWrapper}>
          <View style={styles.sectionCard}>
            <Text style={styles.sectionTitle}>Login</Text>
            {/* Email */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Email</Text>
              <TextInput
                style={styles.input}
                placeholder="you@example.com"
                placeholderTextColor="#9ca3af"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </View>
            {/* Password */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Password</Text>
              <TextInput
                style={styles.input}
                placeholder="••••••••"
                placeholderTextColor="#9ca3af"
                value={password}
                onChangeText={setPassword}
                secureTextEntry
              />
            </View>
            <TouchableOpacity
              style={[styles.primaryButton, loading && styles.disabledButton]}
              onPress={handleLogin}
              disabled={loading}
            >
              <Text style={styles.primaryButtonText}>
                {loading ? "Logging in..." : "Login"}
              </Text>
            </TouchableOpacity>
            <View style={styles.switchRow}>
              <Text style={styles.switchText}>Don't have an account?</Text>
              <TouchableOpacity onPress={navigateToRegister}>
                <Text style={styles.switchLink}> Register</Text>
              </TouchableOpacity>
            </View>
          </View>
          <View style={styles.appInfo}>
            <Text style={styles.appInfoText}>© 2025 SIETK</Text>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f8f9fa",
  },
  scrollContainer: {
    flexGrow: 1,
  },
  gradientHeader: {
    paddingTop: 70,
    paddingHorizontal: 20,
    paddingBottom: 28,
    borderBottomLeftRadius: 32,
    borderBottomRightRadius: 32,
  },
  logoRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  logoCircle: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: "rgba(255,255,255,0.25)",
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
    borderColor: "rgba(255,255,255,0.45)",
  },
  logoImage: { width: 50, height: 50 },
  logoTextWrap: { flex: 1, marginLeft: 16 },
  institutionAbbr: {
    fontSize: 20,
    fontWeight: "700",
    color: "#ffffff",
    letterSpacing: 0.5,
  },
  institutionSub: {
    fontSize: 12,
    color: "#e0f2fe",
    marginTop: 4,
    fontWeight: "500",
  },
  avatarLarge: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: "rgba(255,255,255,0.25)",
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
    borderColor: "rgba(255,255,255,0.55)",
  },
  identityBlock: { marginTop: 24 },
  displayName: {
    fontSize: 26,
    fontWeight: "700",
    color: "#ffffff",
  },
  subtitleHero: {
    fontSize: 13,
    color: "#e0f2fe",
    marginTop: 6,
    fontWeight: "500",
  },
  contentWrapper: {
    paddingHorizontal: 20,
    paddingTop: 24,
    paddingBottom: 40,
  },
  sectionCard: {
    backgroundColor: "#ffffff",
    borderRadius: 18,
    padding: 20,
    marginBottom: 24,
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#1f2937",
    marginBottom: 12,
  },
  inputGroup: {
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 13,
    fontWeight: "600",
    color: "#6b7280",
    marginBottom: 6,
  },
  input: {
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    backgroundColor: "#f9fafb",
    color: "#111827",
  },
  primaryButton: {
    backgroundColor: "#1e40af",
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: "center",
    marginTop: 8,
  },
  primaryButtonText: {
    color: "#ffffff",
    fontSize: 15,
    fontWeight: "600",
  },
  disabledButton: {
    opacity: 0.6,
  },
  switchRow: {
    flexDirection: "row",
    justifyContent: "center",
    marginTop: 18,
    alignItems: "center",
  },
  switchText: {
    fontSize: 13,
    color: "#6b7280",
  },
  switchLink: {
    fontSize: 13,
    color: "#1e40af",
    fontWeight: "700",
  },
  appInfo: {
    alignItems: "center",
    marginTop: 4,
  },
  appInfoText: {
    fontSize: 11,
    color: "#94a3b8",
  },
});
