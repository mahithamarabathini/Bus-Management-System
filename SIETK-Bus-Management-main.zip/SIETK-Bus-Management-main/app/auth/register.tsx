import { MaterialIcons } from "@expo/vector-icons";
import { Picker } from "@react-native-picker/picker";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { collection, getDocs, query, where } from "firebase/firestore";
import React, { useState } from "react";
import {
  Alert,
  Image,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { db } from "../../config/firebase";
import { useAuth, UserData } from "../../contexts/AuthContext";

export default function RegisterScreen() {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    displayName: "",
    role: "" as "student" | "bus_incharge" | "parent" | "admin" | "",
    studentId: "",
    busNumber: "",
    phoneNumber: "",
    college: "SIETK", // Default value set to SIETK
    branch: "",
    year: "",
    address: "",
    parentMobile: "",
  });
  const [loading, setLoading] = useState(false);
  const [studentData, setStudentData] = useState<any>(null);
  const [showStudentConfirmation, setShowStudentConfirmation] = useState(false);
  const [adminSecret, setAdminSecret] = useState("");
  const ADMIN_SECRET = "SISTKISCLOSED";
  const { signUp } = useAuth();
  const router = useRouter();

  // Validate roll number format: 234E5A0902 (10 chars: 2 digits + 4 mixed + 2 digits + 2 mixed)
  const validateRollNumber = (rollNo: string): boolean => {
    if (rollNo.length !== 10) return false;

    const pattern = /^[0-9]{2}[A-Z0-9]{4}[0-9]{2}[A-Z0-9]{2}$/;
    return pattern.test(rollNo);
  };

  // Validate student data for parent registration
  const validateStudentData = async (rollNumber: string) => {
    if (!validateRollNumber(rollNumber)) {
      Alert.alert(
        "Invalid Roll Number",
        "Roll number must be 10 characters long in format: 234E5A0902"
      );
      return;
    }

    try {
      setLoading(true);
      const usersRef = collection(db, "users");

      // Simplified query to avoid index requirements
      const q = query(usersRef, where("studentId", "==", rollNumber));
      const querySnapshot = await getDocs(q);

      // Filter in memory instead of using compound query
      const studentDocs = querySnapshot.docs.filter((doc) => {
        const data = doc.data();
        return data.role === "student";
      });

      if (studentDocs.length === 0) {
        Alert.alert(
          "Student Not Found",
          "No student found with this roll number. Please verify the roll number."
        );
        setStudentData(null);
        setShowStudentConfirmation(false);
        return;
      }

      const studentDoc = studentDocs[0];
      const student = studentDoc.data();

      setStudentData({
        ...student,
        id: studentDoc.id,
      });
      setShowStudentConfirmation(true);
    } catch (error) {
      console.error("Error fetching student data:", error);
      Alert.alert(
        "Error",
        "Failed to validate student data. Please try again."
      );
    } finally {
      setLoading(false);
    }
  };

  const confirmStudentData = () => {
    if (studentData) {
      setFormData((prev) => ({
        ...prev,
        branch: studentData.branch || "",
        year: studentData.year || "",
      }));
      setShowStudentConfirmation(false);
    }
  };

  const handleRegister = async () => {
    if (
      !formData.email ||
      !formData.password ||
      !formData.displayName ||
      !formData.role
    ) {
      Alert.alert("Error", "Please fill in all required fields");
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      Alert.alert("Error", "Passwords do not match");
      return;
    }

    if (formData.password.length < 6) {
      Alert.alert("Error", "Password must be at least 6 characters long");
      return;
    }

    // Validate role-specific fields
    if (formData.role === "student") {
      if (!formData.studentId) {
        Alert.alert("Error", "Roll Number is required for students");
        return;
      }
      if (!validateRollNumber(formData.studentId)) {
        Alert.alert(
          "Invalid Roll Number",
          "Roll number must be 10 characters long in format: 234E5A0902\n" +
            "• First 2: Numbers (e.g., 23)\n" +
            "• Next 4: Letters/Numbers (e.g., 4E5A)\n" +
            "• Next 2: Numbers (e.g., 09)\n" +
            "• Last 2: Letters/Numbers (e.g., 02)"
        );
        return;
      }
      if (!formData.branch) {
        Alert.alert("Error", "Branch is required for students");
        return;
      }
      if (!formData.year) {
        Alert.alert("Error", "Year is required for students");
        return;
      }
      if (!formData.address) {
        Alert.alert("Error", "Address is required for students");
        return;
      }
      if (!formData.parentMobile) {
        Alert.alert("Error", "Parent mobile number is required for students");
        return;
      }
    }

    if (formData.role === "parent") {
      if (!formData.studentId) {
        Alert.alert("Error", "Child's Roll Number is required for parents");
        return;
      }
      if (!studentData) {
        Alert.alert("Error", "Please validate the student data first");
        return;
      }
    }

    if (formData.role === "bus_incharge" && !formData.busNumber) {
      Alert.alert("Error", "Bus Number is required for bus in-charges");
      return;
    }

    if (formData.role === "admin") {
      if (!adminSecret.trim()) {
        Alert.alert("Secret Required", "Enter admin secret code.");
        return;
      }
      if (adminSecret.trim() !== ADMIN_SECRET) {
        Alert.alert("Invalid Secret", "Admin secret code is incorrect.");
        return;
      }
    }

    setLoading(true);
    try {
      const userData: Partial<UserData> = {
        displayName: formData.displayName,
        role: formData.role as "student" | "bus_incharge" | "parent" | "admin",
        phoneNumber: formData.phoneNumber,
        college: formData.college,
      };

      // Role-specific data
      if (formData.role === "student") {
        userData.studentId = formData.studentId;
        userData.branch = formData.branch;
        userData.year = formData.year;
        userData.address = formData.address;
        userData.parentMobile = formData.parentMobile;
      }

      if (formData.role === "parent") {
        userData.studentId = formData.studentId; // Child's roll number
        userData.branch = studentData.branch; // Child's branch
        userData.year = studentData.year; // Child's year
        userData.address = formData.address; // Parent's address (optional)
      }

      if (formData.role === "bus_incharge") {
        userData.busNumber = formData.busNumber;
        userData.address = formData.address; // Optional for bus incharge
      }

      if (formData.role === "admin") {
        // Admin only needs basic info - no address or parent mobile
      }

      await signUp(formData.email, formData.password, userData);
      router.replace("/(tabs)");
    } catch (error: any) {
      let errorMessage = error.message;

      // Handle specific Firebase errors with user-friendly messages
      if (error.code === "auth/email-already-in-use") {
        errorMessage =
          "This email is already registered. Please use a different email or try logging in.";
      } else if (error.code === "auth/invalid-email") {
        errorMessage = "Please enter a valid email address.";
      } else if (error.code === "auth/weak-password") {
        errorMessage =
          "Password is too weak. Please choose a stronger password.";
      } else if (error.code === "auth/network-request-failed") {
        errorMessage =
          "Network error. Please check your internet connection and try again.";
      }

      Alert.alert("Registration Error", errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const navigateToLogin = () => {
    router.push("./login");
  };

  const updateFormData = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <ScrollView
        contentContainerStyle={styles.scrollContainer}
        showsVerticalScrollIndicator={false}
      >
        <LinearGradient
          colors={["#1e40af", "#3b82f6", "#60a5fa"]}
          style={styles.gradientHeader}
        >
          <View style={styles.logoRow}>
            <View style={styles.logoCircle}>
              <Image
                source={require("../../assets/images/sietk-logo.png")}
                style={styles.logoImage}
                resizeMode="contain"
              />
            </View>
            <View style={styles.logoTextWrap}>
              <Text style={styles.institutionAbbr}>SIETK</Text>
              <Text style={styles.institutionSub}>Bus Management</Text>
            </View>
            <View style={styles.avatarLarge}>
              <MaterialIcons name="person-add" size={38} color="#ffffff" />
            </View>
          </View>
          <View style={styles.identityBlock}>
            <Text style={styles.displayName}>Create Account</Text>
            <Text style={styles.subtitleHero}>Join the transport network</Text>
          </View>
        </LinearGradient>
        <View style={styles.contentWrapper}>
          <View style={styles.sectionCard}>
            <Text style={styles.sectionTitle}>Basic Information</Text>
            {/* Name */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Full Name *</Text>
              <TextInput
                style={styles.input}
                placeholder="Enter full name"
                placeholderTextColor="#9ca3af"
                value={formData.displayName}
                onChangeText={(v) => updateFormData("displayName", v)}
                autoCapitalize="words"
              />
            </View>
            {/* Email */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Email *</Text>
              <TextInput
                style={styles.input}
                placeholder="you@example.com"
                placeholderTextColor="#9ca3af"
                value={formData.email}
                onChangeText={(v) => updateFormData("email", v)}
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </View>
            {/* Password */}
            <View style={styles.dualRow}>
              <View style={[styles.inputGroup, styles.dualItem]}>
                <Text style={styles.inputLabel}>Password *</Text>
                <TextInput
                  style={styles.input}
                  placeholder="••••••••"
                  placeholderTextColor="#9ca3af"
                  value={formData.password}
                  onChangeText={(v) => updateFormData("password", v)}
                  secureTextEntry
                />
              </View>
              <View style={[styles.inputGroup, styles.dualItem]}>
                <Text style={styles.inputLabel}>Confirm *</Text>
                <TextInput
                  style={styles.input}
                  placeholder="••••••••"
                  placeholderTextColor="#9ca3af"
                  value={formData.confirmPassword}
                  onChangeText={(v) => updateFormData("confirmPassword", v)}
                  secureTextEntry
                />
              </View>
            </View>
            {/* Role */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Role *</Text>
              <View style={styles.pickerContainer}>
                <Picker
                  selectedValue={formData.role}
                  style={styles.picker}
                  onValueChange={(v: string) => {
                    updateFormData("role", v);
                    setFormData((prev) => ({
                      ...prev,
                      role: v as any,
                      studentId: "",
                      busNumber: "",
                      branch: "",
                      year: "",
                      address: "",
                      parentMobile: "",
                    }));
                    setStudentData(null);
                    setShowStudentConfirmation(false);
                    setAdminSecret("");
                  }}
                >
                  <Picker.Item label="Select role" value="" />
                  <Picker.Item label="Student" value="student" />
                  <Picker.Item label="Parent" value="parent" />
                  <Picker.Item label="Bus In-charge" value="bus_incharge" />
                  <Picker.Item label="Admin" value="admin" />
                </Picker>
              </View>
            </View>
            {/* Phone */}
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Phone</Text>
              <TextInput
                style={styles.input}
                placeholder="+91..."
                placeholderTextColor="#9ca3af"
                value={formData.phoneNumber}
                onChangeText={(v) => updateFormData("phoneNumber", v)}
                keyboardType="phone-pad"
              />
            </View>
            {formData.role === "admin" && (
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Admin Secret Code *</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Enter secret"
                  placeholderTextColor="#9ca3af"
                  value={adminSecret}
                  onChangeText={setAdminSecret}
                  autoCapitalize="characters"
                  secureTextEntry
                />
                <Text style={styles.helperText}>
                  Required to create administrator account.
                </Text>
              </View>
            )}
          </View>
          {formData.role === "student" && (
            <View style={styles.sectionCard}>
              <Text style={styles.sectionTitle}>Student Details</Text>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Roll Number *</Text>
                <TextInput
                  style={styles.input}
                  placeholder="234E5A0902"
                  placeholderTextColor="#9ca3af"
                  value={formData.studentId}
                  onChangeText={(v) =>
                    updateFormData("studentId", v.toUpperCase())
                  }
                  maxLength={10}
                  autoCapitalize="characters"
                />
              </View>
              <View style={styles.dualRow}>
                <View style={[styles.inputGroup, styles.dualItem]}>
                  <Text style={styles.inputLabel}>Branch *</Text>
                  <View style={styles.pickerContainer}>
                    <Picker
                      selectedValue={formData.branch}
                      style={styles.picker}
                      onValueChange={(v: string) => updateFormData("branch", v)}
                    >
                      <Picker.Item label="Branch" value="" />
                      <Picker.Item label="CSE" value="CSE" />
                      <Picker.Item label="ECE" value="ECE" />
                      <Picker.Item label="EEE" value="EEE" />
                      <Picker.Item label="MECH" value="MECH" />
                      <Picker.Item label="CIVIL" value="CIVIL" />
                      <Picker.Item label="IT" value="IT" />
                    </Picker>
                  </View>
                </View>
                <View style={[styles.inputGroup, styles.dualItem]}>
                  <Text style={styles.inputLabel}>Year *</Text>
                  <View style={styles.pickerContainer}>
                    <Picker
                      selectedValue={formData.year}
                      style={styles.picker}
                      onValueChange={(v: string) => updateFormData("year", v)}
                    >
                      <Picker.Item label="Year" value="" />
                      <Picker.Item label="I" value="I" />
                      <Picker.Item label="II" value="II" />
                      <Picker.Item label="III" value="III" />
                      <Picker.Item label="IV" value="IV" />
                    </Picker>
                  </View>
                </View>
              </View>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Address *</Text>
                <TextInput
                  style={[styles.input, styles.textArea]}
                  placeholder="Full address"
                  placeholderTextColor="#9ca3af"
                  value={formData.address}
                  onChangeText={(v) => updateFormData("address", v)}
                  multiline
                  numberOfLines={3}
                  textAlignVertical="top"
                />
              </View>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Parent Mobile *</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Parent mobile"
                  placeholderTextColor="#9ca3af"
                  value={formData.parentMobile}
                  onChangeText={(v) => updateFormData("parentMobile", v)}
                  keyboardType="phone-pad"
                  maxLength={15}
                />
              </View>
            </View>
          )}
          {formData.role === "bus_incharge" && (
            <View style={styles.sectionCard}>
              <Text style={styles.sectionTitle}>Bus In-charge</Text>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Bus Number *</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Bus Number"
                  placeholderTextColor="#9ca3af"
                  value={formData.busNumber}
                  onChangeText={(v) => updateFormData("busNumber", v)}
                />
              </View>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Address (Optional)</Text>
                <TextInput
                  style={[styles.input, styles.textArea]}
                  placeholder="Address"
                  placeholderTextColor="#9ca3af"
                  value={formData.address}
                  onChangeText={(v) => updateFormData("address", v)}
                  multiline
                  numberOfLines={3}
                  textAlignVertical="top"
                />
              </View>
            </View>
          )}
          {formData.role === "parent" && (
            <View style={styles.sectionCard}>
              <Text style={styles.sectionTitle}>Parent</Text>
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Child Roll Number *</Text>
                <View style={styles.inlineRow}>
                  <TextInput
                    style={[styles.input, { flex: 1, marginRight: 8 }]}
                    placeholder="234E5A0902"
                    placeholderTextColor="#9ca3af"
                    value={formData.studentId}
                    onChangeText={(v) =>
                      updateFormData("studentId", v.toUpperCase())
                    }
                    maxLength={10}
                    autoCapitalize="characters"
                  />
                  <TouchableOpacity
                    style={styles.verifyButton}
                    onPress={() => validateStudentData(formData.studentId)}
                    disabled={loading || !formData.studentId}
                  >
                    <MaterialIcons name="search" size={20} color="#ffffff" />
                    <Text style={styles.verifyButtonText}>Verify</Text>
                  </TouchableOpacity>
                </View>
                <Text style={styles.helperText}>
                  Verify to fetch student details.
                </Text>
              </View>
              {showStudentConfirmation && studentData && (
                <View style={styles.confirmCard}>
                  <View style={styles.confirmHeader}>
                    <MaterialIcons name="school" size={22} color="#1e40af" />
                    <Text style={styles.confirmTitle}>Student Found</Text>
                  </View>
                  <Text style={styles.confirmLine}>
                    Name: {studentData.displayName}
                  </Text>
                  <Text style={styles.confirmLine}>
                    Branch: {studentData.branch}
                  </Text>
                  <Text style={styles.confirmLine}>
                    Year: {studentData.year}
                  </Text>
                  <View style={styles.confirmButtons}>
                    <TouchableOpacity
                      style={styles.confirmBtn}
                      onPress={confirmStudentData}
                    >
                      <MaterialIcons name="check" size={16} color="#ffffff" />
                      <Text style={styles.confirmBtnText}>Confirm</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={styles.cancelBtn}
                      onPress={() => {
                        setShowStudentConfirmation(false);
                        setStudentData(null);
                      }}
                    >
                      <MaterialIcons name="close" size={16} color="#ef4444" />
                      <Text style={styles.cancelBtnText}>Cancel</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              )}
              {studentData && !showStudentConfirmation && (
                <Text style={styles.successBanner}>
                  ✓ Verified: {studentData.displayName} ({studentData.branch} -{" "}
                  {studentData.year} Year)
                </Text>
              )}
              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Address (Optional)</Text>
                <TextInput
                  style={[styles.input, styles.textArea]}
                  placeholder="Address"
                  placeholderTextColor="#9ca3af"
                  value={formData.address}
                  onChangeText={(v) => updateFormData("address", v)}
                  multiline
                  numberOfLines={3}
                  textAlignVertical="top"
                />
              </View>
            </View>
          )}
          <View style={styles.sectionCard}>
            <Text style={styles.sectionTitle}>Institution</Text>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>College (Locked)</Text>
              <TextInput
                style={[styles.input, { backgroundColor: "#f1f5f9" }]}
                value={formData.college}
                editable={false}
              />
              <Text style={styles.helperText}>
                Default: Siddharth Institution of Engineering & Technology
              </Text>
            </View>
          </View>
          <TouchableOpacity
            style={[styles.primaryButton, loading && styles.disabledButton]}
            disabled={loading}
            onPress={handleRegister}
          >
            <Text style={styles.primaryButtonText}>
              {loading ? "Creating Account..." : "Register"}
            </Text>
          </TouchableOpacity>
          <View style={styles.switchRow}>
            <Text style={styles.switchText}>Already have an account?</Text>
            <TouchableOpacity onPress={navigateToLogin}>
              <Text style={styles.switchLink}> Login</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.appInfo}>
            <Text style={styles.appInfoText}>© 2025 SIETK</Text>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f8f9fa",
  },
  scrollContainer: { flexGrow: 1 },
  gradientHeader: {
    paddingTop: 70,
    paddingHorizontal: 20,
    paddingBottom: 28,
    borderBottomLeftRadius: 32,
    borderBottomRightRadius: 32,
  },
  logoRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  logoCircle: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: "rgba(255,255,255,0.25)",
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
    borderColor: "rgba(255,255,255,0.45)",
  },
  logoImage: {
    width: 50,
    height: 50,
  },
  logoTextWrap: {
    flex: 1,
    marginLeft: 16,
  },
  institutionAbbr: {
    fontSize: 20,
    fontWeight: "700",
    color: "#ffffff",
    letterSpacing: 0.5,
  },
  institutionSub: {
    fontSize: 12,
    color: "#e0f2fe",
    marginTop: 4,
    fontWeight: "500",
  },
  avatarLarge: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: "rgba(255,255,255,0.25)",
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
    borderColor: "rgba(255,255,255,0.55)",
  },
  identityBlock: {
    marginTop: 24,
  },
  displayName: {
    fontSize: 26,
    fontWeight: "700",
    color: "#ffffff",
  },
  subtitleHero: {
    fontSize: 13,
    color: "#e0f2fe",
    marginTop: 6,
    fontWeight: "500",
  },
  contentWrapper: {
    paddingHorizontal: 20,
    paddingTop: 24,
    paddingBottom: 40,
  },
  sectionCard: {
    backgroundColor: "#ffffff",
    borderRadius: 18,
    padding: 20,
    marginBottom: 24,
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: "700",
    color: "#1f2937",
    marginBottom: 14,
  },
  inputGroup: {
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 13,
    fontWeight: "600",
    color: "#6b7280",
    marginBottom: 6,
  },
  input: {
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    backgroundColor: "#f9fafb",
    color: "#111827",
  },
  textArea: {
    minHeight: 80,
  },
  dualRow: {
    flexDirection: "row",
    gap: 14,
  },
  dualItem: {
    flex: 1,
  },
  pickerContainer: {
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 10,
    overflow: "hidden",
    backgroundColor: "#f9fafb",
  },
  picker: {
    height: 48,
  },
  inlineRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  verifyButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#1e40af",
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderRadius: 10,
  },
  verifyButtonText: {
    color: "#ffffff",
    fontSize: 13,
    fontWeight: "600",
    marginLeft: 4,
  },
  confirmCard: {
    backgroundColor: "#f0f9ff",
    borderRadius: 12,
    padding: 16,
    marginTop: 4,
    borderWidth: 1,
    borderColor: "#bae6fd",
  },
  confirmHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10,
  },
  confirmTitle: {
    fontSize: 15,
    fontWeight: "700",
    color: "#1e40af",
    marginLeft: 8,
  },
  confirmLine: {
    fontSize: 13,
    color: "#1f2937",
    marginBottom: 2,
  },
  confirmButtons: {
    flexDirection: "row",
    gap: 10,
    marginTop: 10,
  },
  confirmBtn: {
    flexDirection: "row",
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#10b981",
    paddingVertical: 10,
    borderRadius: 10,
    gap: 4,
  },
  confirmBtnText: {
    color: "#ffffff",
    fontSize: 13,
    fontWeight: "600",
  },
  cancelBtn: {
    flexDirection: "row",
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#ffffff",
    paddingVertical: 10,
    borderRadius: 10,
    gap: 4,
    borderWidth: 1,
    borderColor: "#ef4444",
  },
  cancelBtnText: {
    color: "#ef4444",
    fontSize: 13,
    fontWeight: "600",
  },
  successBanner: {
    fontSize: 12,
    color: "#10b981",
    fontWeight: "600",
    backgroundColor: "#f0fdf4",
    padding: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "#bbf7d0",
    marginBottom: 12,
  },
  primaryButton: {
    backgroundColor: "#1e40af",
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: "center",
    marginTop: 8,
  },
  primaryButtonText: {
    color: "#ffffff",
    fontSize: 15,
    fontWeight: "600",
  },
  disabledButton: {
    opacity: 0.6,
  },
  switchRow: {
    flexDirection: "row",
    justifyContent: "center",
    marginTop: 10,
    alignItems: "center",
  },
  switchText: {
    fontSize: 13,
    color: "#6b7280",
  },
  switchLink: {
    fontSize: 13,
    color: "#1e40af",
    fontWeight: "700",
  },
  appInfo: {
    alignItems: "center",
    marginTop: 8,
  },
  appInfoText: {
    fontSize: 11,
    color: "#94a3b8",
  },
  helperText: { fontSize: 11, color: "#64748b", marginTop: 4 },
});
