import { Stack } from "expo-router";

export default function RoutesLayout() {
  return (
    <Stack screenOptions={{ headerShown: false }}>
      {/* No screens here anymore - moved to tabs */}
    </Stack>
  );
}
