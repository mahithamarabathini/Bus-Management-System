import { Stack } from "expo-router";

export default function TrackingLayout() {
  return (
    <Stack>
      <Stack.Screen
        name="location"
        options={{
          title: "GPS Tracking",
          headerShown: true,
        }}
      />
      <Stack.Screen
        name="buses"
        options={{
          title: "Live Bus Tracking",
          headerShown: true,
        }}
      />
    </Stack>
  );
}
