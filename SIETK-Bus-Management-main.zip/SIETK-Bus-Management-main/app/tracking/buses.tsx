import { collection, onSnapshot, query } from "firebase/firestore";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { ThemedText } from "../../components/ThemedText";
import { ThemedView } from "../../components/ThemedView";
import { db } from "../../config/firebase";
import { useAuth } from "../../contexts/AuthContext";
import { BusLocationUpdate } from "../../services/LocationService";

interface BusInfo extends BusLocationUpdate {
  id: string;
  distance?: number;
}

export default function BusTrackingScreen() {
  const { userData } = useAuth();
  const [buses, setBuses] = useState<BusInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedBus, setSelectedBus] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = setupBusLocationListener();
    return () => {
      if (unsubscribe) {
        unsubscribe();
      }
    };
  }, []);

  const setupBusLocationListener = () => {
    try {
      const busLocationsRef = collection(db, "busLocations");
      // Using only a simple query to avoid requiring a composite index
      const q = query(busLocationsRef);

      const unsubscribe = onSnapshot(q, (snapshot) => {
        const busData: BusInfo[] = [];

        snapshot.forEach((doc) => {
          const data = doc.data() as BusLocationUpdate;
          // Filter active buses in JavaScript instead of using a Firestore where clause
          if (data.isActive) {
            busData.push({
              id: doc.id,
              ...data,
            });
          }
        });

        // Sort by lastUpdated in JavaScript instead of using Firestore orderBy
        busData.sort((a, b) => {
          const timeA = a.lastUpdated?.toDate?.() || new Date(0);
          const timeB = b.lastUpdated?.toDate?.() || new Date(0);
          return timeB.getTime() - timeA.getTime(); // Descending - newest first
        });

        setBuses(busData);
        setLoading(false);
      });

      return unsubscribe;
    } catch (error) {
      console.error("Error setting up bus location listener:", error);
      setLoading(false);
      return null;
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    // The real-time listener will automatically update the data
    setTimeout(() => {
      setRefreshing(false);
    }, 1000);
  };

  const formatLastUpdated = (timestamp: any): string => {
    if (!timestamp || !timestamp.toDate) {
      return "Unknown";
    }

    const date = timestamp.toDate();
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMinutes = Math.floor(diffMs / (1000 * 60));

    if (diffMinutes < 1) {
      return "Just now";
    } else if (diffMinutes < 60) {
      return `${diffMinutes} minutes ago`;
    } else {
      const diffHours = Math.floor(diffMinutes / 60);
      return `${diffHours} hours ago`;
    }
  };

  const formatCoordinate = (value: number): string => {
    return value.toFixed(6);
  };

  const formatSpeed = (speed: number | null | undefined): string => {
    if (speed === null || speed === undefined) return "N/A";
    return `${(speed * 3.6).toFixed(1)} km/h`;
  };

  const calculateDistance = (
    lat1: number,
    lon1: number,
    lat2: number,
    lon2: number
  ): number => {
    const R = 6371; // Radius of the Earth in kilometers
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const d = R * c; // Distance in kilometers
    return d;
  };

  const renderBusCard = (bus: BusInfo) => {
    const isSelected = selectedBus === bus.id;

    return (
      <TouchableOpacity
        key={bus.id}
        style={[styles.busCard, isSelected && styles.selectedBusCard]}
        onPress={() => setSelectedBus(isSelected ? null : bus.id)}
      >
        <View style={styles.busHeader}>
          <ThemedText style={styles.busNumber}>Bus {bus.busNumber}</ThemedText>
          <View style={[styles.statusBadge, styles.activeBadge]}>
            <Text style={styles.statusText}>ACTIVE</Text>
          </View>
        </View>

        <View style={styles.busInfo}>
          <ThemedText style={styles.lastUpdated}>
            Last updated: {formatLastUpdated(bus.lastUpdated)}
          </ThemedText>
        </View>

        {isSelected && (
          <View style={styles.detailsContainer}>
            <View style={styles.locationDetails}>
              <ThemedText style={styles.detailsTitle}>
                Location Details
              </ThemedText>

              <View style={styles.detailRow}>
                <ThemedText style={styles.detailLabel}>Latitude:</ThemedText>
                <ThemedText style={styles.detailValue}>
                  {formatCoordinate(bus.location.latitude)}
                </ThemedText>
              </View>

              <View style={styles.detailRow}>
                <ThemedText style={styles.detailLabel}>Longitude:</ThemedText>
                <ThemedText style={styles.detailValue}>
                  {formatCoordinate(bus.location.longitude)}
                </ThemedText>
              </View>

              <View style={styles.detailRow}>
                <ThemedText style={styles.detailLabel}>Speed:</ThemedText>
                <ThemedText style={styles.detailValue}>
                  {formatSpeed(bus.location.speed)}
                </ThemedText>
              </View>

              <View style={styles.detailRow}>
                <ThemedText style={styles.detailLabel}>Accuracy:</ThemedText>
                <ThemedText style={styles.detailValue}>
                  {bus.location.accuracy
                    ? `±${bus.location.accuracy.toFixed(1)}m`
                    : "N/A"}
                </ThemedText>
              </View>

              <View style={styles.detailRow}>
                <ThemedText style={styles.detailLabel}>Heading:</ThemedText>
                <ThemedText style={styles.detailValue}>
                  {bus.location.heading
                    ? `${bus.location.heading.toFixed(1)}°`
                    : "N/A"}
                </ThemedText>
              </View>
            </View>

            <TouchableOpacity style={styles.actionButton}>
              <Text style={styles.actionButtonText}>View on Map</Text>
            </TouchableOpacity>
          </View>
        )}
      </TouchableOpacity>
    );
  };

  if (loading) {
    return (
      <ThemedView style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#007AFF" />
        <ThemedText style={styles.loadingText}>
          Loading bus locations...
        </ThemedText>
      </ThemedView>
    );
  }

  return (
    <ScrollView
      style={styles.container}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />
      }
    >
      <ThemedView style={styles.content}>
        <ThemedText style={styles.title}>Live Bus Tracking</ThemedText>
        <ThemedText style={styles.subtitle}>
          Track active buses in real-time
        </ThemedText>

        <View style={styles.summaryContainer}>
          <View style={styles.summaryItem}>
            <ThemedText style={styles.summaryNumber}>{buses.length}</ThemedText>
            <ThemedText style={styles.summaryLabel}>Active Buses</ThemedText>
          </View>
        </View>

        {buses.length === 0 ? (
          <ThemedView style={styles.emptyContainer}>
            <ThemedText style={styles.emptyText}>
              No active buses found
            </ThemedText>
            <ThemedText style={styles.emptySubtext}>
              Check back later or contact your bus in-charge
            </ThemedText>
          </ThemedView>
        ) : (
          <View style={styles.busList}>
            <ThemedText style={styles.sectionTitle}>Active Buses</ThemedText>
            {buses.map(renderBusCard)}
          </View>
        )}

        <ThemedView style={styles.infoContainer}>
          <ThemedText style={styles.infoTitle}>How it works:</ThemedText>
          <ThemedText style={styles.infoText}>
            • Tap on a bus to view detailed location information
          </ThemedText>
          <ThemedText style={styles.infoText}>
            • Pull down to refresh the bus list
          </ThemedText>
          <ThemedText style={styles.infoText}>
            • Locations update automatically every few seconds
          </ThemedText>
          <ThemedText style={styles.infoText}>
            • Only active buses with GPS tracking are shown
          </ThemedText>
        </ThemedView>
      </ThemedView>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  content: {
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 8,
    textAlign: "center",
  },
  subtitle: {
    fontSize: 16,
    textAlign: "center",
    marginBottom: 20,
    opacity: 0.7,
  },
  summaryContainer: {
    flexDirection: "row",
    justifyContent: "center",
    marginBottom: 20,
  },
  summaryItem: {
    alignItems: "center",
    padding: 16,
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    borderRadius: 8,
    minWidth: 100,
  },
  summaryNumber: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#007AFF",
  },
  summaryLabel: {
    fontSize: 14,
    marginTop: 4,
  },
  busList: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 12,
  },
  busCard: {
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    borderRadius: 8,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "transparent",
  },
  selectedBusCard: {
    borderColor: "#007AFF",
    backgroundColor: "rgba(0, 122, 255, 0.1)",
  },
  busHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 8,
  },
  busNumber: {
    fontSize: 18,
    fontWeight: "bold",
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  activeBadge: {
    backgroundColor: "#28a745",
  },
  statusText: {
    color: "white",
    fontSize: 12,
    fontWeight: "600",
  },
  busInfo: {
    marginBottom: 8,
  },
  lastUpdated: {
    fontSize: 14,
    opacity: 0.8,
  },
  detailsContainer: {
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: "rgba(255, 255, 255, 0.2)",
  },
  locationDetails: {
    marginBottom: 16,
  },
  detailsTitle: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 12,
  },
  detailRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 4,
  },
  detailLabel: {
    fontSize: 14,
    flex: 1,
  },
  detailValue: {
    fontSize: 14,
    flex: 1,
    textAlign: "right",
    fontFamily: "monospace",
  },
  actionButton: {
    backgroundColor: "#007AFF",
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  actionButtonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "600",
    textAlign: "center",
  },
  emptyContainer: {
    alignItems: "center",
    padding: 40,
    backgroundColor: "rgba(255, 255, 255, 0.05)",
    borderRadius: 8,
    marginBottom: 20,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 8,
  },
  emptySubtext: {
    fontSize: 14,
    textAlign: "center",
    opacity: 0.7,
  },
  infoContainer: {
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    padding: 16,
    borderRadius: 8,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    marginBottom: 4,
    opacity: 0.8,
  },
});
