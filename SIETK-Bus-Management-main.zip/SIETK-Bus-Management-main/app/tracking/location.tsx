import React, { useEffect, useState } from "react";
import {
  Alert,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { ThemedText } from "../../components/ThemedText";
import { ThemedView } from "../../components/ThemedView";
import { useAuth } from "../../contexts/AuthContext";
import { LocationData, locationService } from "../../services/LocationService";

export default function LocationTrackingScreen() {
  const { userData } = useAuth();
  const [isTracking, setIsTracking] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<LocationData | null>(
    null
  );
  const [loading, setLoading] = useState(false);
  const [locationServicesEnabled, setLocationServicesEnabled] = useState(true);

  useEffect(() => {
    checkLocationServices();
    return () => {
      // Cleanup tracking when component unmounts
      if (isTracking && userData?.busNumber && userData?.uid) {
        locationService.stopLocationTracking(userData.busNumber, userData.uid);
      }
    };
  }, []);

  const checkLocationServices = async () => {
    const enabled = await locationService.checkLocationServicesEnabled();
    setLocationServicesEnabled(enabled);

    if (!enabled) {
      Alert.alert(
        "Location Services Disabled",
        "Please enable location services to use GPS tracking functionality.",
        [{ text: "OK" }]
      );
    }
  };

  const handleStartTracking = async () => {
    if (!userData?.busNumber || !userData?.uid) {
      Alert.alert("Error", "Bus number or user information not available");
      return;
    }

    if (!locationServicesEnabled) {
      Alert.alert("Error", "Location services are not enabled");
      return;
    }

    setLoading(true);

    try {
      const success = await locationService.startLocationTracking(
        userData.busNumber,
        userData.uid,
        (location) => {
          setCurrentLocation(location);
        }
      );

      if (success) {
        setIsTracking(true);
        Alert.alert("Success", "GPS tracking started successfully");
      } else {
        Alert.alert(
          "Error",
          "Failed to start GPS tracking. Please check permissions."
        );
      }
    } catch (error) {
      console.error("Error starting tracking:", error);
      Alert.alert("Error", "Failed to start GPS tracking");
    } finally {
      setLoading(false);
    }
  };

  const handleStopTracking = async () => {
    if (!userData?.busNumber || !userData?.uid) {
      return;
    }

    setLoading(true);

    try {
      await locationService.stopLocationTracking(
        userData.busNumber,
        userData.uid
      );
      setIsTracking(false);
      setCurrentLocation(null);
      Alert.alert("Success", "GPS tracking stopped");
    } catch (error) {
      console.error("Error stopping tracking:", error);
      Alert.alert("Error", "Failed to stop GPS tracking");
    } finally {
      setLoading(false);
    }
  };

  const getCurrentLocationOnce = async () => {
    setLoading(true);

    try {
      const location = await locationService.getCurrentLocation();
      if (location) {
        setCurrentLocation(location);
      } else {
        Alert.alert("Error", "Failed to get current location");
      }
    } catch (error) {
      console.error("Error getting location:", error);
      Alert.alert("Error", "Failed to get current location");
    } finally {
      setLoading(false);
    }
  };

  const formatCoordinate = (value: number | null | undefined): string => {
    if (value === null || value === undefined) return "N/A";
    return value.toFixed(6);
  };

  const formatSpeed = (speed: number | null | undefined): string => {
    if (speed === null || speed === undefined) return "N/A";
    // Convert m/s to km/h
    return `${(speed * 3.6).toFixed(1)} km/h`;
  };

  const formatTimestamp = (timestamp: number): string => {
    return new Date(timestamp).toLocaleString();
  };

  if (userData?.role !== "bus_incharge") {
    return (
      <ThemedView style={styles.container}>
        <ThemedText style={styles.errorText}>
          This feature is only available for bus in-charges.
        </ThemedText>
      </ThemedView>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <ThemedView style={styles.content}>
        <ThemedText style={styles.title}>GPS Location Tracking</ThemedText>
        <ThemedText style={styles.subtitle}>
          Bus Number: {userData?.busNumber || "Not assigned"}
        </ThemedText>

        <ThemedView style={styles.statusContainer}>
          <ThemedText style={styles.statusLabel}>Tracking Status:</ThemedText>
          <ThemedText
            style={[
              styles.statusValue,
              isTracking ? styles.active : styles.inactive,
            ]}
          >
            {isTracking ? "ACTIVE" : "INACTIVE"}
          </ThemedText>
        </ThemedView>

        <ThemedView style={styles.buttonContainer}>
          <TouchableOpacity
            style={[
              styles.button,
              styles.primaryButton,
              (loading || isTracking) && styles.buttonDisabled,
            ]}
            onPress={handleStartTracking}
            disabled={loading || isTracking}
          >
            <Text style={styles.buttonText}>
              {loading ? "Starting..." : "Start Tracking"}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.button,
              styles.dangerButton,
              (loading || !isTracking) && styles.buttonDisabled,
            ]}
            onPress={handleStopTracking}
            disabled={loading || !isTracking}
          >
            <Text style={styles.buttonText}>
              {loading ? "Stopping..." : "Stop Tracking"}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.button,
              styles.secondaryButton,
              loading && styles.buttonDisabled,
            ]}
            onPress={getCurrentLocationOnce}
            disabled={loading}
          >
            <Text style={styles.buttonText}>
              {loading ? "Getting Location..." : "Get Current Location"}
            </Text>
          </TouchableOpacity>
        </ThemedView>

        {currentLocation && (
          <ThemedView style={styles.locationContainer}>
            <ThemedText style={styles.sectionTitle}>
              Current Location
            </ThemedText>

            <View style={styles.locationRow}>
              <ThemedText style={styles.locationLabel}>Latitude:</ThemedText>
              <ThemedText style={styles.locationValue}>
                {formatCoordinate(currentLocation.latitude)}
              </ThemedText>
            </View>

            <View style={styles.locationRow}>
              <ThemedText style={styles.locationLabel}>Longitude:</ThemedText>
              <ThemedText style={styles.locationValue}>
                {formatCoordinate(currentLocation.longitude)}
              </ThemedText>
            </View>

            <View style={styles.locationRow}>
              <ThemedText style={styles.locationLabel}>Altitude:</ThemedText>
              <ThemedText style={styles.locationValue}>
                {currentLocation.altitude
                  ? `${currentLocation.altitude.toFixed(1)}m`
                  : "N/A"}
              </ThemedText>
            </View>

            <View style={styles.locationRow}>
              <ThemedText style={styles.locationLabel}>Accuracy:</ThemedText>
              <ThemedText style={styles.locationValue}>
                {currentLocation.accuracy
                  ? `±${currentLocation.accuracy.toFixed(1)}m`
                  : "N/A"}
              </ThemedText>
            </View>

            <View style={styles.locationRow}>
              <ThemedText style={styles.locationLabel}>Speed:</ThemedText>
              <ThemedText style={styles.locationValue}>
                {formatSpeed(currentLocation.speed)}
              </ThemedText>
            </View>

            <View style={styles.locationRow}>
              <ThemedText style={styles.locationLabel}>Heading:</ThemedText>
              <ThemedText style={styles.locationValue}>
                {currentLocation.heading
                  ? `${currentLocation.heading.toFixed(1)}°`
                  : "N/A"}
              </ThemedText>
            </View>

            <View style={styles.locationRow}>
              <ThemedText style={styles.locationLabel}>
                Last Updated:
              </ThemedText>
              <ThemedText style={styles.locationValue}>
                {formatTimestamp(currentLocation.timestamp)}
              </ThemedText>
            </View>
          </ThemedView>
        )}

        <ThemedView style={styles.infoContainer}>
          <ThemedText style={styles.infoTitle}>Important Notes:</ThemedText>
          <ThemedText style={styles.infoText}>
            • Keep the app in foreground for optimal tracking
          </ThemedText>
          <ThemedText style={styles.infoText}>
            • Location updates every 10 seconds or 10 meters
          </ThemedText>
          <ThemedText style={styles.infoText}>
            • Ensure GPS/Location services are enabled
          </ThemedText>
          <ThemedText style={styles.infoText}>
            • Battery usage may increase during tracking
          </ThemedText>
        </ThemedView>
      </ThemedView>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  content: {
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 8,
    textAlign: "center",
  },
  subtitle: {
    fontSize: 16,
    textAlign: "center",
    marginBottom: 20,
    opacity: 0.7,
  },
  statusContainer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 20,
    padding: 16,
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    borderRadius: 8,
  },
  statusLabel: {
    fontSize: 16,
    fontWeight: "600",
    marginRight: 10,
  },
  statusValue: {
    fontSize: 16,
    fontWeight: "bold",
  },
  active: {
    color: "#28a745",
  },
  inactive: {
    color: "#dc3545",
  },
  buttonContainer: {
    marginBottom: 20,
  },
  button: {
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderRadius: 8,
    marginBottom: 10,
  },
  primaryButton: {
    backgroundColor: "#007AFF",
  },
  secondaryButton: {
    backgroundColor: "#6c757d",
  },
  dangerButton: {
    backgroundColor: "#dc3545",
  },
  buttonDisabled: {
    backgroundColor: "#ccc",
    opacity: 0.6,
  },
  buttonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "600",
    textAlign: "center",
  },
  locationContainer: {
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    padding: 16,
    borderRadius: 8,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 12,
    textAlign: "center",
  },
  locationRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 4,
  },
  locationLabel: {
    fontSize: 14,
    fontWeight: "500",
    flex: 1,
  },
  locationValue: {
    fontSize: 14,
    flex: 1,
    textAlign: "right",
    fontFamily: "monospace",
  },
  infoContainer: {
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    padding: 16,
    borderRadius: 8,
  },
  infoTitle: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    marginBottom: 4,
    opacity: 0.8,
  },
  errorText: {
    fontSize: 16,
    textAlign: "center",
    color: "#dc3545",
    padding: 20,
  },
});
