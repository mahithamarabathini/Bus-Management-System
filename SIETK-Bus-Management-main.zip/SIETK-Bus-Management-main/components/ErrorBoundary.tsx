import React from "react";
import { Platform, StyleSheet, Text, TouchableOpacity } from "react-native";
import { ThemedText } from "./ThemedText";
import { ThemedView } from "./ThemedView";

interface Props {
  children: React.ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export class ErrorBoundary extends React.Component<
  Props,
  State & { showDetails?: boolean }
> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, showDetails: false } as any;
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error("Error caught by boundary:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      const isDev = typeof __DEV__ !== "undefined" && __DEV__;
      return (
        <ThemedView style={styles.container}>
          <ThemedText style={styles.title}>Something went wrong</ThemedText>
          <ThemedText style={styles.message}>
            We're sorry, but something unexpected happened. Please try again.
          </ThemedText>
          {this.state.error && (isDev || this.state.showDetails) && (
            <ThemedText style={styles.errorDetails} numberOfLines={8}>
              {this.state.error?.message}\n
              {this.state.error?.stack?.split("\n").slice(0, 6).join("\n")}
            </ThemedText>
          )}
          {!isDev && this.state.error && (
            <TouchableOpacity
              style={[styles.button, { backgroundColor: "#64748b" }]}
              onPress={() =>
                this.setState((s) => ({ showDetails: !s.showDetails }))
              }
            >
              <Text style={styles.buttonText}>
                {this.state.showDetails ? "Hide Details" : "Show Details"}
              </Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity
            style={[styles.button, { marginTop: 12 }]}
            onPress={() =>
              this.setState({
                hasError: false,
                error: undefined,
                showDetails: false,
              })
            }
          >
            <Text style={styles.buttonText}>Try Again</Text>
          </TouchableOpacity>
        </ThemedView>
      );
    }

    return this.props.children;
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 16,
    textAlign: "center",
  },
  message: {
    fontSize: 16,
    textAlign: "center",
    marginBottom: 24,
    lineHeight: 24,
  },
  button: {
    backgroundColor: "#007AFF",
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
  },
  buttonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "600",
  },
  errorDetails: {
    fontSize: 12,
    color: "#dc2626",
    backgroundColor: "#fef2f2",
    borderWidth: 1,
    borderColor: "#fecaca",
    padding: 10,
    borderRadius: 8,
    width: "100%",
    marginBottom: 8,
    fontFamily: Platform?.OS === "ios" ? "Courier" : "monospace",
  },
});
