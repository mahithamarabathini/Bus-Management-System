import React from "react";
import { StyleSheet, Text, View } from "react-native";

interface FallbackMapProps {
  style?: any;
  message?: string;
}

const FallbackMap: React.FC<FallbackMapProps> = ({
  style,
  message = "Map could not be loaded. Please make sure you have the required permissions and dependencies.",
}) => {
  return (
    <View style={[styles.container, style]}>
      <View style={styles.messageContainer}>
        <Text style={styles.messageIcon}>🗺️</Text>
        <Text style={styles.message}>{message}</Text>
        <Text style={styles.helpText}>
          This is a fallback component displayed when the map can't be loaded
          properly.
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f5f5f5",
  },
  messageContainer: {
    backgroundColor: "#ffffff",
    padding: 20,
    borderRadius: 10,
    width: "80%",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  messageIcon: {
    fontSize: 48,
    marginBottom: 16,
  },
  message: {
    fontSize: 16,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 8,
    color: "#333",
  },
  helpText: {
    fontSize: 14,
    textAlign: "center",
    color: "#666",
    lineHeight: 20,
  },
});

export default FallbackMap;
