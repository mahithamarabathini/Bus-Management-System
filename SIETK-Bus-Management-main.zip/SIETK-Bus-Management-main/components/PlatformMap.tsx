// Legacy file removed. Keeping stub to avoid import crashes if any lingering imports.
// Please migrate imports to: import MapAdapter from "@/components/maps/MapAdapter";
// This stub will be deleted after all references are cleaned.
import MapAdapter from "./maps/MapAdapter";
export default MapAdapter;
