// Legacy web PlatformMap removed. Use MapAdapter instead.
import MapAdapter from "./maps/MapAdapter";
export default MapAdapter;
