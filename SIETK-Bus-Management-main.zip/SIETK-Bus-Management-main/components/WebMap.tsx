import React from "react";
import { StyleSheet, View } from "react-native";
import { WebView } from "react-native-webview";
import FallbackMap from "./FallbackMap";

interface WebMapProps {
  style?: any;
  region: {
    latitude: number;
    longitude: number;
    latitudeDelta: number;
    longitudeDelta: number;
  };
  stops?: Array<{
    id: string;
    name: string;
    latitude: number;
    longitude: number;
    order: number;
  }>;
  routeCoordinates?: Array<{ latitude: number; longitude: number }>;
  routeColor?: string;
  showUserLocation?: boolean;
}

export default function WebMap({
  style,
  region,
  stops = [],
  routeCoordinates = [],
  routeColor = "#007AFF",
  showUserLocation = true,
}: WebMapProps) {
  // Generate HTML for an OpenStreetMap with markers
  const generateMapHtml = () => {
    const { latitude, longitude, latitudeDelta } = region;
    // Convert latitudeDelta to zoom level (approximation)
    const zoom = Math.log2(360 / latitudeDelta) - 2;

    const stopsJson = JSON.stringify(stops);
    const routeJson = JSON.stringify(routeCoordinates);

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
        <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
        <style>
          body { margin: 0; padding: 0; }
          #map { width: 100%; height: 100vh; }
          .bus-stop-marker { 
            background-color: #FF6B6B; 
            color: white; 
            border-radius: 50%; 
            width: 24px; 
            height: 24px; 
            text-align: center; 
            line-height: 24px; 
            font-weight: bold;
            border: 2px solid white;
          }
        </style>
      </head>
      <body>
        <div id="map"></div>
        <script>
          // Initialize map
          const map = L.map('map').setView([${latitude}, ${longitude}], ${zoom});
          
          // Add OpenStreetMap tiles
          L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          }).addTo(map);
          
          // Add stops
          const stops = ${stopsJson};
          stops.forEach(stop => {
            const marker = L.marker([stop.latitude, stop.longitude], {
              title: stop.name
            }).addTo(map);
            marker.bindPopup("<b>" + stop.name + "</b><br>Stop " + stop.order);
          });
          
          // Add route polyline
          const route = ${routeJson};
          if (route.length > 1) {
            const routePoints = route.map(point => [point.latitude, point.longitude]);
            L.polyline(routePoints, {color: '${routeColor}', weight: 4, dashArray: '5, 5'}).addTo(map);
          }
          
          // Add user location if allowed
          if (${showUserLocation}) {
            map.locate({setView: false, maxZoom: 16});
            
            function onLocationFound(e) {
              const radius = e.accuracy / 2;
              L.marker(e.latlng).addTo(map)
                .bindPopup("You are within " + radius + " meters from this point").openPopup();
              L.circle(e.latlng, radius).addTo(map);
            }
            
            map.on('locationfound', onLocationFound);
          }
        </script>
      </body>
      </html>
    `;
  };

  try {
    return (
      <View style={[styles.container, style]}>
        <WebView
          style={styles.webView}
          source={{ html: generateMapHtml() }}
          originWhitelist={["*"]}
          javaScriptEnabled={true}
          domStorageEnabled={true}
          startInLoadingState={true}
          onError={() => console.error("WebView error")}
        />
      </View>
    );
  } catch (error) {
    console.error("Error rendering WebMap:", error);
    return (
      <FallbackMap
        style={style}
        message="Web map could not be loaded. Please check your connection."
      />
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  webView: {
    flex: 1,
  },
});
