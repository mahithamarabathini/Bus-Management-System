import React from "react";
import OSMWebMap from "./OSMWebMap";
import VectorMap from "./VectorMap";

export interface CommonMapProps {
  region: {
    latitude: number;
    longitude: number;
    latitudeDelta: number;
    longitudeDelta: number;
  };
  stops?: Array<{
    id: string;
    name: string;
    latitude: number;
    longitude: number;
    order: number;
  }>;
  buses?: Array<{
    id: string;
    busNumber: string;
    location: { latitude: number; longitude: number; speed?: number | null };
    lastUpdated?: any;
  }>;
  routeCoordinates?: Array<{ latitude: number; longitude: number }>;
  routeColor?: string;
  onMapPress?: (c: { latitude: number; longitude: number }) => void;
  showUserLocation?: boolean;
  darkModeTiles?: boolean; // new
  clustering?: boolean; // new
  style?: any;
  onError?: (err?: any) => void;
  mode?: "auto" | "vector" | "web";
}

// Tries vector map first (MapLibre placeholder), falls back to WebView.
const MapAdapter: React.FC<CommonMapProps> = (props) => {
  const { mode = "web" } = props; // force web default
  if (mode === "web") return <OSMWebMap {...props} />;
  if (mode === "vector") return <VectorMap {...props} />;
  return <OSMWebMap {...props} />; // auto fallback to web
};

export default MapAdapter;
