import * as Location from "expo-location";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { ActivityIndicator, StyleSheet, View } from "react-native";
import { WebView } from "react-native-webview";
import FallbackMap from "../FallbackMap";
import { CommonMapProps } from "./MapAdapter";

const OSMWebMap: React.FC<CommonMapProps> = ({
  region,
  stops = [],
  buses = [],
  routeCoordinates = [],
  routeColor = "#007AFF",
  onMapPress,
  showUserLocation = true,
  style,
  onError,
}) => {
  const webRef = useRef<WebView | null>(null);
  const [userLocation, setUserLocation] = useState<{
    latitude: number;
    longitude: number;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    if (!showUserLocation) return;
    (async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status === "granted") {
          const loc = await Location.getCurrentPositionAsync({});
          setUserLocation({
            latitude: loc.coords.latitude,
            longitude: loc.coords.longitude,
          });
        }
      } catch (e) {
        console.warn("Location error", e);
      }
    })();
  }, [showUserLocation]);

  const zoom = useMemo(() => {
    const z = Math.log2(360 / region.latitudeDelta);
    return Math.min(19, Math.max(3, Math.round(z)));
  }, [region.latitudeDelta]);

  const html = useMemo(() => {
    const stopsJson = JSON.stringify(stops);
    const busesJson = JSON.stringify(
      buses.map((b) => ({
        id: b.id,
        busNumber: b.busNumber,
        latitude: b.location.latitude,
        longitude: b.location.longitude,
        speed: b.location.speed || 0,
      }))
    );
    const routeJson = JSON.stringify(routeCoordinates);
    const userJson = JSON.stringify(userLocation);
    // Force light mode tiles irrespective of system preference
    const dark = false; // previously: Appearance.getColorScheme() === 'dark'
    const tileUrl = "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png";
    const tileAttrib = "© OpenStreetMap";
    return `<!DOCTYPE html><html><head><meta name='viewport' content='initial-scale=1, maximum-scale=1'>
<link rel=\"preconnect\" href=\"https://unpkg.com\" />
<link rel=\"preconnect\" href=\"https://cdnjs.cloudflare.com\" />
<style>html,body,#map{height:100%;margin:0;padding:0;background:${
      dark ? "#0f172a" : "#e2e8f0"
    };font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;} #map{opacity:0;transition:opacity .4s ease;} .marker-stop{background:#FF6B6B;color:#fff;border:2px solid #fff;width:26px;height:26px;border-radius:13px;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:600;box-shadow:0 2px 4px rgba(0,0,0,.25);} .marker-bus{background:${
      dark ? "#1e293b" : "#fff"
    };border:2px solid #007AFF;border-radius:16px;padding:4px 6px;font-size:11px;font-weight:600;display:flex;align-items:center;gap:4px;box-shadow:0 2px 6px rgba(0,0,0,.3);} .pulse-user{position:relative;width:16px;height:16px;background:rgba(0,122,255,.3);border:2px solid #007AFF;border-radius:50%;} .pulse-user:after{content:'';position:absolute;left:50%;top:50%;width:5px;height:5px;background:#007AFF;border-radius:3px;transform:translate(-50%,-50%);} .leaflet-popup-content-wrapper{border-radius:10px;} .arrow{font-size:12px;transform:translate(-50%,-50%);} #fallbackMsg{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);background:${
      dark ? "#1e293b" : "#ffffff"
    };color:${
      dark ? "#f8fafc" : "#1f2937"
    };padding:14px 18px;border-radius:12px;box-shadow:0 4px 16px rgba(0,0,0,.25);font-size:12px;line-height:1.4;display:none;text-align:center;width:70%;}</style></head><body>
<div id='map'></div><div id='fallbackMsg'>Unable to load map libraries. Check your internet connection or network restrictions.</div>
<script>
(function(){
 const send = (o)=>{ if(window.ReactNativeWebView){ window.ReactNativeWebView.postMessage(JSON.stringify(o)); } };
 const update = (m)=>{ send({type:'phase', step:m}); };
 const cssCdns = [
  'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css',
  'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.css'
 ];
 const jsCdns = [
  'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',
  'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.js'
 ];
 let leafletLoaded=false; let mapStarted=false; let tileFirstLoaded=false;
 function loadCSS(i){ if(i>=cssCdns.length){ update('css fail'); return; } const l=document.createElement('link'); l.rel='stylesheet'; l.href=cssCdns[i]; l.onload=()=>{ update('css ok '+i); }; l.onerror=()=>{ update('css err '+i); loadCSS(i+1); }; document.head.appendChild(l);} loadCSS(0);
 function loadLeaflet(i){ if(i>=jsCdns.length){ update('leaflet fail'); showFallback(); return; } const s=document.createElement('script'); s.src=jsCdns[i]; s.async=true; s.onload=()=>{ leafletLoaded=true; update('leaflet ok '+i); initMap(); }; s.onerror=()=>{ update('leaflet err '+i); setTimeout(()=>loadLeaflet(i+1),400); }; document.head.appendChild(s);} loadLeaflet(0);
 function showFallback(){ document.getElementById('fallbackMsg').style.display='block'; send({type:'error', message:'Leaflet failed all CDNs'}); }
 function initMap(){ if(mapStarted) return; if(!window.L){ update('L missing'); return; } mapStarted=true; try {
  update('build map');
  const stops=${stopsJson}; const buses=${busesJson}; const route=${routeJson}; const userLoc=${userJson};
  const map=L.map('map',{zoomControl:true}).setView([${region.latitude},${
      region.longitude
    }],${zoom});
  const primaryUrl='${tileUrl}';
  const primaryAttrib='${tileAttrib}';
  const primary=L.tileLayer(primaryUrl,{maxZoom:19, attribution:primaryAttrib});
  primary.on('tileload',()=>{ if(!tileFirstLoaded){ tileFirstLoaded=true; document.getElementById('map').style.opacity='1'; update('tiles ok'); send({type:'tileLoaded'});} });
  primary.on('tileerror',(e)=>{ send({type:'tileError', url:e?.tile?.src}); });
  primary.addTo(map);
  setTimeout(()=>{ if(!tileFirstLoaded){ update('alt tiles'); try { L.tileLayer('https://{s}.tile.openstreetmap.de/{z}/{x}/{y}.png',{maxZoom:19, attribution:'© OpenStreetMap'}).addTo(map); } catch(e){ send({type:'error', message:'alt tile fail '+e}); } } },4000);
  if(route.length>1){ const latlngs=route.map(p=>[p.latitude,p.longitude]); const bounds=L.latLngBounds(latlngs); map.fitBounds(bounds.pad(0.2)); L.polyline(latlngs,{color:'${
    dark ? "#334155" : "#ffffff"
  }',weight:12,opacity:0.9}).addTo(map); L.polyline(latlngs,{color:'${routeColor}',weight:8,opacity:0.95}).addTo(map); }
  stops.forEach(s=>{ var el=document.createElement('div'); el.className='marker-stop'; el.innerText=s.order; L.marker([s.latitude,s.longitude],{icon:L.divIcon({className:'',html:el.outerHTML,iconSize:[26,26],iconAnchor:[13,13]})}).addTo(map); });
  buses.forEach(b=>{ var h='<div class=\\'marker-bus\\'>🚌<span>'+b.busNumber+'</span></div>'; L.marker([b.latitude,b.longitude],{icon:L.divIcon({className:'',html:h})}).addTo(map); });
  if(userLoc){ var u=document.createElement('div'); u.className='pulse-user'; L.marker([userLoc.latitude,userLoc.longitude],{icon:L.divIcon({className:'',html:u.outerHTML,iconSize:[16,16],iconAnchor:[8,8]})}).addTo(map); }
  map.on('click',e=>{ send({type:'mapClick', latitude:e.latlng.lat, longitude:e.latlng.lng}); });
  update('ready');
 } catch(err){ update('init err'); send({type:'error', message:String(err)}); showFallback(); }
 }
 setTimeout(()=>{ if(!leafletLoaded){ update('timeout'); } },7000);
})();
</script></body></html>`;
  }, [
    stops,
    buses,
    routeCoordinates,
    userLocation,
    region.latitude,
    region.longitude,
    zoom,
    routeColor,
  ]);

  const handleMessage = (e: any) => {
    try {
      const data = JSON.parse(e.nativeEvent.data);
      if (data.type === "mapClick" && onMapPress) {
        onMapPress({ latitude: data.latitude, longitude: data.longitude });
      } else if (data.type === "error") {
        console.error("[OSMWebMap] Inner WebView error:", data.message);
        setFailed(true);
        onError && onError(new Error(data.message));
      } else if (data.type === "tileError") {
        console.warn("[OSMWebMap] Tile error", data.url, "count", data.count);
      } else if (data.type === "fallbackTiles") {
        console.log("[OSMWebMap] Using fallback tile source");
      } else if (data.type === "tileLoaded") {
        console.log("[OSMWebMap] First tile loaded");
      } else if (data.type === "phase") {
        // Silent now (no overlay) – keep for debugging if needed
      } else {
        console.log("[OSMWebMap] Message", data);
      }
    } catch {}
  };

  if (failed) return <FallbackMap style={style} message="Map failed to load" />;

  return (
    <View style={[styles.container, style]}>
      {loading && (
        <View style={styles.loader}>
          <ActivityIndicator size="large" color="#1e40af" />
        </View>
      )}
      <WebView
        ref={(r) => {
          webRef.current = r;
        }}
        originWhitelist={["*"]}
        javaScriptEnabled
        domStorageEnabled
        onLoadEnd={() => setLoading(false)}
        onError={(err) => {
          setFailed(true);
          onError && onError(err);
        }}
        onMessage={handleMessage}
        injectedJavaScript="window.onerror=function(m,s,l,c,e){if(window.ReactNativeWebView){window.ReactNativeWebView.postMessage(JSON.stringify({type:'error',message:m+' @'+s+':'+l}));}};true;"
        style={styles.webview}
        source={{ html: html as unknown as string }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#000" },
  webview: { flex: 1, backgroundColor: "#000" },
  loader: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: "center",
    justifyContent: "center",
    zIndex: 5,
    backgroundColor: "rgba(255,255,255,0.25)",
  },
});

export default OSMWebMap;
