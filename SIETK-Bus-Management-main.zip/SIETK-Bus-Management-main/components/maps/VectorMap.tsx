import React from "react";
import { Text, View } from "react-native";
import { CommonMapProps } from "./MapAdapter";

// Placeholder until MapLibre integration added.
// Accepts fallback prop to gracefully downgrade.
interface VectorMapProps extends CommonMapProps {
  fallback?: React.ReactNode;
}

const VectorMap: React.FC<VectorMapProps> = ({ fallback }) => {
  // We could attempt dynamic require here later.
  return fallback ? (
    <>{fallback}</>
  ) : (
    <View
      style={{
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#111",
      }}
    >
      <Text style={{ color: "#fff" }}>Vector map not available</Text>
    </View>
  );
};

export default VectorMap;
