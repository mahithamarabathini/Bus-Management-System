import { getApp, getApps, initializeApp } from "firebase/app";
import { Auth, getAuth, initializeAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// Your Firebase configuration
// Replace these values with your actual Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyBB98Ek2eKPhIUKXw3I9yP7nf5bwNrcZGc",
  authDomain: "collegebusmanagement-609c4.firebaseapp.com",
  projectId: "collegebusmanagement-609c4",
  storageBucket: "collegebusmanagement-609c4.firebasestorage.app",
  messagingSenderId: "378381878269",
  appId: "1:378381878269:web:df3229f2783092557b8f94",
  measurementId: "G-5WEG0XKTED",
};

// Initialize Firebase - check if app already exists to prevent duplicate initialization
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Initialize Auth - Firebase v12 handles persistence automatically on React Native
let auth: Auth;
try {
  if (getApps().length === 0) {
    auth = initializeAuth(app);
  } else {
    auth = getAuth(app);
  }
} catch (error) {
  // If initializeAuth fails (already initialized), use getAuth
  auth = getAuth(app);
}

// Initialize Firestore
const db = getFirestore(app);

export { auth, db };
export default app;
