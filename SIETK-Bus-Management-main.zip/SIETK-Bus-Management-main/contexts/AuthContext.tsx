import {
  User,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut,
  updateProfile,
} from "firebase/auth";
import { doc, getDoc, serverTimestamp, setDoc } from "firebase/firestore";
import React, { createContext, useContext, useEffect, useState } from "react";
import { auth, db } from "../config/firebase";

export interface UserData {
  uid: string;
  email: string;
  displayName: string;
  role: "student" | "bus_incharge" | "parent" | "admin";
  studentId?: string;
  busNumber?: string;
  phoneNumber?: string;
  college?: string;
  branch?: string; // Added branch field
  year?: string; // Added year field
  address?: string; // Added address field
  parentMobile?: string; // Added parent mobile field
  childStudentId?: string; // For parent role
  createdAt?: any;
  lastLoginAt?: any;
}

interface AuthContextType {
  user: User | null;
  userData: UserData | null;
  loading: boolean; // overall auth loading (initial + transitions)
  signIn: (email: string, password: string) => Promise<UserData | null>;
  signUp: (
    email: string,
    password: string,
    userData: Partial<UserData>
  ) => Promise<void>;
  logout: () => Promise<void>;
  refreshUserData: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const [user, setUser] = useState<User | null>(null);
  const [userData, setUserData] = useState<UserData | null>(null);
  const [loading, setLoading] = useState(true);
  const [transitioning, setTransitioning] = useState(false); // during sign-in/sign-out transitions

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        setUser(firebaseUser);
        try {
          const userDocRef = doc(db, "users", firebaseUser.uid);
          const userDoc = await getDoc(userDocRef);
          if (userDoc.exists()) {
            const data = userDoc.data() as UserData;
            // Ensure displayName fallback consistency
            if (!data.displayName && firebaseUser.displayName) {
              data.displayName = firebaseUser.displayName;
            }
            setUserData(data);
          } else {
            // Create a minimal document if missing (edge case) to keep native consistent
            const minimal: UserData = {
              uid: firebaseUser.uid,
              email: firebaseUser.email || "",
              displayName: firebaseUser.displayName || firebaseUser.email || "",
              role: "student",
              createdAt: serverTimestamp(),
              lastLoginAt: serverTimestamp(),
            } as any;
            await setDoc(userDocRef, minimal, { merge: true });
            setUserData(minimal);
          }
        } catch (e) {
          console.warn("AuthContext fetch error", e);
        }
      } else {
        setUser(null);
        setUserData(null);
      }
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  const signIn = async (email: string, password: string) => {
    setTransitioning(true);
    // Clear prior userData immediately to avoid showing stale role
    setUserData(null);
    try {
      const userCredential = await signInWithEmailAndPassword(
        auth,
        email,
        password
      );
      const signedInUser = userCredential.user;
      setUser(signedInUser); // proactively set user so refreshUserData won't skip

      // Update last login timestamp
      const userDocRef = doc(db, "users", signedInUser.uid);
      await setDoc(
        userDocRef,
        { lastLoginAt: serverTimestamp() },
        { merge: true }
      );

      // Fetch fresh user document directly (avoid race with onAuthStateChanged)
      const userSnap = await getDoc(userDocRef);
      let freshData: UserData | null = null;
      if (userSnap.exists()) {
        freshData = userSnap.data() as UserData;
        if (!freshData.displayName && signedInUser.displayName) {
          freshData.displayName = signedInUser.displayName;
        }
      } else {
        // Edge: missing doc. Create minimal default.
        freshData = {
          uid: signedInUser.uid,
          email: signedInUser.email || email,
          displayName: signedInUser.displayName || signedInUser.email || email,
          role: "student",
          createdAt: serverTimestamp(),
          lastLoginAt: serverTimestamp(),
        } as any;
        await setDoc(userDocRef, freshData, { merge: true });
      }
      setUserData(freshData);
      return freshData;
    } catch (error) {
      // On error ensure user cleared
      setUser(null);
      setUserData(null);
      throw error;
    } finally {
      setTransitioning(false);
    }
  };

  const signUp = async (
    email: string,
    password: string,
    additionalData: Partial<UserData>
  ) => {
    try {
      const userCredential = await createUserWithEmailAndPassword(
        auth,
        email,
        password
      );
      const user = userCredential.user;

      // Update profile with display name
      if (additionalData.displayName) {
        await updateProfile(user, {
          displayName: additionalData.displayName,
        });
      }

      // Save additional user data to Firestore
      const userData: UserData = {
        uid: user.uid,
        email: user.email!,
        displayName: additionalData.displayName || "",
        role: additionalData.role || "student",
        ...(additionalData.studentId && {
          studentId: additionalData.studentId,
        }),
        ...(additionalData.busNumber && {
          busNumber: additionalData.busNumber,
        }),
        ...(additionalData.phoneNumber && {
          phoneNumber: additionalData.phoneNumber,
        }),
        ...(additionalData.college && { college: additionalData.college }),
        ...(additionalData.branch && { branch: additionalData.branch }),
        ...(additionalData.year && { year: additionalData.year }),
        createdAt: serverTimestamp(),
        lastLoginAt: serverTimestamp(),
      };

      await setDoc(doc(db, "users", user.uid), userData);
      setUserData(userData);
    } catch (error) {
      throw error;
    }
  };

  const logout = async () => {
    setTransitioning(true);
    try {
      setUser(null);
      setUserData(null);
      await signOut(auth);
    } catch (error) {
      console.error("Logout error:", error);
      throw error;
    } finally {
      setTransitioning(false);
    }
  };

  const refreshUserData = async () => {
    if (user) {
      try {
        const userDocRef = doc(db, "users", user.uid);
        const userDoc = await getDoc(userDocRef);
        if (userDoc.exists()) {
          const data = userDoc.data() as UserData;
          if (!data.displayName && user.displayName) {
            data.displayName = user.displayName;
          }
          setUserData(data);
        }
      } catch (error) {
        console.error("Error refreshing user data:", error);
      }
    }
  };

  const value: AuthContextType = {
    user,
    userData,
    loading: loading || transitioning,
    signIn,
    signUp,
    logout,
    refreshUserData,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
