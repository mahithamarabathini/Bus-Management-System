import {
  collection,
  limit,
  onSnapshot,
  query,
  where,
} from "firebase/firestore";
import React, {
  createContext,
  ReactNode,
  useContext,
  useEffect,
  useState,
} from "react";
import { db } from "../config/firebase";
import {
  NotificationData,
  notificationService,
} from "../services/NotificationService";
import { useAuth } from "./AuthContext";

interface NotificationContextType {
  isInitialized: boolean;
  pushToken: string | null;
  notificationHistory: NotificationData[];
  unreadCount: number;
  sendBusArrivalNotification: (
    busNumber: string,
    stopName: string,
    estimatedMinutes: number
  ) => Promise<void>;
  sendStudentBoardingNotification: (
    studentName: string,
    busNumber: string,
    stopName: string
  ) => Promise<void>;
  sendStudentDeboardingNotification: (
    studentName: string,
    busNumber: string,
    stopName: string
  ) => Promise<void>;
  sendBusDelayNotification: (
    busNumber: string,
    routeName: string,
    delayMinutes: number,
    reason?: string
  ) => Promise<void>;
  sendEmergencyNotification: (
    title: string,
    message: string,
    busNumber?: string
  ) => Promise<void>;
  sendAnnouncementNotification: (
    title: string,
    message: string
  ) => Promise<void>;
  clearAllNotifications: () => Promise<void>;
  markAsRead: (notificationId: string) => Promise<void>;
  deleteNotification: (notificationId: string) => Promise<void>;
  preferences: NotificationPreferences;
  updatePreferences: (patch: Partial<NotificationPreferences>) => Promise<void>;
}

interface NotificationPreferences {
  arrival: boolean;
  boarding: boolean;
  delay: boolean;
  announcement: boolean;
  emergency: boolean;
  quietHoursEnabled: boolean;
  quietStart?: string; // HH:mm
  quietEnd?: string; // HH:mm
}

const NotificationContext = createContext<NotificationContextType | undefined>(
  undefined
);

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error(
      "useNotifications must be used within a NotificationProvider"
    );
  }
  return context;
};

interface NotificationProviderProps {
  children: ReactNode;
}

export const NotificationProvider: React.FC<NotificationProviderProps> = ({
  children,
}) => {
  const { user, userData } = useAuth();
  const [isInitialized, setIsInitialized] = useState(false);
  const [pushToken, setPushToken] = useState<string | null>(null);
  const [notificationHistory, setNotificationHistory] = useState<
    NotificationData[]
  >([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [preferences, setPreferences] = useState<NotificationPreferences>({
    arrival: true,
    boarding: true,
    delay: true,
    announcement: true,
    emergency: true,
    quietHoursEnabled: false,
  });

  useEffect(() => {
    initializeNotifications();
  }, []);

  useEffect(() => {
    if (user && userData) {
      setupNotificationListeners();
      loadNotificationHistory();
    }
  }, [user, userData]);

  useEffect(() => {
    // Load preferences for user
    const loadPrefs = async () => {
      if (!user) return;
      try {
        const { doc, getDoc } = await import("firebase/firestore");
        const ref = doc(db, "users", user.uid);
        const snap = await getDoc(ref);
        if (snap.exists()) {
          const data: any = snap.data();
          if (data.notificationPreferences) {
            setPreferences({ ...preferences, ...data.notificationPreferences });
          }
        }
      } catch (e) {
        console.warn("Failed loading notification preferences", e);
      }
    };
    loadPrefs();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const initializeNotifications = async () => {
    try {
      const initialized = await notificationService.initialize();
      setIsInitialized(initialized);

      if (initialized) {
        const token = notificationService.getPushToken();
        setPushToken(token);

        // Save push token to user profile if logged in
        if (user) {
          await notificationService.savePushTokenToUser(user.uid);
        }
      }
    } catch (error) {
      console.error("Error initializing notifications:", error);
    }
  };

  const setupNotificationListeners = () => {
    const listeners = notificationService.setupNotificationListeners();

    // Cleanup listeners on unmount
    return () => {
      notificationService.removeNotificationListeners(listeners);
    };
  };

  const loadNotificationHistory = () => {
    if (!userData || !userData.uid) {
      console.log("NotificationContext: userData or uid not available");
      return;
    }

    try {
      const notificationsRef = collection(db, "notifications");
      // Remove composite where+orderBy that was requiring index.
      // We'll listen separately to user-specific and global then merge & sort client-side.
      const userQ = query(
        notificationsRef,
        where("userId", "==", userData.uid),
        limit(100)
      );
      const globalQ = query(
        notificationsRef,
        where("userId", "==", "global"),
        limit(100)
      );

      const mergeAndSet = (userSnap: any, globalSnap: any) => {
        const list: any[] = [];
        let unread = 0;
        if (userSnap) {
          userSnap.forEach((d: any) => {
            const data = d.data();
            const item = { ...data, id: d.id };
            list.push(item);
            if (!data.read) unread++;
          });
        }
        if (globalSnap) {
          globalSnap.forEach((d: any) => {
            const data = d.data();
            const item = { ...data, id: d.id };
            list.push(item);
            if (!data.read) unread++;
          });
        }
        // Sort newest first (timestamp could be Date or Firestore Timestamp)
        list.sort((a, b) => {
          const ta = a.timestamp?.seconds
            ? a.timestamp.seconds * 1000
            : new Date(a.timestamp).getTime();
          const tb = b.timestamp?.seconds
            ? b.timestamp.seconds * 1000
            : new Date(b.timestamp).getTime();
          return tb - ta;
        });
        setNotificationHistory(list.slice(0, 100));
        setUnreadCount(unread);
      };

      let userSnapCache: any = null;
      let globalSnapCache: any = null;

      const unsubUser = onSnapshot(userQ, (snap) => {
        userSnapCache = snap;
        mergeAndSet(userSnapCache, globalSnapCache);
      });
      const unsubGlobal = onSnapshot(globalQ, (snap) => {
        globalSnapCache = snap;
        mergeAndSet(userSnapCache, globalSnapCache);
      });

      return () => {
        unsubUser();
        unsubGlobal();
      };
    } catch (error) {
      console.error("Error in loadNotificationHistory:", error);
      return;
    }
  };

  const sendBusArrivalNotification = async (
    busNumber: string,
    stopName: string,
    estimatedMinutes: number
  ) => {
    await notificationService.notifyBusArrival(
      busNumber,
      stopName,
      estimatedMinutes
    );
  };

  const sendStudentBoardingNotification = async (
    studentName: string,
    busNumber: string,
    stopName: string
  ) => {
    await notificationService.notifyStudentBoarding(
      studentName,
      busNumber,
      stopName
    );
  };

  const sendStudentDeboardingNotification = async (
    studentName: string,
    busNumber: string,
    stopName: string
  ) => {
    await notificationService.notifyStudentDeboarding(
      studentName,
      busNumber,
      stopName
    );
  };

  const sendBusDelayNotification = async (
    busNumber: string,
    routeName: string,
    delayMinutes: number,
    reason?: string
  ) => {
    await notificationService.notifyBusDelay(
      busNumber,
      routeName,
      delayMinutes,
      reason
    );
  };

  const sendEmergencyNotification = async (
    title: string,
    message: string,
    busNumber?: string
  ) => {
    await notificationService.notifyEmergency(title, message, busNumber);
  };

  const sendAnnouncementNotification = async (
    title: string,
    message: string
  ) => {
    await notificationService.notifyGeneralAnnouncement(title, message);
  };

  const clearAllNotifications = async () => {
    await notificationService.clearAllNotifications();
    setNotificationHistory([]);
    setUnreadCount(0);
  };

  const updatePreferences = async (patch: Partial<NotificationPreferences>) => {
    if (!user) return;
    const next = { ...preferences, ...patch };
    setPreferences(next);
    try {
      const { doc, updateDoc } = await import("firebase/firestore");
      await updateDoc(doc(db, "users", user.uid), {
        notificationPreferences: next,
        updatedAt: new Date(),
      });
    } catch (e) {
      console.error("updatePreferences error", e);
    }
  };

  const markAsRead = async (notificationId: string) => {
    try {
      await notificationService.markNotificationRead(notificationId);
    } catch (e) {
      console.error("markAsRead error", e);
    }
  };

  const deleteNotification = async (notificationId: string) => {
    try {
      await notificationService.deleteNotification(notificationId);
    } catch (e) {
      console.error("deleteNotification error", e);
    }
  };

  const contextValue: NotificationContextType = {
    isInitialized,
    pushToken,
    notificationHistory,
    unreadCount,
    sendBusArrivalNotification,
    sendStudentBoardingNotification,
    sendStudentDeboardingNotification,
    sendBusDelayNotification,
    sendEmergencyNotification,
    sendAnnouncementNotification,
    clearAllNotifications,
    markAsRead,
    deleteNotification,
    preferences,
    updatePreferences,
  };

  return (
    <NotificationContext.Provider value={contextValue}>
      {children}
    </NotificationContext.Provider>
  );
};
