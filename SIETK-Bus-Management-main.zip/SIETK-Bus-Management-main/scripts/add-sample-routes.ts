import { initializeApp } from "firebase/app";
import { addDoc, collection, getFirestore } from "firebase/firestore";

// Firebase config - replace with your actual config
const firebaseConfig = {
  apiKey: "your-api-key",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "123456789",
  appId: "your-app-id",
};

// Sample route data for testing
const sampleRoutes = [
  {
    name: "Campus to City Center",
    busNumber: "CB001",
    color: "#FF6B6B",
    isActive: true,
    stops: [
      {
        id: "stop_1",
        name: "Main Campus Gate",
        latitude: 12.9716,
        longitude: 77.5946,
        order: 1,
      },
      {
        id: "stop_2",
        name: "Engineering Block",
        latitude: 12.972,
        longitude: 77.595,
        order: 2,
      },
      {
        id: "stop_3",
        name: "Library Junction",
        latitude: 12.9725,
        longitude: 77.5955,
        order: 3,
      },
      {
        id: "stop_4",
        name: "City Center Mall",
        latitude: 12.98,
        longitude: 77.61,
        order: 4,
      },
    ],
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    name: "Campus to Tech Park",
    busNumber: "CB002",
    color: "#4ECDC4",
    isActive: true,
    stops: [
      {
        id: "stop_1",
        name: "Main Campus Gate",
        latitude: 12.9716,
        longitude: 77.5946,
        order: 1,
      },
      {
        id: "stop_2",
        name: "Sports Complex",
        latitude: 12.971,
        longitude: 77.594,
        order: 2,
      },
      {
        id: "stop_3",
        name: "Metro Station",
        latitude: 12.965,
        longitude: 77.58,
        order: 3,
      },
      {
        id: "stop_4",
        name: "Electronic City",
        latitude: 12.85,
        longitude: 77.66,
        order: 4,
      },
    ],
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    name: "Campus to Airport",
    busNumber: "CB003",
    color: "#45B7D1",
    isActive: false,
    stops: [
      {
        id: "stop_1",
        name: "Main Campus Gate",
        latitude: 12.9716,
        longitude: 77.5946,
        order: 1,
      },
      {
        id: "stop_2",
        name: "Hostel Block A",
        latitude: 12.97,
        longitude: 77.593,
        order: 2,
      },
      {
        id: "stop_3",
        name: "Outer Ring Road",
        latitude: 12.95,
        longitude: 77.55,
        order: 3,
      },
      {
        id: "stop_4",
        name: "Kempegowda Airport",
        latitude: 13.1986,
        longitude: 77.7066,
        order: 4,
      },
    ],
    createdAt: new Date(),
    updatedAt: new Date(),
  },
];

// Function to add sample routes to Firestore
export async function addSampleRoutes() {
  const app = initializeApp(firebaseConfig);
  const db = getFirestore(app);

  try {
    const routesCollection = collection(db, "routes");

    for (const route of sampleRoutes) {
      await addDoc(routesCollection, route);
      console.log(`Added route: ${route.name}`);
    }

    console.log("All sample routes added successfully!");
  } catch (error) {
    console.error("Error adding sample routes:", error);
  }
}

// Uncomment the line below to run this script and add sample data
// addSampleRoutes();
