# Removed Legacy Map Code

Date: 2025-08-10

Removed the following legacy files and dependencies during migration to MapAdapter + OSM WebView implementation:

- components/PlatformMap.tsx
- components/PlatformMap.native.tsx
- components/PlatformMap.web.tsx
- react-native-maps dependency (package.json)
- fix-maps scripts (no longer needed)

Rationale:

- Consolidated mapping via `components/maps/MapAdapter.tsx`.
- Eliminated native dependency complexity and Google key requirements.
- Simplified troubleshooting & future vector map upgrade path.

If you need to restore, retrieve them from git history prior to this commit.
