# This script fixes issues with react-native-maps and other dependencies
Write-Host "Starting map dependency repair script..." -ForegroundColor Cyan

# Install react-native-maps
Write-Host "Installing/reinstalling react-native-maps..." -ForegroundColor Yellow
npx expo install react-native-maps

# Install WebView for web fallback
Write-Host "Installing WebView component for fallback..." -ForegroundColor Yellow
npx expo install react-native-webview

# Clear cache
Write-Host "Clearing npm cache..." -ForegroundColor Yellow
npm cache clean --force

# Clear metro bundler cache
Write-Host "Clearing metro bundler cache..." -ForegroundColor Yellow
if (Test-Path "node_modules/.cache") {
    Remove-Item -Recurse -Force "node_modules/.cache"
}

Write-Host "Running expo prebuild to update native dependencies..." -ForegroundColor Yellow
npx expo prebuild

Write-Host "Repair script completed!" -ForegroundColor Green
Write-Host "Please restart your Expo app with 'npx expo start --clear'" -ForegroundColor Cyan
