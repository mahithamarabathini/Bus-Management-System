# This script fixes issues with react-native-maps and other dependencies

echo "Starting map dependency repair script..."

# Install react-native-maps
echo "Installing/reinstalling react-native-maps..."
npx expo install react-native-maps

# Install WebView for web fallback
echo "Installing WebView component for fallback..."
npx expo install react-native-webview

# Clear cache
echo "Clearing npm cache..."
npm cache clean --force

# Clear metro bundler cache
echo "Clearing metro bundler cache..."
rm -rf node_modules/.cache

echo "Running expo prebuild to update native dependencies..."
npx expo prebuild

echo "Repair script completed!"
echo "Please restart your Expo app with 'npx expo start --clear'"
