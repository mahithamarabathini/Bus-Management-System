import * as Location from "expo-location";
import { doc, serverTimestamp, setDoc } from "firebase/firestore";
import { db } from "../config/firebase";

export interface LocationData {
  latitude: number;
  longitude: number;
  altitude?: number | null;
  accuracy?: number | null;
  heading?: number | null;
  speed?: number | null;
  timestamp: number;
}

export interface BusLocationUpdate {
  busNumber: string;
  driverId: string;
  location: LocationData;
  isActive: boolean;
  lastUpdated: any; // Firestore server timestamp
}

class LocationService {
  private watchSubscription: Location.LocationSubscription | null = null;
  private isTracking = false;

  async requestPermissions(): Promise<boolean> {
    try {
      const { status: foregroundStatus } =
        await Location.requestForegroundPermissionsAsync();

      if (foregroundStatus !== "granted") {
        throw new Error("Foreground location permission not granted");
      }

      // For background tracking (optional)
      const { status: backgroundStatus } =
        await Location.requestBackgroundPermissionsAsync();

      if (backgroundStatus !== "granted") {
        console.warn("Background location permission not granted");
      }

      return true;
    } catch (error) {
      console.error("Error requesting location permissions:", error);
      return false;
    }
  }

  async getCurrentLocation(): Promise<LocationData | null> {
    try {
      const hasPermission = await this.requestPermissions();
      if (!hasPermission) {
        return null;
      }

      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High,
      });

      return {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
        altitude: location.coords.altitude,
        accuracy: location.coords.accuracy,
        heading: location.coords.heading,
        speed: location.coords.speed,
        timestamp: location.timestamp,
      };
    } catch (error) {
      console.error("Error getting current location:", error);
      return null;
    }
  }

  async startLocationTracking(
    busNumber: string,
    driverId: string,
    onLocationUpdate?: (location: LocationData) => void
  ): Promise<boolean> {
    try {
      const hasPermission = await this.requestPermissions();
      if (!hasPermission) {
        return false;
      }

      if (this.isTracking) {
        console.warn("Location tracking is already active");
        return true;
      }

      this.watchSubscription = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.High,
          timeInterval: 10000, // Update every 10 seconds
          distanceInterval: 10, // Update every 10 meters
        },
        async (location) => {
          const locationData: LocationData = {
            latitude: location.coords.latitude,
            longitude: location.coords.longitude,
            altitude: location.coords.altitude,
            accuracy: location.coords.accuracy,
            heading: location.coords.heading,
            speed: location.coords.speed,
            timestamp: location.timestamp,
          };

          // Update Firestore with new location
          await this.updateBusLocation(busNumber, driverId, locationData);

          // Call callback if provided
          if (onLocationUpdate) {
            onLocationUpdate(locationData);
          }
        }
      );

      this.isTracking = true;
      console.log("Location tracking started");
      return true;
    } catch (error) {
      console.error("Error starting location tracking:", error);
      return false;
    }
  }

  async stopLocationTracking(
    busNumber: string,
    driverId: string
  ): Promise<void> {
    try {
      if (this.watchSubscription) {
        this.watchSubscription.remove();
        this.watchSubscription = null;
      }

      this.isTracking = false;

      // Update Firestore to mark bus as inactive
      await this.updateBusStatus(busNumber, driverId, false);

      console.log("Location tracking stopped");
    } catch (error) {
      console.error("Error stopping location tracking:", error);
    }
  }

  private async updateBusLocation(
    busNumber: string,
    driverId: string,
    location: LocationData
  ): Promise<void> {
    try {
      const busLocationRef = doc(db, "busLocations", busNumber);

      const updateData: BusLocationUpdate = {
        busNumber,
        driverId,
        location,
        isActive: true,
        lastUpdated: serverTimestamp(),
      };

      await setDoc(busLocationRef, updateData, { merge: true });
    } catch (error) {
      console.error("Error updating bus location:", error);
    }
  }

  private async updateBusStatus(
    busNumber: string,
    driverId: string,
    isActive: boolean
  ): Promise<void> {
    try {
      const busLocationRef = doc(db, "busLocations", busNumber);

      await setDoc(
        busLocationRef,
        {
          busNumber,
          driverId,
          isActive,
          lastUpdated: serverTimestamp(),
        },
        { merge: true }
      );
    } catch (error) {
      console.error("Error updating bus status:", error);
    }
  }

  isLocationTrackingActive(): boolean {
    return this.isTracking;
  }

  async checkLocationServicesEnabled(): Promise<boolean> {
    try {
      return await Location.hasServicesEnabledAsync();
    } catch (error) {
      console.error("Error checking location services:", error);
      return false;
    }
  }
}

export const locationService = new LocationService();
