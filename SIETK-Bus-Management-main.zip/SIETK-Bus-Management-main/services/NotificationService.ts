import Constants from "expo-constants";
import * as Notifications from "expo-notifications";
import { addDoc, collection, doc, updateDoc } from "firebase/firestore";
import { Platform } from "react-native";
import { db } from "../config/firebase";

// Configure notification behavior
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export interface NotificationData {
  title: string;
  body: string;
  data?: any;
  userId?: string; // target user id or 'global'
  busNumber?: string;
  type: "boarding" | "arrival" | "delay" | "announcement" | "emergency";
}

class NotificationService {
  private expoPushToken: string | null = null;

  async initialize(): Promise<boolean> {
    try {
      // Detect unsupported environment (Expo Go store client, SDK 53+)
      const ownership = (Constants as any).appOwnership;
      const execEnv = (Constants as any).executionEnvironment;
      const inStoreClient = ownership === "expo" && execEnv === "storeClient";

      // Request permissions (even in Expo Go so local notifications still work)
      const { status: existingStatus } =
        await Notifications.getPermissionsAsync();
      let finalStatus = existingStatus;

      if (existingStatus !== "granted") {
        const { status } = await Notifications.requestPermissionsAsync();
        finalStatus = status;
      }

      if (finalStatus !== "granted") {
        console.warn("Failed to get push notification permissions");
        return false; // local scheduling also requires permission
      }

      if (inStoreClient) {
        console.warn(
          "[PushToken] Running inside Expo Go (store client). Remote push tokens are not supported in SDK 53+. Build a development client with 'eas build --profile development'."
        );
        // Continue configuring channels so local notifications still work.
      } else {
        // Get push token - Updated for SDK 53 (only in dev/standalone builds)
        try {
          // Resolve projectId robustly (normalize & trim)
          const candidates: (string | undefined)[] = [
            Constants.easConfig?.projectId,
            (Constants as any).expoConfig?.extra?.eas?.projectId,
            (Constants as any).manifest?.extra?.eas?.projectId,
            (Constants as any).manifest2?.extra?.eas?.projectId,
          ];
          let rawId = candidates.find((v) => !!v)?.trim();
          if (rawId && rawId.startsWith("{") && rawId.endsWith("}"))
            rawId = rawId.slice(1, -1); // remove braces if present
          const uuidRegex =
            /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
          let tokenResponse: Notifications.ExpoPushToken | null = null;
          const attemptWithProject = async (id: string) => {
            console.log("[PushToken] Attempting with projectId", id);
            return await Notifications.getExpoPushTokenAsync({ projectId: id });
          };
          const attemptWithoutProject = async () => {
            console.log("[PushToken] Attempting without explicit projectId");
            return await Notifications.getExpoPushTokenAsync();
          };
          if (rawId && uuidRegex.test(rawId)) {
            const versionChar = rawId.split("-")[2]?.charAt(0);
            if (versionChar && versionChar !== "4") {
              console.warn(
                `[PushToken] projectId appears to be UUID version ${versionChar}, expected v4 for standard EAS IDs. Verify you used the real EAS projectId.`
              );
            }
            try {
              tokenResponse = await attemptWithProject(rawId);
            } catch (inner: any) {
              const msg =
                inner?.message || inner?.toString?.() || String(inner);
              const body = inner?.toString?.() || "";
              const invalid =
                /Invalid uuid/i.test(msg) || /Invalid uuid/i.test(body);
              if (invalid) {
                console.warn(
                  "[PushToken] Server rejected projectId as invalid UUID. Falling back without projectId. Value used:",
                  rawId
                );
                try {
                  tokenResponse = await attemptWithoutProject();
                } catch (fallbackErr) {
                  console.error(
                    "[PushToken] Fallback (no projectId) also failed:",
                    fallbackErr
                  );
                }
              } else {
                console.warn(
                  "[PushToken] Token fetch with projectId failed, retrying w/out projectId. Reason:",
                  msg
                );
                try {
                  tokenResponse = await attemptWithoutProject();
                } catch (fallbackErr) {
                  console.error(
                    "[PushToken] Fallback (no projectId) also failed:",
                    fallbackErr
                  );
                }
              }
            }
          } else {
            if (rawId) {
              console.warn(
                "[PushToken] Ignored non-UUID format projectId value:",
                rawId
              );
            } else {
              console.warn(
                "[PushToken] No projectId detected; using implicit (dev)."
              );
            }
            try {
              tokenResponse = await attemptWithoutProject();
            } catch (noProjErr) {
              console.error(
                "[PushToken] Token fetch without projectId failed:",
                noProjErr
              );
            }
          }
          if (tokenResponse) {
            this.expoPushToken = tokenResponse.data;
            console.log("[PushToken] Acquired token", this.expoPushToken);
          } else {
            console.warn(
              "[PushToken] No token acquired after attempts. Continuing without push token."
            );
            this.expoPushToken = null;
          }
        } catch (tokenError) {
          console.error(
            "Error getting push token (will continue without it):",
            tokenError
          );
          this.expoPushToken = null;
        }
      }

      // Configure for Android
      if (Platform.OS === "android") {
        await Notifications.setNotificationChannelAsync("default", {
          name: "College Bus Updates",
          importance: Notifications.AndroidImportance.MAX,
          vibrationPattern: [0, 250, 250, 250],
          lightColor: "#FF231F7C",
        });

        await Notifications.setNotificationChannelAsync("emergency", {
          name: "Emergency Alerts",
          importance: Notifications.AndroidImportance.MAX,
          vibrationPattern: [0, 250, 250, 250],
          lightColor: "#FF0000",
          sound: "default",
        });
      }

      return true;
    } catch (error) {
      console.error("Error initializing notifications:", error);
      return false;
    }
  }

  async savePushTokenToUser(userId: string): Promise<void> {
    if (!this.expoPushToken) {
      console.warn("No push token available to save");
      return;
    }

    try {
      const userRef = doc(db, "users", userId);
      await updateDoc(userRef, {
        pushToken: this.expoPushToken,
        updatedAt: new Date(),
      });
      console.log("Push token saved to user profile");
    } catch (error) {
      console.error("Error saving push token:", error);
      // Don't throw error - continue app functionality even if token save fails
    }
  }

  async sendLocalNotification(
    notificationData: NotificationData
  ): Promise<void> {
    try {
      await Notifications.scheduleNotificationAsync({
        content: {
          title: notificationData.title,
          body: notificationData.body,
          data: notificationData.data,
          categoryIdentifier: notificationData.type,
        },
        trigger: null, // Send immediately
      });
    } catch (error) {
      console.error("Error sending local notification:", error);
    }
  }

  async saveNotificationToFirestore(
    notificationData: NotificationData,
    targetUserIds?: string[]
  ): Promise<void> {
    try {
      const base = {
        ...notificationData,
        timestamp: new Date(),
        sent: false,
        read: false,
      };
      if (targetUserIds && targetUserIds.length > 0) {
        await Promise.all(
          targetUserIds.map((uid) =>
            addDoc(collection(db, "notifications"), { ...base, userId: uid })
          )
        );
      } else {
        // Global notification
        await addDoc(collection(db, "notifications"), {
          ...base,
          userId: "global",
        });
      }
    } catch (error) {
      console.error("Error saving notification to Firestore:", error);
    }
  }

  // Notification templates for different scenarios
  async notifyBusArrival(
    busNumber: string,
    stopName: string,
    estimatedMinutes: number,
    targetUserIds?: string[]
  ): Promise<void> {
    const notification: NotificationData = {
      title: `Bus ${busNumber} Approaching`,
      body: `Your bus will arrive at ${stopName} in approximately ${estimatedMinutes} minutes.`,
      type: "arrival",
      busNumber,
      data: {
        busNumber,
        stopName,
        estimatedMinutes,
        timestamp: new Date().toISOString(),
      },
    };

    await this.sendLocalNotification(notification);
    await this.saveNotificationToFirestore(notification, targetUserIds);
  }

  async notifyStudentBoarding(
    studentName: string,
    busNumber: string,
    stopName: string,
    targetUserIds?: string[]
  ): Promise<void> {
    const notification: NotificationData = {
      title: "Student Boarded",
      body: `${studentName} has boarded bus ${busNumber} at ${stopName}.`,
      type: "boarding",
      busNumber,
      data: {
        studentName,
        busNumber,
        stopName,
        action: "boarded",
        timestamp: new Date().toISOString(),
      },
    };

    await this.sendLocalNotification(notification);
    await this.saveNotificationToFirestore(notification, targetUserIds);
  }

  async notifyStudentDeboarding(
    studentName: string,
    busNumber: string,
    stopName: string,
    targetUserIds?: string[]
  ): Promise<void> {
    const notification: NotificationData = {
      title: "Student Deboarded",
      body: `${studentName} has deboarded bus ${busNumber} at ${stopName}.`,
      type: "boarding",
      busNumber,
      data: {
        studentName,
        busNumber,
        stopName,
        action: "deboarded",
        timestamp: new Date().toISOString(),
      },
    };

    await this.sendLocalNotification(notification);
    await this.saveNotificationToFirestore(notification, targetUserIds);
  }

  async notifyBusDelay(
    busNumber: string,
    routeName: string,
    delayMinutes: number,
    reason?: string,
    targetUserIds?: string[]
  ): Promise<void> {
    const notification: NotificationData = {
      title: `Bus ${busNumber} Delayed`,
      body: `${routeName} is delayed by ${delayMinutes} minutes${
        reason ? ` due to ${reason}` : ""
      }.`,
      type: "delay",
      busNumber,
      data: {
        busNumber,
        routeName,
        delayMinutes,
        reason,
        timestamp: new Date().toISOString(),
      },
    };

    await this.sendLocalNotification(notification);
    await this.saveNotificationToFirestore(notification, targetUserIds);
  }

  async notifyEmergency(
    title: string,
    message: string,
    busNumber?: string,
    targetUserIds?: string[]
  ): Promise<void> {
    const notification: NotificationData = {
      title: `🚨 EMERGENCY: ${title}`,
      body: message,
      type: "emergency",
      busNumber,
      data: {
        priority: "high",
        timestamp: new Date().toISOString(),
        busNumber,
      },
    };

    if (Platform.OS === "android") {
      await Notifications.scheduleNotificationAsync({
        content: {
          title: notification.title,
          body: notification.body,
          data: notification.data,
          categoryIdentifier: "emergency",
        },
        trigger: null,
      });
    } else {
      await this.sendLocalNotification(notification);
    }

    await this.saveNotificationToFirestore(notification, targetUserIds);
  }

  async notifyGeneralAnnouncement(
    title: string,
    message: string,
    targetUserIds?: string[]
  ): Promise<void> {
    const notification: NotificationData = {
      title,
      body: message,
      type: "announcement",
      data: {
        timestamp: new Date().toISOString(),
      },
    };

    await this.sendLocalNotification(notification);
    await this.saveNotificationToFirestore(notification, targetUserIds);
  }

  // Get notification history for user
  async getNotificationHistory(): Promise<any[]> {
    try {
      // This would typically filter by userId in a real implementation
      const history = await Notifications.getAllScheduledNotificationsAsync();
      return history;
    } catch (error) {
      console.error("Error getting notification history:", error);
      return [];
    }
  }

  // Clear all notifications
  async clearAllNotifications(): Promise<void> {
    try {
      await Notifications.cancelAllScheduledNotificationsAsync();
      await Notifications.dismissAllNotificationsAsync();
    } catch (error) {
      console.error("Error clearing notifications:", error);
    }
  }

  // Get the current push token
  getPushToken(): string | null {
    return this.expoPushToken;
  }

  // Set up notification listeners
  setupNotificationListeners() {
    // Handle notification received while app is in foreground
    const foregroundSubscription =
      Notifications.addNotificationReceivedListener((notification) => {
        console.log("Notification received in foreground:", notification);
      });

    // Handle notification tapped/opened
    const responseSubscription =
      Notifications.addNotificationResponseReceivedListener((response) => {
        console.log("Notification response:", response);
        const data = response.notification.request.content.data;

        // Handle different notification types
        if (data.busNumber) {
          console.log(`Navigate to bus ${data.busNumber} details`);
          // You can use router.push() here to navigate to specific screens
        }
      });

    return {
      foregroundSubscription,
      responseSubscription,
    };
  }

  // Clean up listeners
  removeNotificationListeners(subscriptions: any) {
    subscriptions.foregroundSubscription?.remove();
    subscriptions.responseSubscription?.remove();
  }

  // Mark a notification as read
  async markNotificationRead(id: string): Promise<void> {
    try {
      const { doc, updateDoc } = await import("firebase/firestore");
      await updateDoc(doc(db, "notifications", id), { read: true });
    } catch (e) {
      console.error("markNotificationRead error", e);
    }
  }

  // Delete a notification
  async deleteNotification(id: string): Promise<void> {
    try {
      const { doc, deleteDoc } = await import("firebase/firestore");
      await deleteDoc(doc(db, "notifications", id));
    } catch (e) {
      console.error("deleteNotification error", e);
    }
  }
}

export const notificationService = new NotificationService();
