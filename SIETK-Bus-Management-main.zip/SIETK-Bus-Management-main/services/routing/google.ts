// Stub provider to keep interface parity; real implementation will need Google Directions API key.
import { LatLng, RouteResult, RoutingError, RoutingProvider } from "./types";

export const GoogleProvider: RoutingProvider = {
  name: "google",
  async getRoute(points: LatLng[]): Promise<RouteResult> {
    throw new RoutingError("Google routing not enabled (no API key)");
  },
  async snap(point: LatLng): Promise<LatLng> {
    return point; // no-op
  },
};
