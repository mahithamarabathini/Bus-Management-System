import { GoogleProvider } from "./google";
import { OSRMProvider } from "./osrm";
import { RoutingProvider } from "./types";

const providers: Record<string, RoutingProvider> = {
  osrm: OSRMProvider,
  google: GoogleProvider,
};

export function getRoutingProvider(name?: string): RoutingProvider {
  if (!name) return OSRMProvider;
  return providers[name] || OSRMProvider;
}

export * from "./types";
