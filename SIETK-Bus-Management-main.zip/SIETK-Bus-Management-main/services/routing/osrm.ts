import { decodePolyline } from "./polyline";
import { LatLng, RouteResult, RoutingError, RoutingProvider } from "./types";

const OSRM_BASE = "https://router.project-osrm.org";

function buildCoords(points: LatLng[]): string {
  return points.map((p) => `${p.longitude},${p.latitude}`).join(";");
}

export const OSRMProvider: RoutingProvider = {
  name: "osrm",
  async getRoute(points: LatLng[]): Promise<RouteResult> {
    if (points.length < 2) throw new RoutingError("Need at least 2 points");
    const coords = buildCoords(points);
    // Include annotations for speed/duration & add steps for potential turn-by-turn arrows
    const url = `${OSRM_BASE}/route/v1/driving/${coords}?overview=full&geometries=polyline&steps=true&annotations=distance,duration,speed`;
    const res = await fetch(url);
    if (!res.ok) throw new RoutingError("OSRM network error");
    const json = await res.json();
    if (!json.routes || !json.routes.length)
      throw new RoutingError("No route found");
    const route = json.routes[0];
    return {
      geometry: decodePolyline(route.geometry),
      distanceMeters: route.distance,
      durationSeconds: route.duration,
      provider: "osrm",
      raw: route,
    };
  },
  async snap(point: LatLng): Promise<LatLng> {
    // Using nearest service
    const url = `${OSRM_BASE}/nearest/v1/driving/${point.longitude},${point.latitude}`;
    const res = await fetch(url);
    if (!res.ok) return point;
    const json = await res.json();
    if (json.waypoints && json.waypoints.length) {
      const wp = json.waypoints[0].location; // [lon, lat]
      return { latitude: wp[1], longitude: wp[0] };
    }
    return point;
  },
};
