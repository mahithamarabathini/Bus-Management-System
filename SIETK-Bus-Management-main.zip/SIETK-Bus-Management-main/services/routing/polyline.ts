// Polyline decoder (Google/OSRM compatible) - minimal implementation
import { LatLng } from "./types";

export function decodePolyline(str: string, precision = 5): LatLng[] {
  let index = 0,
    lat = 0,
    lng = 0,
    coordinates: LatLng[] = [];
  const factor = Math.pow(10, precision);
  while (index < str.length) {
    let b,
      shift = 0,
      result = 0;
    do {
      b = str.charCodeAt(index++) - 63;
      result |= (b & 0x1f) << shift;
      shift += 5;
    } while (b >= 0x20);
    const dlat = result & 1 ? ~(result >> 1) : result >> 1;
    lat += dlat;
    shift = 0;
    result = 0;
    do {
      b = str.charCodeAt(index++) - 63;
      result |= (b & 0x1f) << shift;
      shift += 5;
    } while (b >= 0x20);
    const dlng = result & 1 ? ~(result >> 1) : result >> 1;
    lng += dlng;
    coordinates.push({ latitude: lat / factor, longitude: lng / factor });
  }
  return coordinates;
}
