export interface LatLng {
  latitude: number;
  longitude: number;
}

export interface RouteResult {
  geometry: LatLng[];
  distanceMeters: number;
  durationSeconds: number;
  provider: string;
  raw?: any;
}

export interface RoutingProvider {
  name: string;
  getRoute(points: LatLng[]): Promise<RouteResult>;
  snap?(point: LatLng): Promise<LatLng>;
}

export class RoutingError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "RoutingError";
  }
}
